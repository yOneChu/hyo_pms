create TYPE CELL_INFO AS OBJECT (
classname VARCHAR2(200),
cell_id NUMBER,
link_id NUMBER,
column_id NUMBER
)
/

