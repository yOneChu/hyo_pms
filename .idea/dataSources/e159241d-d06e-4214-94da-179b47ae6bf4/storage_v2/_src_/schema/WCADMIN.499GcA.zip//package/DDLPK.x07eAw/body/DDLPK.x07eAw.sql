create PACKAGE BODY DDLPK IS
CURSOR GP_BASELINE_CURSOR(v_gpid NUMBER, v_baselineid NUMBER) IS
SELECT DISTINCT A0.IDA2A2 AS GPID, A1.IDA2A2 AS USAGEID, A2.NAME, A2.WTPARTNUMBER, A2.GENERICTYPE
FROM WTPART A0, WTPARTUSAGELINK A1, WTPARTMASTER A2, BASELINEMEMBER A3
WHERE (A1.idA3A5 = v_gpid) AND (A1.idA3B5 = A2.idA2A2) AND (A0.idA3masterReference = A2.idA2A2)
AND ((A3.idA3A5 = v_baselineid) AND (A0.idA2A2 = A3.idA3B5)) AND (A0.statecheckoutinfo IN ('c/i','wrk'));
CURSOR GP_STANDARD_CURSOR(v_gpid NUMBER, v_state VARCHAR2, v_viewid NUMBER) IS
SELECT DISTINCT A0.IDA2A2 AS GPID, A1.IDA2A2 AS USAGEID, A2.NAME, A2.WTPARTNUMBER, A2.GENERICTYPE
FROM WTPART A0, WTPARTUSAGELINK A1, WTPARTMASTER A2
WHERE (A1.idA3A5 = v_gpid) AND (A1.idA3B5 = A2.idA2A2) AND (A0.idA3masterReference = A2.idA2A2)
AND (A0.latestiterationInfo = 1) AND (A0.oneOffVersionIdA2oneOffVersi IS NULL)
AND (A0.statestate = NVL(v_state, A0.statestate)) AND (A0.statecheckoutinfo IN ('c/i','wrk'))
AND ((A0.viewIsNull IS NULL) OR (A0.idA3view = v_viewid) OR A0.idA3view IN (
select ida3a5 from viewassociation connect by prior ida3a5 = ida3b5 start with ida3b5 = v_viewid));
CURSOR GP_LATEST_ITERATION_CURSOR(v_gpid NUMBER) IS
SELECT DISTINCT A0.IDA2A2 AS GPID, A1.IDA2A2 AS USAGEID, A2.NAME, A2.WTPARTNUMBER, A2.GENERICTYPE
FROM WTPART A0, WTPARTUSAGELINK A1, WTPARTMASTER A2
WHERE (A1.idA3A5 = v_gpid) AND (A1.idA3B5 = A2.idA2A2) AND (A0.idA3masterReference = A2.idA2A2)
AND (A0.latestiterationInfo = 1) AND (A0.statecheckoutinfo IN ('c/i','wrk'));
CURSOR LOCATION_CURSOR(init_id NUMBER) IS
SELECT IDA3A5 AS ID, CLASSNAMEKEYROLEAOBJECTREF AS CLASSNAME FROM SUBFOLDERLINK
CONNECT BY PRIOR IDA3A5 = IDA3B5
START WITH IDA3B5 = init_id;
FUNCTION IS_GENERIC(part_type VARCHAR2) RETURN BOOLEAN IS
BEGIN
RETURN part_type = 'generic' or part_type = 'configurable_generic';
END IS_GENERIC;
FUNCTION TYPE_MATCH(type_id NUMBER, part_type VARCHAR2) RETURN BOOLEAN IS
BEGIN
RETURN type_id = ALL_PARTS or (type_id = GENERIC_PART and (part_type = 'generic' or part_type = 'configurable')) or (type_id = WT_PART and part_type = 'none');
END TYPE_MATCH;
FUNCTION EXISTS_IN_ARRAY(id NUMBER, usage_id NUMBER, array DDL_GP_LIST) RETURN BOOLEAN IS
BEGIN
FOR i IN 1..array.COUNT LOOP
IF array(i).part_id = id AND array(i).part_usage_id = usage_id THEN
RETURN true;
END IF;
END LOOP;
RETURN false;
END EXISTS_IN_ARRAY;
FUNCTION GET_SUBFOLDER(part_id NUMBER, classname VARCHAR2) RETURN VARCHAR2 IS
v_folder SUBFOLDER.NAME%TYPE := NULL;
BEGIN
IF classname = 'wt.folder.SubFolder' THEN
SELECT name
INTO v_folder
FROM SUBFOLDER
WHERE IDA2A2 = part_id;
ELSE
SELECT name
INTO v_folder
FROM CABINET
WHERE IDA2A2 = part_id;
END IF;
return TRIM(v_folder);
END GET_SUBFOLDER;
FUNCTION GET_PART_LOCATION(part_id NUMBER) RETURN VARCHAR2 IS
v_location VARCHAR2(400) := '';
v_init_location_id NUMBER;
v_folder SUBFOLDER.NAME%TYPE := '';
v_classname SUBFOLDERLINK.CLASSNAMEKEYROLEBOBJECTREF%TYPE := '';
BEGIN
SELECT B.IDA3A5
INTO v_init_location_id
FROM WTPART A, ITERFOLDERMEMBERLINK B
WHERE A.BRANCHIDITERATIONINFO = B.BRANCHIDA3B5 AND A.IDA2A2 = part_id;
FOR r_cursor IN LOCATION_CURSOR(v_init_location_id) LOOP
v_folder := GET_SUBFOLDER(r_cursor.ID, r_cursor.CLASSNAME);
v_location := '/' || TRIM(v_folder) || v_location;
END LOOP;
BEGIN
SELECT CLASSNAMEKEYROLEBOBJECTREF
INTO v_classname
FROM SUBFOLDERLINK
WHERE IDA3B5 = v_init_location_id;
EXCEPTION
WHEN NO_DATA_FOUND THEN
v_classname := 'wt.folder.Cabinet';
END;
v_folder := GET_SUBFOLDER(v_init_location_id, v_classname);
v_location := NVL(v_location, '') || '/' || v_folder;
RETURN v_location;
END GET_PART_LOCATION;
PROCEDURE GET_GPS_FOR_LATEST_ITERATION(gpid NUMBER, gps IN OUT DDL_GP_LIST,
level NUMBER, part_type NUMBER, cutoff_level NUMBER, compute_location NUMBER) IS
gp_children_list DDL_GP_LIST := DDL_GP_LIST();
v_location VARCHAR2(400) := '';
BEGIN
IF level > cutoff_level THEN
RETURN;
END IF;
FOR r_cursor IN GP_LATEST_ITERATION_CURSOR(gpid) LOOP
IF compute_location <> 0 THEN
v_location := GET_PART_LOCATION(r_cursor.GPID);
END IF;
gp_children_list.EXTEND;
gp_children_list(gp_children_list.COUNT) :=
DDL_GP_VALUE(r_cursor.GPID, r_cursor.USAGEID, 'wt.part.WTPart', v_location, level, r_cursor.name, r_cursor.wtpartnumber, r_cursor.generictype);
END LOOP;
FOR i IN 1..gp_children_list.COUNT LOOP
IF TYPE_MATCH(part_type, gp_children_list(i).part_type) and NOT EXISTS_IN_ARRAY(gp_children_list(i).part_id, gp_children_list(i).part_usage_id, gps) THEN
gps.EXTEND;
gps(gps.COUNT) := gp_children_list(i);
END IF;
IF IS_GENERIC(gp_children_list(i).part_type) THEN
GET_GPS_FOR_LATEST_ITERATION(gp_children_list(i).part_id, gps, level + 1, part_type, cutoff_level, compute_location);
END IF;
END LOOP;
END GET_GPS_FOR_LATEST_ITERATION;
PROCEDURE GET_GPS_FOR_STANDARD_SPEC(gpid NUMBER, state VARCHAR2, viewid NUMBER, gps IN OUT DDL_GP_LIST,
level NUMBER, part_type NUMBER, cutoff_level NUMBER, compute_location NUMBER) IS
gp_children_list DDL_GP_LIST := DDL_GP_LIST();
v_location VARCHAR2(400) := '';
BEGIN
IF level > cutoff_level THEN
RETURN;
END IF;
FOR r_cursor IN GP_STANDARD_CURSOR(gpid, state, viewid) LOOP
IF compute_location <> 0 THEN
v_location := GET_PART_LOCATION(r_cursor.GPID);
END IF;
gp_children_list.EXTEND;
gp_children_list(gp_children_list.COUNT) :=
DDL_GP_VALUE(r_cursor.GPID, r_cursor.USAGEID, 'wt.part.WTPart', v_location, level, r_cursor.name, r_cursor.wtpartnumber, r_cursor.generictype);
END LOOP;
FOR i IN 1..gp_children_list.COUNT LOOP
IF TYPE_MATCH(part_type, gp_children_list(i).part_type) and NOT EXISTS_IN_ARRAY(gp_children_list(i).part_id, gp_children_list(i).part_usage_id, gps) THEN
gps.EXTEND;
gps(gps.COUNT) := gp_children_list(i);
END IF;
IF IS_GENERIC(gp_children_list(i).part_type) THEN
GET_GPS_FOR_STANDARD_SPEC(gp_children_list(i).part_id, state, viewid, gps,
level + 1, part_type, cutoff_level, compute_location);
END IF;
END LOOP;
END GET_GPS_FOR_STANDARD_SPEC;
PROCEDURE GET_GPS_FOR_BASELINE_SPEC(gpid NUMBER, baselineid NUMBER, gps IN OUT DDL_GP_LIST,
level NUMBER, part_type NUMBER, cutoff_level NUMBER, compute_location NUMBER) IS
gp_children_list DDL_GP_LIST := DDL_GP_LIST();
v_location VARCHAR2(400) := '';
BEGIN
IF level > cutoff_level THEN
RETURN;
END IF;
FOR r_cursor IN GP_BASELINE_CURSOR(gpid, baselineid) LOOP
IF compute_location <> 0 THEN
v_location := GET_PART_LOCATION(r_cursor.GPID);
END IF;
gp_children_list.EXTEND;
gp_children_list(gp_children_list.COUNT) :=
DDL_GP_VALUE(r_cursor.GPID, r_cursor.USAGEID, 'wt.part.WTPart', v_location, level, r_cursor.name, r_cursor.wtpartnumber, r_cursor.generictype);
END LOOP;
FOR i IN 1..gp_children_list.COUNT LOOP
IF TYPE_MATCH(part_type, gp_children_list(i).part_type) and NOT EXISTS_IN_ARRAY(gp_children_list(i).part_id, gp_children_list(i).part_usage_id, gps) THEN
gps.EXTEND;
gps(gps.COUNT) := gp_children_list(i);
END IF;
IF IS_GENERIC(gp_children_list(i).part_type) THEN
GET_GPS_FOR_BASELINE_SPEC(gp_children_list(i).part_id, baselineid, gps,
level + 1, part_type, cutoff_level, compute_location);
END IF;
END LOOP;
END GET_GPS_FOR_BASELINE_SPEC;
PROCEDURE GET_GPS_FOR_EFFECTIVITY_SPEC(gpid NUMBER, gps IN OUT DDL_GP_LIST,
level NUMBER, part_type NUMBER, cutoff_level NUMBER, compute_location NUMBER) IS
v_location VARCHAR2(400) := '';
BEGIN
NULL;
END GET_GPS_FOR_EFFECTIVITY_SPEC;
FUNCTION GET_TOP_PART_INFO(gpid NUMBER, compute_location NUMBER) RETURN DDL_GP_VALUE IS
v_part_name WTPARTMASTER.NAME%TYPE;
v_part_number WTPARTMASTER.WTPARTNUMBER%TYPE;
v_type WTPARTMASTER.GENERICTYPE%TYPE;
v_location VARCHAR2(400) := '';
BEGIN
SELECT B.NAME, B.WTPARTNUMBER, B.GENERICTYPE
INTO v_part_name, v_part_number, v_type
FROM WTPART A, WTPARTMASTER B
WHERE A.IDA3MASTERREFERENCE = B.IDA2A2
AND A.ida2a2 = gpid;
IF compute_location <> 0 THEN
v_location := GET_PART_LOCATION(gpid);
END IF;
RETURN DDL_GP_VALUE(gpid, NULL, 'wt.part.WTPart', v_location, 0, v_part_name, v_part_number, v_type);
END GET_TOP_PART_INFO;
FUNCTION GET_GP_CHILDREN(gpid NUMBER, configspecid NUMBER, part_type NUMBER,
cutoff_level NUMBER, compute_location NUMBER) RETURN DDL_GP_LIST IS
gplist DDL_GP_LIST := DDL_GP_LIST();
v_effectivityactive NUMBER(1) := 0;
v_baselineactive NUMBER(1) := 0;
v_standardactive NUMBER(1) := 0;
v_viewid NUMBER := 0;
v_baselineid NUMBER := 0;
v_state VARCHAR2(200) := NULL;
BEGIN
IF configspecid = -1 THEN
GET_GPS_FOR_LATEST_ITERATION(gpid, gplist, 1, part_type, cutoff_level, compute_location);
ELSE
SELECT EFFECTIVITYACTIVE, STANDARDACTIVE, BASELINEACTIVE, LIFECYCLESTATEA5, IDA3A2A5, IDA3A2B5
INTO v_effectivityactive, v_standardactive, v_baselineactive, v_state, v_viewid, v_baselineid
FROM WTPARTCONFIGSPEC
WHERE IDA2A2 = configspecid;
IF v_standardactive = 1 THEN
GET_GPS_FOR_STANDARD_SPEC(gpid, v_state, v_viewid, gplist, 1, part_type, cutoff_level, compute_location);
ELSIF v_baselineactive = 1 THEN
GET_GPS_FOR_BASELINE_SPEC(gpid, v_baselineid, gplist, 1, part_type, cutoff_level, compute_location);
ELSE
GET_GPS_FOR_EFFECTIVITY_SPEC(gpid, gplist, 1, part_type, cutoff_level, compute_location);
END IF;
END IF;
RETURN gplist;
END GET_GP_CHILDREN;
FUNCTION GET_GP_TREE(gpid NUMBER, configspecid NUMBER, part_type NUMBER,
cutoff_level NUMBER, compute_location NUMBER) RETURN DDL_GP_LIST IS
gp_children_list DDL_GP_LIST;
top_part_info DDL_GP_VALUE;
BEGIN
gp_children_list := GET_GP_CHILDREN(gpid, configspecid, part_type, cutoff_level, compute_location);
gp_children_list.extend();
top_part_info := GET_TOP_PART_INFO(gpid, compute_location);
FOR i IN REVERSE 2..gp_children_list.COUNT LOOP
gp_children_list(i) := gp_children_list(i - 1);
END LOOP;
gp_children_list(1) := top_part_info;
RETURN gp_children_list;
END GET_GP_TREE;
PROCEDURE PRINT_GP_STRUCTURE(gp_list DDL_GP_LIST, show_details NUMBER, buffer_size NUMBER) IS
v_result VARCHAR2(200);
v_class_name VARCHAR2(11);
BEGIN
--dbms_output.enable(buffer_size);
FOR i IN 1..gp_list.COUNT LOOP
--dbms_output.put_line(gp_list(i).part_name || ':' || gp_list(i).part_number || ', ' || gp_list(i).part_classname);
v_result := gp_list(i).part_name || ':' || gp_list(i).part_number;
IF show_details <> 0 THEN
v_class_name := replace(replace(gp_list(i).part_classname, 'com.ptc.wpcfg.family.', ''), 'wt.part.', '');
--v_class_name := gp_list(i).part_classname;
v_result := v_result || ': ' || v_class_name || ' in ' || gp_list(i).part_location ||
', id=' || gp_list(i).part_id || ', usageid=' || gp_list(i).part_usage_id;
END IF;
dbms_output.put_line(rpad('>', 2 * gp_list(i).part_level) || v_result);
END LOOP;
END PRINT_GP_STRUCTURE;
PROCEDURE PRINT_GP_CHILDREN(gpid NUMBER, configspecid NUMBER, part_type NUMBER,
cutoff_level NUMBER, show_details NUMBER, buffer_size NUMBER) IS
gp_children_list DDL_GP_LIST;
BEGIN
gp_children_list := GET_GP_CHILDREN(gpid, configspecid, part_type, cutoff_level, show_details);
PRINT_GP_STRUCTURE(gp_children_list, show_details, buffer_size);
END PRINT_GP_CHILDREN;
PROCEDURE PRINT_GP_TREE(gpid NUMBER, configspecid NUMBER, part_type NUMBER,
cutoff_level NUMBER, show_details NUMBER, buffer_size NUMBER) IS
gp_children_list DDL_GP_LIST;
BEGIN
gp_children_list := GET_GP_TREE(gpid, configspecid, part_type, cutoff_level, show_details);
PRINT_GP_STRUCTURE(gp_children_list, show_details, buffer_size);
END PRINT_GP_TREE;
END DDLPK;
/

