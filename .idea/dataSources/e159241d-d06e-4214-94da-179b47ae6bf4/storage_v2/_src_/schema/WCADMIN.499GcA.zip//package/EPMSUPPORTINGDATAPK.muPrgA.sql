create PACKAGE EPMSupportingDataPK IS
FUNCTION CopyEpmSupportingData(source_epm_supporting_data IN TABLE_OF_NUMBER , holder_object IN OID_OBJECT) RETURN OID_OBJECT_LIST;
FUNCTION saveEPMSupportingData(epm_supporting_data IN TABLE_OF_EPM_SUPPORTING_INFO, NumblobsToUse IN TABLE_OF_NUMBER, blobDataList IN RAW_OBJECT_LIST) RETURN OID_OBJECT_LIST;
FUNCTION removeEPMSupportingData(epm_supporting_data IN TABLE_OF_NUMBER) RETURN NUMBER;
FUNCTION CopySupportingData(sourceSupportingdata IN TABLE_OF_NUMBER , holderObjects IN OID_OBJECT_LIST, changeDataHolderToUse IN TABLE_OF_NUMBER) RETURN OID_OBJECT_LIST;
END EPMSupportingDataPK;
/

