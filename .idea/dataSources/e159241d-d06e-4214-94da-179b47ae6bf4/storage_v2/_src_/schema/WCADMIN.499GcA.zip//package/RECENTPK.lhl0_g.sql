create PACKAGE RecentPK IS
PROCEDURE DeleteOldestFromList(keepItems IN NUMBER);
END RecentPK;
/

