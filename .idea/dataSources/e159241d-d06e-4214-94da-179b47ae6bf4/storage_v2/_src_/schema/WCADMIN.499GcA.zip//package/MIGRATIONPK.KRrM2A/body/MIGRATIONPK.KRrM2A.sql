create PACKAGE BODY MigrationPK IS

Procedure cwpRegisverPIPIV (WCDBLinkName VARCHAR2, ildomainid varchar2);

  TYPE ArrayVarcharV6 IS TABLE of varchar2(600) INDEX BY varchar2(600);
--  TYPE ArrayNumber    IS TABLE of NUMBER       INDEX BY BINARY_INTEGER;
  TYPE ArrayVarchar200 IS TABLE of VARCHAR2(200) INDEX BY BINARY_INTEGER;
  TYPE ArrayVarchar150 IS TABLE of VARCHAR2(150) INDEX BY BINARY_INTEGER;
  TYPE ArrayVarchar6000 IS TABLE of VARCHAR2(6000) INDEX BY BINARY_INTEGER;
  TYPE ArrayDate      IS TABLE of DATE         INDEX BY BINARY_INTEGER;
  TYPE ArrayVarchar4000 IS TABLE of VARCHAR2(4000) INDEX BY BINARY_INTEGER;
  TYPE RefCur              IS REF CURSOR;
  TYPE ArrayNumberV2 IS TABLE of number INDEX BY varchar2(200);

  object_missing EXCEPTION;
  NULL_EXCPETION CONSTANT      NUMBER := -20001;
  gbl_curr_seq_id NUMBER := 0;
  gbl_end_seq_id NUMBER := 1;

-- link types (should match with ILDep.java and ILObject.java)
MEMBER_LINK      CONSTANT      NUMBER := 0;
REFERENCE_LINK    CONSTANT      NUMBER := 1;

EPMDOCTYPE        CONSTANT      NUMBER := 0;
WTDOCTYPE         CONSTANT              NUMBER := 1;
SECDOCTYPE         CONSTANT              NUMBER := 2;

SKELETON_MEMB_DEP CONSTANT NUMBER := 1;
-- from EPMNDConst.java
--    public static final int EPMND_VALUE_TYPE_Boolean = 1;
--    public static final int EPMND_VALUE_TYPE_Integer = 2;
--    public static final int EPMND_VALUE_TYPE_Real    = 3;
--    public static final int EPMND_VALUE_TYPE_String  = 4;
--    public static final int EPMND_VALUE_TYPE_Time    = 5;
WCBOOLTYPE        CONSTANT      number := 1;
WCINTTYPE        CONSTANT      number := 2;
WCFLOATTYPE        CONSTANT      number := 3;
WCSTRTYPE        CONSTANT      number := 4;
WCDATETYPE        CONSTANT      number := 5;

-- database values of parametervaluetype are from ilapi/proilcommon/inc/attrval.h
-- whereas the capi values are slightly different
-- we are getting data directly from database so using those values
--enum PDME_AttributeType {
--  PDME_AT_Null      =  0, // Attributes that just exist but have no value
--                          // This type is used only for passing NULL values
--  PDME_AT_Any       =  1, // Attribute type is not statically known or
--                          // not expressible (system attributes only).
--  PDME_AT_Integer   =  2, // integer (32-bit value)
--  PDME_AT_Real      =  3, // floating-point
--  PDME_AT_Boolean   =  4, // boolean
--  PDME_AT_String    =  5, // string
--  PDME_AT_DateTime  =  6, // date
--  PDME_AT_RelSingle =  7, // to one relationship
--  PDME_AT_RelMany   =  8, // to many relationship
--  PDME_AT_Byte      =  9, // byte (8-bit value)
--  PDME_AT_Long      = 10, // long (64-bit value)
--  PDME_AT_ObjectId  = 11, // DBId (48-bit value)
--  PDME_AT_DomainId  = 12, // DomainDBId (string)
--  PDME_AT_Password  = 13, // password stored as a string
--
--  PDME_AT_LDBObject = 99  // LDB object
--};


ILTKINTTYPE        CONSTANT      number := 2;
ILTKFLOATTYPE        CONSTANT      number := 3;
ILTKBOOLTYPE        CONSTANT      number := 4;
ILTKSTRTYPE        CONSTANT      number := 5;
ILTKDATETYPE        CONSTANT      number := 6;
-- and feature value types are used from
-- and from ila/ilacomm/inc/ilavalue.h
--enum ilaValueType
--{
--  ilaVTNone,
--  ilaVTInteger,
--  ilaVTFloat,
--  ilaVTString,
--  ilaVTDate,
--  ilaVTDateTime, Do not use this id.  Only use ilaVTDate. This is here just f
--  or backward compatibility.
--  ilaVTBoolean,
--  ilaVTIcon
--};
ILAINTTYPE        CONSTANT      number := 1;
ILAFLOATTYPE        CONSTANT      number := 2;
ILASTRTYPE        CONSTANT      number := 3;
ILADATETYPE        CONSTANT      number := 4;
ILABOOLTYPE        CONSTANT      number := 6;

MIGRATION_CANNOTDO      CONSTANT   NUMBER := 4;
MIGRATION_INCOMPLETE       CONSTANT   NUMBER := 13;
MIGRATION_SUCCESS       CONSTANT   NUMBER := 1;
MIGRATION_REPLICA_SUCCESS       CONSTANT   NUMBER := 10;
MIGRATION_UNFINISHED    CONSTANT   NUMBER := 3;
MIGRATION_UPDATING      CONSTANT   number := 5;
MIGRATION_HOLES_AND_UPDATING CONSTANT number := 6;
MIGRATION_HOLES         CONSTANT    number := 7;
MIG_UNDECIDED           CONSTANT number := 11;  -- from ILObject.java
MIGRATION_WILL_NOT_MIGRATE       CONSTANT   NUMBER := 15;

-- from ilbasicloader.java
DEP_CREATE CONSTANT NUMBER := 0;
DEP_UPDATE CONSTANT NUMBER := 1;
SKEL_MODEL CONSTANT VARCHAR2(10) := 'SKEL_MODEL';

-- duplicate status bits from MergeStatus.java
-- public final static int INIT                    = 0x200; //insignificant bit
-- public final static int VALID                   =   0x1;
-- public final static int USER_MODIFIED           =   0x2;
-- public final static int CHECK_FOR_EQUALITY      =   0x4;
-- public final static int EQUAL                   =   0x8;
-- public final static int MARKED_FOR_MERGE        =  0x10;
-- public final static int UNEQUAL                 =  0x20;
-- public final static int MARKED_FOR_DELETE       =  0x40;
-- public final static int MARKED_OTHER_UPDATE     =  0x80;
-- public final static int MARKED_SERIES_UPDATE    = 0x100;

  VALID_FLAG CONSTANT number := 1;
  CHECK_FOR_EQUALITY_FLAG CONSTANT number := 4;
-- the program is starting with 0x200 = 512. Just to be safe I created the NOT of check for equality flag based on 1024
-- so NOT_CHECK_FOR_EQUALITY_FLAG = 11 1111 1011 = 1023 - 4 = 1019
  NOT_CHECK_FOR_EQUALITY_FLAG CONSTANT number := 1019;
  EQUAL_FLAG CONSTANT number := 8;
-- similarly NOT_EQUAL_FLAG = 11 1111 0111 = 1023 - 8 = 1015
  NOT_EQUAL_FLAG CONSTANT number := 1015;
  UNEQUAL_FLAG CONSTANT number := 32;
-- similarly NOT_UNEQUAL_FLAG = 11 1101 1111 = 1023 - 32 = 991;
  NOT_UNEQUAL_FLAG CONSTANT number := 991;

  MARKED_FOR_MERGE_FLAG CONSTANT number := 16;
  MARKED_FOR_DELETE_FLAG CONSTANT NUMBER := 64;

  FUNCTION getEPMDocumentMaster(piId_ NUMBER, domainId_ NUMBER) RETURN NUMBER IS
    CURSOR C1 IS
      select EPMDocumentMasterId
      from PItoWCStatus
      where piId = piId_ and domainId = domainId_ and DocumentType = 0;

    doc_id PItoWCStatus.EPMDocumentMasterId%TYPE := NULL;
  BEGIN
--    putpipe('Getting master for piid: '||piid_);
    OPEN C1;  FETCH C1 INTO doc_id;  CLOSE C1;

    IF doc_id is NULL THEN
--      putpipe ('doc_mid is null');
      raise object_missing;
    END IF;

--    putpipe('doc_mid is: '||doc_id);

    RETURN doc_id;
  END getEPMDocumentMaster;
  ----------------------------------------------------------------------------------
  FUNCTION getEPMDocument(pivId_ NUMBER, domainId_ NUMBER) RETURN NUMBER IS
    CURSOR C1 IS
      select EPMDocumentId
      from PIVtoWCStatus
      where pivId = pivId_ and domainId = domainId_ and DocumentType = 0;

    doc_id PIVtoWCStatus.EPMDocumentId%TYPE := NULL;
  BEGIN
--    putpipe('Getting document for pivid: '||pivid_);
    OPEN C1;  FETCH C1 INTO doc_id;  CLOSE C1;

    IF doc_id is NULL THEN
--      putpipe ('doc_id is null');
      raise object_missing;
    END IF;
--    putpipe('doc_id is: '||doc_id);

    RETURN doc_id;
  END getEPMDocument;
 ----------------------------------------------------------------------------------

  PROCEDURE getEPMDocumentBasedOnMigSt(pivId_ IN NUMBER, domainId_ IN NUMBER, docId OUT number, status out number) IS
    CURSOR C1 IS
      select status,EPMDocumentId
      from PIVtoWCStatus
      where pivId = pivId_ and domainId = domainId_ and DocumentType = 0;
  BEGIN
--    putpipe('Getting document for pivid: '||pivid_);
    OPEN C1;  FETCH C1 INTO status, docId;  CLOSE C1;
--    putpipe('doc_id is: '||doc_id);

  END getEPMDocumentBasedOnMigSt;

  ----------------------------------------------------------------------------------

  PROCEDURE getEPMDocumentWithTimeStamp(pivId_ IN NUMBER,
                                        domainId_ IN NUMBER,
                                        docId IN OUT number,
                                        crStamp IN OUT date,
                                        modStamp IN OUT date) IS
    CURSOR C1 IS
      select st.EPMDocumentId, doc.CREATESTAMPA2, doc.MODIFYSTAMPA2
      from PIVtoWCStatus st, epmdocument doc
      where pivId = pivId_ and domainId = domainId_ and DocumentType = 0 and st.epmdocumentid = doc.ida2a2;

  BEGIN
--    putpipe('Getting document for pivid: '||pivid_);
    OPEN C1;  FETCH C1 INTO docId, crStamp, modStamp;  CLOSE C1;

    IF docId is NULL THEN
--      putpipe ('doc_id is null');
      raise object_missing;
    END IF;
--    putpipe('doc_id is: '||doc_id);

  END getEPMDocumentWithTimeStamp;
  ----------------------------------------------------------------------------------
  FUNCTION getFamTabMasterId(loId_ NUMBER, domainId_ number) RETURN NUMBER IS
    CURSOR C1 IS
      select EPMSepFamilytableMasterId
      from LOtoWCStatus
      where loid = loId_ and domainId = domainId_ ;

    doc_id LOtoWCStatus.EPMSepFamilytableMasterId%TYPE := NULL;
  BEGIN
    OPEN C1;  FETCH C1 INTO doc_id;  CLOSE C1;

--    putpipe('Getting document for loid: '||loid_);

    IF doc_id is NULL THEN
--      putpipe ('doc_id is null');
      raise object_missing;
    END IF;
--    putpipe('doc_id is: '||doc_id);

    RETURN doc_id;
  END getFamTabMasterId;
  ----------------------------------------------------------------------------------
  FUNCTION getFamTabId(lovId_ NUMBER, domainId_ number) RETURN NUMBER IS
    CURSOR C1 IS
      select EPMSepFamilytableId
      from LOVtoWCStatus
      where lovid = lovId_ and domainId = domainId_ ;

    doc_id LOVtoWCStatus.EPMSepFamilytableId%TYPE := NULL;
  BEGIN
    OPEN C1;  FETCH C1 INTO doc_id;  CLOSE C1;
--    putpipe('Getting document for lovid: '||lovid_);

    IF doc_id is NULL THEN
--      putpipe ('doc_id is null');
      raise object_missing;
    END IF;
--    putpipe('doc_id is: '||doc_id);

    RETURN doc_id;
  END getFamTabId;
  ----------------------------------------------------------------------------------
  FUNCTION getContainedInId(lovid_ NUMBER, pivid_ number, domainId_ number) RETURN NUMBER IS
    CURSOR C1 IS
      select EPMContainedInId
      from ContainedInLinks
      where lovid = lovid_ and pivid = pivid_ and domainId = domainId_ ;

    doc_id ContainedInLinks.EPMContainedInId%TYPE := NULL;
  BEGIN
    OPEN C1;  FETCH C1 INTO doc_id;  CLOSE C1;

--    putpipe('Getting linkid for lov: '||lovid_||' and pivid: '||pivid_);
    IF doc_id is NULL THEN
--      putpipe ('doc_id is null');
      raise object_missing;
    END IF;
--    putpipe('doc_id is: '||doc_id);

    RETURN doc_id;
  END getContainedInId;
  ----------------------------------------------------------------------------------
 FUNCTION getUniqueNDId(dgid_ NUMBER,  domainId_ number,linkType_ number) RETURN varchar2 IS
      CURSOR C1_member IS
      select mb.uniquendid
      from deptowcstatus dep, epmmemberlink mb
      where dep.dgid=dgid_  and dep.epmlinkid=mb.ida2a2 and dep.domainid=domainId_ ;

      CURSOR C1_reference IS
      select mb.uniquendid
      from deptowcstatus dep, epmreferencelink mb
      where dep.dgid=dgid_  and dep.epmlinkid=mb.ida2a2 and dep.domainid=domainId_;
      uniquend_id  varchar2(200) := NULL;
  BEGIN
   if dgid_<=0 then
      return uniquend_id;
   end if;
   if linkType_=MEMBER_LINK then
    OPEN C1_member;   FETCH C1_member INTO uniquend_id; CLOSE C1_member;
   else   --linkType_=REFERENCE_LINK
    OPEN C1_reference;   FETCH C1_reference INTO uniquend_id;  CLOSE C1_reference;
   end if;
--    putpipe('Getting linkid for lov: '||lovid_||' and pivid: '||pivid_);
    IF uniquend_id is NULL THEN
--      putpipe ('doc_id is null');
      raise object_missing;
    END IF;
--    putpipe('doc_id is: '||doc_id);

    RETURN uniquend_id;
  exception when object_missing then
     raise;
  END getUniqueNDId;


  ----------------------------------------------------------------------------------
  FUNCTION getDepType(dgid_ NUMBER, domainId_ number) RETURN number IS
    CURSOR C1 IS
      select linktype
      from deptowcstatus
      where dgid = dgid_ and domainId = domainId_ ;

    link_type number := NULL;
  BEGIN
    OPEN C1;  FETCH C1 INTO link_type;  CLOSE C1;

--    putpipe('Getting linkid for dgid: '||dgid_);
    IF link_type is NULL THEN
--      putpipe ('link_type is null');
      raise object_missing;
    END IF;
--    putpipe('link_type is: '||link_type);

    RETURN link_type;
  END getDepType;
  ----------------------------------------------------------------------------------
  FUNCTION getFeatureValType( ilType number ) RETURN number IS

  BEGIN
    if ilType = ILAINTTYPE then
      return WCINTTYPE;
    elsif ilType = ILAFLOATTYPE then
      return WCFLOATTYPE;
    elsif ilType = ILASTRTYPE then
      return WCSTRTYPE;
    elsif ilType = ILABOOLTYPE then
      return WCBOOLTYPE;
    elsif ilType = ILADATETYPE then
      return WCDATETYPE;
    end if;
  END getFeatureValType;
  ----------------------------------------------------------------------------------
  FUNCTION getPIIPValType( ilType number ) RETURN number IS

  BEGIN
    if ilType = ILTKINTTYPE then
      return WCINTTYPE;
    elsif ilType = ILTKFLOATTYPE then
      return WCFLOATTYPE;
    elsif ilType = ILTKSTRTYPE then
      return WCSTRTYPE;
    elsif ilType = ILTKBOOLTYPE then
      return WCBOOLTYPE;
    elsif ilType = ILTKDATETYPE then
      return WCDATETYPE;
    end if;
  END getPIIPValType;

  ----------------------------------------------------------------------------------
  PROCEDURE filterLOs ( IlinkDomainId VARCHAR2,
                       loIDs TABLE_OF_NUMBER,
                       lovsPerLOCount TABLE_OF_NUMBER,
                       lovIDs TABLE_OF_NUMBER,

                       topGenericPIVIDs TABLE_OF_NUMBER,
                       cisPerLOVCount TABLE_OF_NUMBER,
                       containedPIVIDs TABLE_OF_NUMBER,
                       varsPerLOVCount TABLE_OF_NUMBER,
                       genericPIIDs TABLE_OF_NUMBER,
                       variantPIVIDs TABLE_OF_NUMBER,
                       existingLOIdArr OUT TABLE_OF_NUMBER,
                       existingFTMasterIdArr OUT TABLE_OF_NUMBER,
                       ignoredLOVIds OUT TABLE_OF_NUMBER ) IS

    cursor famTabMaster_for_topGen (cv_docId number) IS
      SELECT ft.IDA3MASTERREFERENCE
        FROM epmcontainedin cont, epmsepfamilytable ft, epmdocument d1, epmdocument d2
       WHERE d2.ida2a2 = cv_docId
         and d2.IDA3MASTERREFERENCE = d1.IDA3MASTERREFERENCE
         and d2.FAMILYTABLESTATUS = d1.FAMILYTABLESTATUS
         and cont.ida3a5 = d1.ida2a2
         and cont.ida3b5 = ft.ida2a2;

    curr_lo_idx    NUMBER := 0; curr_lov_idx   NUMBER := 0;
    last_ci_idx number := 0; last_var_idx number := 0;
    curr_loid number; curr_lovid number;
    curr_ci_idx   NUMBER := 0; curr_var_idx   NUMBER := 0;
    status NUMBER := 0;

    ilDomainId NUMBER := to_number(IlinkDomainId);
    lov_status NUMBER; i NUMBER; j NUMBER;
    topGenEPMDoc number := 0; containedEPMDoc number := 0; variantEPMDoc number := 0; variantEPMDocM number := 0;
    firstLOV boolean := false; loFTMasterCt number := 0; ftMasterId number;
    ignoreAndMarkAsCannodDoLOVIds TABLE_OF_NUMBER := TABLE_OF_NUMBER();
    -- 801=Cannot migrate this lov because at least one of its FT members is not migratable.
    n_errid number :=801;


  BEGIN
--  putpipe('----- Starting SP filterLOs--- '||to_char(sysdate,'hh24:mi:ss'));
--  putpipe('LOIDs count is '||LOIDs.count);
--  putpipe('LOVIDs count is '||LOVIDs.count);
    existingLOIdArr := TABLE_OF_NUMBER();
    existingFTMasterIdArr := TABLE_OF_NUMBER();
    ignoredLOVIds := TABLE_OF_NUMBER();

    existingLOIdArr.delete;
    existingFTMasterIdArr.delete;
    ignoredLOVIds.delete;
    ignoreAndMarkAsCannodDoLOVIds.delete;

    if loIDs.count>0 then

    FOR curr_lo_idx IN loIDs.FIRST..loIDs.LAST LOOP
      curr_loid := loIDs(curr_lo_idx);
      firstLOV := true;
      FOR i IN 1..lovsPerLOCount(curr_lo_idx) LOOP
        last_ci_idx := curr_ci_idx;
        last_var_idx := curr_var_idx;
        BEGIN
          curr_lov_idx := curr_lov_idx + 1;

         -- find if the lov is already migrated
          select max(status) into lov_status from LOVtoWCStatus
           where LOVId = lovIDs(curr_lov_idx) and domainId = ilDomainId;

          IF lov_status is NULL THEN  -- This LOV hasn't been processed yet
--            putpipe('lovstatus is null for lovid '||lovIDs(curr_lov_idx));

            curr_lovid := lovIDs(curr_lov_idx);
            topGenEPMDoc := getEPMDocument(topGenericPIVIDs(curr_lov_idx), ilDomainId);

            if firstLOV then
              -- find if the LO for this LOV is already in Windchill and get its ida2a2
              firstLOV := false;
              ftMasterId := null;
              open famTabMaster_for_topGen(topGenEPMDoc);
              fetch famTabMaster_for_topGen into ftMasterId;
              close famTabMaster_for_topGen;
              if ftMasterId is not null then
                loFTMasterCt := loFTMasterCt + 1;
                existingLOIdArr.extend();
                existingFTMasterIdArr.extend();
                existingLOIdArr(loFTMasterCt) := curr_loid;
                existingFTMasterIdArr(loFTMasterCt) := ftMasterId;
              end if;
            end if;


            FOR j IN 1..cisPerLOVCount(curr_lov_idx) LOOP
              curr_ci_idx := curr_ci_idx + 1;
              --commet out the old one              containedEPMDoc := getEPMDocument(containedPIVIDs(curr_ci_idx), ilDomainId);
              getEPMDocumentBasedOnMigSt(containedPIVIDs(curr_ci_idx), ilDomainId, containedEPMDoc, status);

              IF status = 4 THEN
                --remove from the filtered list / add to ignoredLOVIds
                --Insert LOV in LOVtoStatus with status as 4 and errMsg as "at least one FT member not migrateable"
                ignoredLOVIds.extend();
                ignoredLOVIds(ignoredLOVIds.COUNT) := curr_lovid;
                ignoreAndMarkAsCannodDoLOVIds.extend();
                ignoreAndMarkAsCannodDoLOVIds(ignoreAndMarkAsCannodDoLOVIds.COUNT) := curr_lovid;
              -- do insert here
              -- sqlstmt := 'insert into lovtowcstatus (lovid, domainid, status) ' ||'values('||curr_lovid||', '||ilDomainId||', '||status||')';
              -- execute immediate sqlstmt;
              elsif containedEPMDoc is null  then
                --remove from the filtered list / add to ignoredLOVIds
                ignoredLOVIds.extend();
                ignoredLOVIds(ignoredLOVIds.COUNT) := curr_lovid;
              END IF;
            END LOOP;

            FOR j IN 1..varsPerLOVCount(curr_lov_idx) LOOP
              curr_var_idx := curr_var_idx + 1;
              variantEPMDocM := getEPMDocumentMaster(genericPIIDs(curr_var_idx), ilDomainId);
              variantEPMDoc := getEPMDocument(variantPIVIDs(curr_var_idx), ilDomainId);
            END LOOP;


          ELSE
--            putpipe('lov '||curr_lov_idx||' already migrated');
            -- need to ignore this lov so move over its cis and vars
            ignoredLOVIds.extend();
            ignoredLOVIds(ignoredLOVIds.COUNT) := curr_lovid;
            curr_ci_idx := curr_ci_idx + cisPerLOVCount(curr_lov_idx);
            curr_var_idx := curr_var_idx + varsPerLOVCount(curr_lov_idx);
          END IF;

          forall j in ignoreAndMarkAsCannodDoLOVIds.first..ignoreAndMarkAsCannodDoLOVIds.last
            insert into lovtowcstatus (lovid, domainid, status,errid, errmsg ) values (ignoreAndMarkAsCannodDoLOVIds(j), ilDomainId, 4,n_errid, 'at least one FT member not migrateable');


        EXCEPTION
          WHEN others THEN -- In this case we skip to the next LOV
--            putpipe('exception occured for lo '||LOIDs(curr_lo_idx)||' and lovid '||LOVIDs(curr_lov_idx));
--            putpipe('sqlcode '||SQLCODE);
--            putpipe('sql error message '||SQLERRM);
            -- curr_lov_idx is the lov we want to ignore
            -- so lets move over its cis and vars
            ignoredLOVIds.extend();
            ignoredLOVIds(ignoredLOVIds.COUNT) := curr_lovid;
            curr_ci_idx := last_ci_idx + cisPerLOVCount(curr_lov_idx);
            curr_var_idx := last_var_idx + varsPerLOVCount(curr_lov_idx);
--          putpipe('lovidx: '||curr_lov_idx||' ciidx: '||curr_ci_idx||' varidx: '||curr_var_idx);

        END;
      END LOOP;
    END LOOP;
    end if;
  END filterLOs;

  ----------------------------------------------------------------------------------
 FUNCTION insertLOs(containedType VARCHAR2,
                     epmDocumentClassName VARCHAR2,
                     epmDocumentMasterClassName VARCHAR2,
                     containedLinkClassName VARCHAR2,
                     variantLinkClassName VARCHAR2,
                     epmSepFTClassName VARCHAR2,
                     authAppVerClassName VARCHAR2,
                     adminDomainClassName VARCHAR2,

                     IlinkDomainId VARCHAR2,
                     lovLoaderSize number,
                     isLastrow number,
                     loIDs TABLE_OF_NUMBER,
                     ftmIDs TABLE_OF_NUMBER,
                     lovsPerLOCount TABLE_OF_NUMBER,
                     lovIDs TABLE_OF_NUMBER,
                     ftIDs TABLE_OF_NUMBER,
                     appVerIDs TABLE_OF_NUMBER,
                     appVerBools TABLE_OF_NUMBER,
                     lovCreatedOn TABLE_OF_DATE,
                     lovModifiedOn TABLE_OF_DATE,

                     topGenericPIVIDs TABLE_OF_NUMBER,
                     fileIds TABLE_OF_NUMBER,
                     fileNames uzy_mig_TABLE_OF_VARCHAR2_200,
                     fileSizes TABLE_OF_NUMBER,
                     fsHosts uzy_mig_TABLE_OF_VARCHAR2_200,
                     fsPorts TABLE_OF_NUMBER,
                     fpPaths TABLE_OF_VARCHAR2,
                     fMapNames uzy_mig_TABLE_OF_VARCHAR2_200,
                     categories uzy_mig_TABLE_OF_VARCHAR2_200,

                     cisPerLOVCount TABLE_OF_NUMBER,
                     containedPIVIDs TABLE_OF_NUMBER,
                     instanceStoredName UZY_MIG_TABLE_OF_VARCHAR2_200,
                     verStatuses TABLE_OF_NUMBER,
                     lockStatuses TABLE_OF_NUMBER,
                     varsPerLOVCount TABLE_OF_NUMBER,
                     genericPIIDs TABLE_OF_NUMBER,
                     variantPIVIDs TABLE_OF_NUMBER,
                     replicaLOVIDs TABLE_OF_NUMBER, replicaLOIDs TABLE_OF_NUMBER) RETURN NUMBER IS

    cursor lostatus (cv_loid number, cv_domainid number) IS
       select count(loid), sum( decode( status, MIGRATION_INCOMPLETE,1,0))
          from lotowcstatus
       where loid = cv_loid and domainid = cv_domainid;

    curr_lo_idx    NUMBER := 0;
    curr_lov_start NUMBER := 0;
    curr_var_start NUMBER := 0;
    curr_ci_start NUMBER := 0;
    curr_lov_idx   NUMBER := 0;
    last_lov_idx number := 0;
    last_ci_idx number := 0;
    last_var_idx number := 0;
    curr_loid number; curr_lovid number;
--    linkExists number := 0;

    curr_ci_idx   NUMBER := 0;
    curr_var_idx  NUMBER := 0;
    curr_ftid     NUMBER := 0;

    ilDomainId NUMBER := to_number(IlinkDomainId);

    idArray ArrayNumber;

    lovIDArray ArrayNumber; loIDArray ArrayNumber;
    FTIdArray ArrayNumber;
    FTMofLO ArrayNumber; FTofLOV ArrayNumber;

    cilovIDs ArrayNumber; containedPIVs ArrayNumber; verStatusArray ArrayNumber; lockStatusArray ArrayNumber;
    instStoredNameArray ArrayVarchar200; ciFTIdArray ArrayNumber;
    ciCreatedOnArray ArrayDate; ciModifiedOnArray ArrayDate;
    varCreatedOnArray ArrayDate; varModifiedOnArray ArrayDate;
    lovCreatedOnArray ArrayDate; lovModifiedOnArray ArrayDate;
    applVerIdArray ArrayNumber; applVerBoolArray ArrayNumber; --todo confirm that this is not needed here and then delete
    applIdOfFT ArrayNumberV2; applBoolOfFT ArrayNumberV2;
    fileIdArr ArrayNumber; fileIdOfLOV ArrayNumber;
    fileNameArr ArrayVarchar200; fileNameOfLOV ArrayVarchar200;
    fileSizeArr ArrayNumber; fileSizeOfLOV ArrayNumber;
    fsHostArr ArrayVarchar200; fsHostOfLOV ArrayVarchar200;
    fsPortArr ArrayNumber; fsPortOfLOV ArrayNumber;
    fpPathArr ArrayVarchar4000; fpPathOfLOV ArrayVarchar4000;
    fMapNameArr ArrayVarchar200; fMapNameOfLOV ArrayVarchar200;
    categoryArr ArrayVarchar200; categoryOfLOV ArrayVarchar200;

    ciEPMDocIdArray ArrayNumber; genEPMDocMasterIdArray ArrayNumber; varEPMDocIdArray ArrayNumber;

    i NUMBER; j NUMBER; k NUMBER; arrct number; ciCounter number; varCounter number;

    topGenEPMDoc number := 0;
    firstLOV boolean := false; loCount number := 0;loICCount number := 0;
    existingLOIdArr ArrayNumber; existingFTMasterIdArr ArrayNumber; ftMasterId number;
    incompleteLOIdArr ArrayNumber;
    lovLoaderSizeFlag boolean :=false;
    lastRowFlag boolean :=false;
    lo_status number ;

  BEGIN
--    putpipe('----- Starting SP--- '||to_char(sysdate,'hh24:mi:ss'));
--  putpipe('LOIDs count is '||LOIDs.count);
--  putpipe('LOVIDs count is '||LOVIDs.count);

     if lovLoaderSize>0 then lovLoaderSizeFlag := true; end if;
     if isLastrow=1 then lastRowFlag := true ; end if;
        lo_status :=case
                  when not lovLoaderSizeFlag then  MIGRATION_SUCCESS
                  when lovLoaderSizeFlag and lastRowFlag  then  MIGRATION_SUCCESS
                  else MIGRATION_INCOMPLETE
                  end ;


    incompleteLOIdArr.delete;
  if loIDs.count > 0 then
    FOR curr_lo_idx IN loIDs.FIRST..loIDs.LAST LOOP
      curr_loid := loIDs(curr_lo_idx);
      loIDArray(curr_lo_idx) := curr_loid;
      FTMofLO(curr_loid) := ftmIDs(curr_lo_idx);
      firstLOV := true;
      FOR i IN 1..lovsPerLOCount(curr_lo_idx) LOOP
        curr_lov_start := lovIDArray.COUNT + 1;
        curr_ci_start := ciFTIdArray.COUNT + 1;
        curr_var_start := genEPMDocMasterIdArray.COUNT + 1;
--      putpipe('lst: '||curr_lov_start||' cst: '||curr_ci_start||' vst: '||curr_var_start);
        last_lov_idx := curr_lov_idx;
        last_ci_idx := curr_ci_idx;
        last_var_idx := curr_var_idx;
        BEGIN
          curr_lov_idx := curr_lov_idx + 1;

          -- we have ensured with filterLO function that lovs that are in lovtowcstatus table are filtered out.
          -- so no need to make sure of that
          curr_lovid := lovIDs(curr_lov_idx);
          curr_ftid := ftIDs(curr_lov_idx);
          topGenEPMDoc := getEPMDocument(topGenericPIVIDs(curr_lov_idx), ilDomainId);
           if firstLOV then
               firstLOV := false;
                 -- check if this LO is already in the lotowcstatus table
                 open lostatus(curr_loid, ilDomainId);
                 fetch lostatus into loCount, loICCount;
                 close lostatus;

                 if (loICCount > 0) then
                   incompleteLOIdArr(incompleteLOIdArr.COUNT + 1) := curr_loid;
                 end if;
            end if;
          lovIDArray(lovIDArray.COUNT + 1) := curr_lovid;
          FTofLOV(curr_lovid) := curr_ftid;
          applIdOfFT(to_char(curr_ftid)) := appVerIDs(curr_lov_idx);
          applBoolOfFT(to_char(curr_ftid)) := appVerBools(curr_lov_idx);
          fileIdOfLOV(curr_lovid) := fileIds(curr_lov_idx);
          fileNameOfLOV(curr_lovid) := fileNames(curr_lov_idx);
          fileSizeOfLOV(curr_lovid) := fileSizes(curr_lov_idx);
          fsHostOfLOV(curr_lovid) := fsHosts(curr_lov_idx);
          fsPortOfLOV(curr_lovid) := fsPorts(curr_lov_idx);
          fpPathOfLOV(curr_lovid) := fpPaths(curr_lov_idx);
          fMapNameOfLOV(curr_lovid) := fMapNames(curr_lov_idx);
          categoryOfLOV(curr_lovid) := categories(curr_lov_idx);

          ciCounter := ciFTIdArray.COUNT;
          FOR j IN 1..cisPerLOVCount(curr_lov_idx) LOOP
            curr_ci_idx := curr_ci_idx + 1;
            ciCounter := ciCounter + 1;
            cilovIDs(ciCounter) := curr_lovid;
            containedPIVs(ciCounter) := containedPIVIDs(curr_ci_idx);
            ciFTIdArray(ciCounter) := curr_ftid;
            ciEPMDocIdArray(ciCounter) := getEPMDocument(containedPIVIDs(curr_ci_idx), ilDomainId);

            instStoredNameArray(ciCounter) := instanceStoredName(curr_ci_idx);
            verStatusArray(ciCounter) := verStatuses(curr_ci_idx);
            lockStatusArray(ciCounter) := lockStatuses(curr_ci_idx);
            ciCreatedOnArray(ciCounter) := lovCreatedOn(curr_lov_idx);
            ciModifiedOnArray(ciCounter) := lovModifiedOn(curr_lov_idx);
          END LOOP;

          varCounter := genEPMDocMasterIdArray.COUNT;
          FOR j IN 1..varsPerLOVCount(curr_lov_idx) LOOP
            curr_var_idx := curr_var_idx + 1;
            varCounter := varCounter + 1;

            genEPMDocMasterIdArray(varCounter) := getEPMDocumentMaster(genericPIIDs(curr_var_idx), ilDomainId);
            varEPMDocIdArray(varCounter) := getEPMDocument(variantPIVIDs(curr_var_idx), ilDomainId);
            varCreatedOnArray(varCounter) := lovCreatedOn(curr_lov_idx);
            varModifiedOnArray(varCounter) := lovModifiedOn(curr_lov_idx);

          END LOOP;
        EXCEPTION
          WHEN others THEN -- In this case we skip the next LOV
--            putpipe('exception occured for lo '||LOIDs(curr_lo_idx)||' and lovid '||LOVIDs(curr_lov_idx));
--            putpipe('sqlcode '||SQLCODE);
--            putpipe('sql error message '||SQLERRM);

--            putpipe('lovidx: '||curr_lov_idx||' ciidx: '||curr_ci_idx||' varidx: '||curr_var_idx);
            curr_ci_idx := last_ci_idx + cisPerLOVCount(curr_lov_idx);
            curr_var_idx := last_var_idx + varsPerLOVCount(curr_lov_idx);
--            putpipe('lovidx: '||curr_lov_idx||' ciidx: '||curr_ci_idx||' varidx: '||curr_var_idx);

            lovIDArray.DELETE(curr_lov_start, lovIDArray.COUNT);
            cilovIDs.DELETE(curr_ci_start, cilovIDs.COUNT);
            containedPIVs.DELETE(curr_ci_start, containedPIVs.COUNT);
            ciFTIdArray.DELETE(curr_ci_start, ciFTIdArray.COUNT);
            ciEPMDocIdArray.DELETE(curr_ci_start, ciEPMDocIdArray.COUNT);
            instStoredNameArray.DELETE(curr_ci_start, instStoredNameArray.COUNT);
            verStatusArray.DELETE(curr_ci_start, verStatusArray.COUNT);
            lockStatusArray.DELETE(curr_ci_start, lockStatusArray.COUNT);
            ciCreatedOnArray.DELETE(curr_ci_start, ciCreatedOnArray.COUNT);
            ciModifiedOnArray.DELETE(curr_ci_start, ciModifiedOnArray.COUNT);

            genEPMDocMasterIdArray.DELETE(curr_var_start, genEPMDocMasterIdArray.COUNT);
            varEPMDocIdArray.DELETE(curr_var_start, varEPMDocIdArray.COUNT);
            varCreatedOnArray.DELETE(curr_var_start, varCreatedOnArray.COUNT);
            varModifiedOnArray.DELETE(curr_var_start, varModifiedOnArray.COUNT);
        END;
      END LOOP;
    END LOOP;

--    putpipe('lov processing is finished');

    IF lovIDArray.COUNT > 0 THEN
      -- create contained in links
      idArray.DELETE;
      FOR i in ciFTIdArray.FIRST..ciFTIdArray.LAST LOOP
        curr_ftid := ciFTIdArray(i);
        applVerIdArray(i) := applIdOfFT(to_char(curr_ftid));
        applVerBoolArray(i) := applBoolOfFT(to_char(curr_ftid));
        idArray(i) := GetNewWCID;
--        putpipe('currlov is '||curr_lovid||', i is :'||i||' and ciFTIdArray(i) is '||ciFTIdArray(i)));
--        putpipe('idArray is '||idArray(i)||', cicreatedon is '||ciCreatedOnArray(i)||', cimodon is '||ciModifiedOnArray(i));
--        putpipe('storename is '||instStoredNameArray(i));

      END LOOP;

--      putpipe('inserting '||ciFTIdArray.count||' ciLinks');
      -- found out from Brijesh that Intralink does not store the locked information, so he always returns false
      -- also native pdmlink data has this value as 0
      -- SPR 1174721 - found out from Brijesh that Intralink does store locked information (in field isfrozen) so using it
      FORALL i in ciFTIdArray.FIRST..ciFTIdArray.LAST
        insert into EPMContainedIn(ContainedType, Identifier, locked,
                                  ClassNameKeyRoleAObjectRef, IDA3A5,
                                   ClassNameKeyRoleBObjectRef, IDA3B5,
                                   CreateStampA2, MARKFORDELETEA2, ModifyStampA2,
                                   ClassNameA2A2, IDA2A2, UpdateCountA2, UpdateStampA2, verifystatus)
        values(containedType, instStoredNameArray(i), lockStatusArray(i),
               epmDocumentClassName, ciEPMDocIdArray(i),
               epmSepFTClassName, ciFTIdArray(i),
               ciCreatedOnArray(i), 0, ciModifiedOnArray(i),
               containedLinkClassName, idArray(i),
               1, sysdate, verStatusArray(i));

      -- update authappversion for lov content epmdocuments
      -- added VERIFIED update from WinDU EPMDocumentVerifiedColumnCheck where appVer = null.
      FORALL i in ciFTIdArray.FIRST..ciFTIdArray.LAST
        update epmdocument set CLASSNAMEKEYB10 = decode(applVerIdArray(i), null, null, authAppVerClassName),
                               IDA3B10 = applVerIdArray(i),
                               AUTHORINGAPPVERSION = applVerBoolArray(i),
                               VERIFIED = decode(applVerBoolArray(i), null, 1, VERIFIED)
                         where ida2a2 = ciEPMDocIdArray(i) AND ida3b10 IS NULL;

--    first is the contained and second is lov
--      putpipe('inserted cilinks');
      FORALL i in ciFTIdArray.FIRST..ciFTIdArray.LAST
        insert into ContainedInLinks (LOVId, PIVId, DomainId, EPMContainedInId)
           values (cilovIds(i), containedPIVs(i), ilDomainId, idArray(i));

-- create variant links
--      putpipe('inserting '||genEPMDocMasterIdArray.count||' varlinks');
      idArray.DELETE;

      FOR i in genEPMDocMasterIdArray.FIRST..genEPMDocMasterIdArray.LAST loop
        begin
          idArray(i) := GetNewWCID;
          insert into EPMVariantLink( Required,
                                     ClassNameKeyRoleAObjectRef, IDA3A5,
                                     ClassNameKeyRoleBObjectRef, IDA3B5,
                                     CreateStampA2, MARKFORDELETEA2, ModifyStampA2,
                                     ClassNameA2A2, IDA2A2, UpdateCountA2, UpdateStampA2)
          values( 1,
                 epmDocumentClassName, varEPMDocIdArray(i),
                 epmDocumentMasterClassName, genEPMDocMasterIdArray(i),
                 varCreatedOnArray(i), 0, varModifiedOnArray(i),
                 variantLinkClassName, idArray(i),
                 1, sysdate);
        exception when DUP_VAL_ON_INDEX then
          null; -- ignore
        end;
      end loop;
    END IF;

    -- LO status
    FOR i in loIDArray.FIRST..loIDArray.LAST loop
      begin
        insert into LOToWCStatus ( LOId, domainid, status, epmsepfamilytablemasterid,
                                ErrId, ErrMsg, LoadTime)
              values (loIDArray(i), ilDomainId, lo_status, FTMofLO(loIDArray(i)), NULL, NULL, sysdate);
      exception when DUP_VAL_ON_INDEX then
        null; -- ignore
      end;
    end loop;
    -- for in_complete loStatus
    if incompleteLOIdArr.COUNT > 0 then
	    if not lovLoaderSizeFlag or (lovLoaderSizeFlag and lastRowFlag) then
	       FORALL i in incompleteLOIdArr.FIRST..incompleteLOIdArr.LAST
		  update LOToWCStatus set status=MIGRATION_SUCCESS
		  where loid = incompleteLOIdArr(i) and domainid=ilDomainId;
	    end if;
    end if;
    -- LOV status
    FOR i in lovIDArray.FIRST..lovIDArray.LAST LOOP
       curr_lovid := lovIDArray(i);
       FTIdArray(i) := FTofLOV(curr_lovid);
       fileIdArr(i) := fileIdOfLOV(curr_lovid);
       fileNameArr(i) := fileNameOfLOV(curr_lovid);
       fileSizeArr(i) := fileSizeOfLOV(curr_lovid);
       fsHostArr(i) := fsHostOfLOV(curr_lovid);
       fsPortArr(i) := fsPortOfLOV(curr_lovid);
       fpPathArr(i) := fpPathOfLOV(curr_lovid);
       fMapNameArr(i) := fMapNameOfLOV(curr_lovid);
       categoryArr(i) := categoryOfLOV(curr_lovid);

     END LOOP;

     FORALL i in lovIDArray.FIRST..lovIDArray.LAST
       insert into LOVtoWCStatus(LOVId, DomainId, EPMSepFamilyTableId, propStatus, Status, -- 1: succeed, 2: failed
                                 ErrId, ErrMsg, LoadTime, fileId, fileName, fileSize, fileServerHost,
                                 fileServerPort, filePoolPath, fileMapName, category, fileStatus)
       values(lovIDArray(i), ilDomainId, FTIdArray(i), NULL, MIGRATION_SUCCESS, NULL, NULL, sysdate,
              fileIdArr(i), fileNameArr(i), fileSizeArr(i), fsHostArr(i),
              fsPortArr(i), fpPathArr(i), fMapNameArr(i), categoryArr(i), NULL );

end if;
    if replicaLOIDs.count > 0 then
      for  i in replicaLOIDs.FIRST..replicaLOIDs.LAST loop
       begin
                insert into LOToWCStatus ( LOId, domainid, status, epmsepfamilytablemasterid,
                                    ErrId, ErrMsg, LoadTime)
                values (replicaLOIDs(i), ilDomainId, MIGRATION_REPLICA_SUCCESS, null, NULL, NULL, sysdate);
        exception when others then
          null; --ignore
        end;
        end loop;
    end if;
    -- replicat lov status
    if replicaLOVIDs.count > 0 then
      FORALL i in replicaLOVIDs.FIRST..replicaLOVIDs.LAST
        insert into LOVtoWCStatus(LOVId, DomainId, EPMSepFamilyTableId, propStatus, Status, -- 1: succeed, 2: failed
                                  ErrId, ErrMsg, LoadTime)
        values(replicaLOVIDs(i), ilDomainId, NULL, NULL, MIGRATION_REPLICA_SUCCESS, NULL, NULL, sysdate);
    end if;

--    putpipe('----- Ending SP--- '||to_char(sysdate,'hh24:mi:ss'));
    return 1;
--  EXCEPTION WHEN OTHERS THEN
--            putpipe('sqlcode '||SQLCODE);
--            putpipe('sql error message '||SQLERRM);
  END insertLOs;
----------------------------------------------------------------------------------
  FUNCTION insertLOProps( containedLinkClassName VARCHAR2,
                          epmSepFTMasterClassName VARCHAR2,
                          epmSepFTClassName VARCHAR2,
                          paramDefClassName VARCHAR2,
                          paramClassName VARCHAR2,
                          featureDefClassName VARCHAR2,
                          featureClassName VARCHAR2,
                          memberLinkClassName VARCHAR2,
                          refLinkClassName VARCHAR2,
                          attrClassName VARCHAR2,
                          cellClassName VARCHAR2,
                          cellDepClassName VARCHAR2,
                          epmDocumentClassName VARCHAR2,
                          paramValClassName VARCHAR2,
                          featureValClassName VARCHAR2,

                          IlinkDomainId VARCHAR2,
                          loIDs TABLE_OF_NUMBER, lovsPerLOCount TABLE_OF_NUMBER,
                          lovIDs TABLE_OF_NUMBER,
                          lovCreatedOn TABLE_OF_DATE,
                          lovModifiedOn TABLE_OF_DATE,

                          paramsPerLOVCount TABLE_OF_NUMBER,
                          pInstPIVIDs TABLE_OF_NUMBER,
                          piipInternalIds TABLE_OF_NUMBER, piipNames uzy_mig_TABLE_OF_VARCHAR2_200,
                          piipTypes TABLE_OF_NUMBER, piipValueTypes TABLE_OF_NUMBER,
                          pAttributes TABLE_OF_NUMBER, pColumnTypes TABLE_OF_NUMBER,
                          pTitles uzy_mig_TABLE_OF_VARCHAR2_200,
                          pOverridable TABLE_OF_NUMBER,
                          pDefinedHere TABLE_OF_NUMBER,

                          paramValsPerLOVCount TABLE_OF_NUMBER,
                          pValPIVIDs TABLE_OF_NUMBER,
                          pValpiipNames uzy_mig_TABLE_OF_VARCHAR2_200,
                          pValpiipValueTypes TABLE_OF_NUMBER,
                          piipValueLongs TABLE_OF_NUMBER, piipValueReals TABLE_OF_NUMBER,
                          piipValueStrings uzy_mig_TABLE_OF_VARCHAR2_200,

                          featuresPerLOVCount TABLE_OF_NUMBER,
                          fInstPIVIDs TABLE_OF_NUMBER,
                          pifInternalIds TABLE_OF_NUMBER, pifNames uzy_mig_TABLE_OF_VARCHAR2_200,
                          pifTypes TABLE_OF_NUMBER,
                          featureValueTypes TABLE_OF_NUMBER,
                          featureValueNumbers TABLE_OF_NUMBER, featureValueStrings uzy_mig_TABLE_OF_VARCHAR2_200,
                          fAttributes TABLE_OF_NUMBER, fColumnTypes TABLE_OF_NUMBER,
                          fTitles uzy_mig_TABLE_OF_VARCHAR2_200,
                          fOverridable TABLE_OF_NUMBER,
                          fDefinedHere TABLE_OF_NUMBER,

                          depsPerLOVCount TABLE_OF_NUMBER,
                          dInstPIVIDs TABLE_OF_NUMBER,
                          dlinkTypes TABLE_OF_NUMBER,
                          dSuppressed TABLE_OF_NUMBER, depNames uzy_mig_TABLE_OF_VARCHAR2_200,
                          dChildNames uzy_mig_TABLE_OF_VARCHAR2_200,
			  dDgids TABLE_OF_NUMBER,
                          dAttributes TABLE_OF_NUMBER, dColumnTypes TABLE_OF_NUMBER,
                          dTitles uzy_mig_TABLE_OF_VARCHAR2_200,
                          dOverridable TABLE_OF_NUMBER,
                          dDefinedHere TABLE_OF_NUMBER,


                          attrsPerLOVCount TABLE_OF_NUMBER,
                          aInstPIVIDs TABLE_OF_NUMBER,
                          attrDefIds TABLE_OF_NUMBER,
                          attrNames uzy_mig_TABLE_OF_VARCHAR2_200,
                          aAttributes TABLE_OF_NUMBER, aColumnTypes TABLE_OF_NUMBER,
                          aTitles uzy_mig_TABLE_OF_VARCHAR2_200,
                          aOverridable TABLE_OF_NUMBER,
                          aDefinedHere TABLE_OF_NUMBER

                          ) RETURN NUMBER IS

    cursor get_paramDef(cv_name varchar2, cv_id number) is
        select ida2a2 from epmParameterDefinition where
              name = cv_name and idA3A3 = cv_id;

    cursor get_featureDef(cv_name varchar2, cv_id number) is
        select ida2a2 from epmFeatureDefinition where
              name = cv_name and idA3A3 = cv_id;

    curr_lo_idx NUMBER := 0; curr_lov_idx NUMBER := 0; t number; k number;
    loid number; lovid number; cellId number; v_lovid number;
    famTabMasterId number; famTabId number;
    instpiv number;
    epmContainedInId number; v_inherited number; v_uniquendid varchar2(200);
    lastOne boolean := false;

    curr_param_idx number := 0; paramDefId number; paramId number; valType number;
    paramDefName varchar2(200);
    paramDefs ArrayNumberV2; famTabParams ArrayNumberV2;

    curr_paramVal_idx number := 0; numVal number; strVal varchar2(200);
    createStamp date; modStamp date;
    epmDocumentId number; valId number; docCount number := 0;

    curr_feature_idx number := 0; pifValueType number; featureDefId number; featureId number;
    featureDefName varchar2(200);
    featureDefs ArrayNumberV2; famTabFeatures ArrayNumberV2;

    curr_dep_idx number := 0; depValueType number; depType number; ftlinkId number;
    famTabLinks ArrayNumberV2;
    ftLinkClassName varchar2(200); ftLinkName varchar2(200);

    curr_attr_idx number := 0; attrDefId number; ftAttrId number;
    famTabAttrs ArrayNumber;
    ftAttrName varchar2(200);

--  from ildep.java
--  public final static int MEMBER_LINK = 0;
--  public final static int REFERENCE_LINK = 1;

--  from capicomm.h
-- typedef enum PDME_INHERIT_PROTOCOL {
--     PDME_IP_OVERRIDABLE = 0,
--     PDME_IP_NONOVERRIDABLE = 1,
--     PDME_IP_FREE = 2
-- }PDME_INHERIT_PROTOCOL;
-- Brijesh does not expect a value of 2 assigned to this variable overridable
-- so inherited = overridable.



    ilDomainId NUMBER := to_number(IlinkDomainId);

  BEGIN
--    putpipe('----- Starting SP--- '||to_char(sysdate,'hh24:mi:ss'));
--    putpipe('LOIDs count is '||LOIDs.count);
--    putpipe('LOVIDs count is '||LOVIDs.count);
   if loIDs.count > 0 then
    FOR curr_lo_idx IN loIDs.FIRST..loIDs.LAST LOOP
      loid := loIDs(curr_lo_idx);
--      putpipe('loid is '||loid);
      -- param defs and feature defs are per LO so delete those per LO
      paramDefs.delete;
      featureDefs.delete;
      famTabMasterId := getFamTabMasterId(loid, ilDomainId);
--      putpipe('famtabmasterid is '||famTabMasterId);
      FOR i IN 1..lovsPerLOCount(curr_lo_idx) LOOP
        -- these four are epmfamilytable<columns> and we need to create one for each LOV
        -- so delete the array for each LOV
        famTabParams.delete;
        famTabFeatures.delete;
        famTabLinks.delete;
        famTabAttrs.delete;
        curr_lov_idx := curr_lov_idx + 1;
        lovid := lovIDs(curr_lov_idx);
        famTabId := getFamTabId(lovid, ilDomainId);
--        putpipe('lov :'||lovid);
--        putpipe('params per lov :'||paramsPerLOVCount(curr_lov_idx));
--        putpipe('features per lov :'||featuresPerLOVCount(curr_lov_idx));
--        putpipe('deps per lov :'||depsPerLOVCount(curr_lov_idx));
--        putpipe('attrs per lov :'||attrsPerLOVCount(curr_lov_idx));

        if depsPerLOVCount(curr_lov_idx) > 0 then
          for j in 1..depsPerLOVCount(curr_lov_idx) LOOP
            curr_dep_idx := curr_dep_idx + 1;
            t := curr_dep_idx;
            ftlinkName := depNames(t);

            instpiv := dInstPIVIDs(t);

            ftlinkId := null;
            -- get ftlinkid for this ftlinkname
            if not famTabLinks.exists(ftlinkName) then
              -- if ftlinkid is null then we need to create family table member/reference
              ftlinkId := GetNewWCID;
              if dlinkTypes(t) = MEMBER_LINK then
                insert into EPMFamilyTableMember
                       ( attribute, columnType,
                       classnamekeyA3, idA3A3, name, createStampA2,
                       markForDeleteA2, modifyStampA2, classnameA2A2,
                       idA2A2, updateCountA2, updateStampA2, title )
                values
                       ( dAttributes(t), dColumnTypes(t),
                         epmSepFTClassName, famTabId, ftlinkName, lovCreatedOn(curr_lov_idx),
                         0, lovModifiedOn(curr_lov_idx), memberLinkClassName,
                         ftlinkId, 1, sysdate, dTitles(t));
              else
                insert into EPMFamilyTableReference
                       ( attribute, columnType,
                       classnamekeyA3, idA3A3, name, createStampA2,
                       markForDeleteA2, modifyStampA2, classnameA2A2,
                       idA2A2, updateCountA2, updateStampA2, title )
                values
                       ( dAttributes(t), dColumnTypes(t),
                         epmSepFTClassName, famTabId, ftlinkName, lovCreatedOn(curr_lov_idx),
                         0, lovModifiedOn(curr_lov_idx), refLinkClassName,
                         ftlinkId, 1, sysdate, dTitles(t));
              end if;
              famTabLinks(ftlinkName) := ftlinkId;
    --        putpipe('famtabmember/reference inserted');
            end if;
            ftlinkId := famTabLinks(ftlinkName);

            if dlinkTypes(t) = MEMBER_LINK then
              ftlinkClassName := memberLinkClassName;
            else
              ftlinkClassName := refLinkClassName;
            end if;

  --          putpipe('ftlinkId is '||ftlinkId);
  --          putpipe(lovid||', '||instpiv||', '||ilDomainId);
            epmContainedInId := getContainedInId(lovid, instpiv, ilDomainId);
            begin
            v_uniquendid := getUniqueNDId(dDgids(t), ilDomainId, dlinkTypes(t));
            exception when others then
             raise_application_error (NULL_EXCPETION,'error occured at dgid='||dDgids(t)||' and lovid = '||lovid||' and instpiv='||instpiv);
            end;
            cellId := GetNewWCID;
            insert into EPMFamilyTableCellDep
                 ( childName, classnamekeyB3, idA3B3, classnamekeyA3, idA3A3,
                   definedHere, inherited, suppressed, createStampA2, markForDeleteA2,
                   modifyStampA2, classnameA2A2, idA2A2,
                   updateCountA2, updateStampA2, uniqueId )
            values
                 ( dChildNames(t), ftlinkClassName, ftlinkId, containedLinkClassName, epmContainedInId,
                   dDefinedHere(t), dOverridable(t), dSuppressed(t), lovCreatedOn(curr_lov_idx), 0,
                   lovModifiedOn(curr_lov_idx), cellDepClassName, cellId,
                   1, sysdate, v_uniquendid );
  --        putpipe('inserted in epmfamilytablecelldep');
          end LOOP;
        end if;

        -- derived parameter
        if paramsPerLOVCount(curr_lov_idx) > 0 then
          for j in 1..paramsPerLOVCount(curr_lov_idx) LOOP
            curr_param_idx := curr_param_idx + 1;
            t := curr_param_idx;
            paramDefName := piipNames(t);
  --        putpipe('paramDefName is '||paramDefName);

            -- create parameter definition if it does not exist already
            if not paramDefs.exists(paramDefName) then
		    begin
			    select ida2a2 into  paramDefId
			    from EPMParameterDefinition where IDA3A3 = famTabMasterId and name = paramDefName and rownum<=1;

		    exception when no_data_found then
              paramDefId := GetNewWCID;
              valType := getPIIPValType(piipValueTypes(t));
              insert into EPMParameterDefinition
                     ( CLASSNAMEKEYA3, IDA3A3, INTERNALID, NAME, PARAMETERTYPE,
                       CREATESTAMPA2, MARKFORDELETEA2, MODIFYSTAMPA2,
                       CLASSNAMEA2A2, IDA2A2, UPDATECOUNTA2, UPDATESTAMPA2, VALUETYPE)
              values
                     ( epmSepFTMasterClassName, famTabMasterId, piipInternalIds(t),
                       paramDefName, piipTypes(t), lovCreatedOn(curr_lov_idx), 0,
                       lovModifiedOn(curr_lov_idx), paramDefClassName, paramDefId,
                       1, sysdate, valType );
  --          putpipe('paramdef inserted');

		    end;
              paramDefs(paramDefName) := paramDefId;
            end if;
            paramDefId := paramDefs(paramDefName);


              -- create family table parameter if it does not exist already
            if not famTabParams.exists(paramDefName) then
  --          putpipe('defid is '||paramDefId||' and defname is '||paramDefName);
              paramId := GetNewWCID;
              insert into EPMFamilyTableParameter
                   ( attribute, columnType, classnamekeyA4, idA3A4,
                   classnamekeyA3, idA3A3, name, createStampA2,
                   markForDeleteA2, modifyStampA2, classnameA2A2,
                   idA2A2, updateCountA2, updateStampA2, title )
              values
                   ( pAttributes(t), pColumnTypes(t), paramDefClassName, paramDefId,
                     epmSepFTClassName, famTabId, paramDefName, lovCreatedOn(curr_lov_idx),
                     0, lovModifiedOn(curr_lov_idx), paramClassName,
                   paramId, 1, sysdate, pTitles(t));
              famTabParams(paramDefName) := paramId;
  --          putpipe('famtabparameter inserted');
            end if;

            instpiv := pInstPIVIDs(t);

            paramId := famTabParams(paramDefName);
  --          putpipe('paramId is '||paramId);
            epmContainedInId := getContainedInId(lovid, instpiv, ilDomainId);
            cellId := GetNewWCID;
            insert into EPMFamilyTableCell
               ( classnamekeyB3, idA3B3, classnamekeyA3, idA3A3,
                 definedHere, inherited, createStampA2, markForDeleteA2,
                 modifyStampA2, classnameA2A2, idA2A2,
                 updateCountA2, updateStampA2 )
              values
               ( paramClassName, paramId, containedLinkClassName, epmContainedInId,
                 pDefinedHere(t), pOverridable(t), lovCreatedOn(curr_lov_idx), 0,
                     lovModifiedOn(curr_lov_idx), cellClassName, cellId,
                     1, sysdate );
  --        putpipe('inserted in epmfamilytablecell');

          end loop;  -- end of loop for parameters
        end if; -- end of if count of paramters per lov is more than 0

        -- derived parameter values
        for j in 1..paramValsPerLOVCount(curr_lov_idx) LOOP
          curr_paramVal_idx := curr_paramVal_idx + 1;
          t := curr_paramVal_idx;
          paramDefName := pValpiipNames(t);
          getEPMDocumentWithTimeStamp(pValPIVIDs(t), ilDomainId, epmDocumentId, createStamp, modStamp);
          docCount := 0;
          select count(ida2a2) into docCount
            from epmparametervalue where ida3a4 = epmDocumentId and name = paramDefName;

          if docCount = 0 then -- this value was not inserted with earlier PIV
            valId := GetNewWCID;
            numVal := null; strVal := null;
            valType := getPIIPValType(pValpiipValueTypes(t));
            if valType = WCINTTYPE or valType = WCBOOLTYPE then
              numVal := piipValueLongs(t);
            elsif valType = WCFLOATTYPE then
              numVal := piipValueReals(t);
            elsif valType = WCSTRTYPE then
              strVal := piipValueStrings(t);
            end if;

            insert into EPMParameterValue
              ( CLASSNAMEKEYA4, IDA3A4, NAME, NUMBERVALUE,
                STRINGVALUE, CREATESTAMPA2, MARKFORDELETEA2, MODIFYSTAMPA2,
                CLASSNAMEA2A2, IDA2A2, UPDATECOUNTA2, UPDATESTAMPA2, VALUETYPE )
              values
              ( epmDocumentClassName, epmDocumentId, paramDefName, numVal,
                strVal, createStamp, 0, modStamp,
                paramValClassName, valId, 1, sysdate, valType );
          end if;
        end loop;

        -- create features for this lov
        if featuresPerLOVCount(curr_lov_idx) > 0 then
          for j in 1..featuresPerLOVCount(curr_lov_idx) LOOP
            curr_feature_idx := curr_feature_idx + 1;
            t := curr_feature_idx;
            featureDefName := pifNames(t);
            -- create feature definition if it does not exist already

            if not featureDefs.exists(featureDefName) then
  --          putpipe('featuredefname is '|| featureDefName);
	   begin
              select ida2a2 into  featureDefId
	        from EPMFeatureDefinition where IDA3A3 = famTabMasterId and name = featureDefName and rownum<=1;
	     exception when no_data_found then
              valType := getFeatureValType(featureValueTypes(t));
              featureDefId := GetNewWCID;

              insert into EPMFeatureDefinition
                     ( CLASSNAMEKEYA3, IDA3A3, INTERNALID, NAME, FEATURETYPE,
                       CREATESTAMPA2, MARKFORDELETEA2, MODIFYSTAMPA2,
                       CLASSNAMEA2A2, IDA2A2, UPDATECOUNTA2, UPDATESTAMPA2, VALUETYPE)
              values
                     ( epmSepFTMasterClassName, famTabMasterId, pifInternalIds(t),
                       featureDefName, pifTypes(t), lovCreatedOn(curr_lov_idx), 0,
                       lovModifiedOn(curr_lov_idx), featureDefClassName, featureDefId,
                       1, sysdate, valType );
  --          putpipe('featuredef inserted');
	      end;
              featureDefs(featureDefName) := featureDefId;
            end if;
            featureDefId := featureDefs(featureDefName);
  --        putpipe('defid is '||featureDefId||' and defname is '||featureDefName);

            -- create family table feature if it does not exist already
            if not famTabFeatures.exists(featureDefName) then
              featureId := GetNewWCID;
              insert into EPMFamilyTableFeature
                   ( attribute, columnType, classnamekeyA4, idA3A4,
                   classnamekeyA3, idA3A3, name, createStampA2,
                   markForDeleteA2, modifyStampA2, classnameA2A2,
                   idA2A2, updateCountA2, updateStampA2, title )
              values
                   ( fAttributes(t), fColumnTypes(t), featureDefClassName, featureDefId,
                     epmSepFTClassName, famTabId, featureDefName, lovCreatedOn(curr_lov_idx),
                     0, lovModifiedOn(curr_lov_idx), featureClassName,
                     featureId, 1, sysdate, fTitles(t));
              famTabFeatures(featureDefName) := featureId;
  --          putpipe('famtabparameter inserted');
            end if;
            featureId := famTabFeatures(featureDefName);
  --        putpipe('featureId is '||featureId);


            instpiv := fInstPIVIDs(t);

            epmContainedInId := getContainedInId(lovid, instpiv, ilDomainId);
            cellId := GetNewWCID;
            insert into EPMFamilyTableCell
               ( classnamekeyB3, idA3B3, classnamekeyA3, idA3A3,
                 definedHere, inherited, createStampA2, markForDeleteA2,
                 modifyStampA2, classnameA2A2, idA2A2,
                 updateCountA2, updateStampA2 )
              values
               ( featureClassName, featureId, containedLinkClassName, epmContainedInId,
                 fDefinedHere(t), fOverridable(t), lovCreatedOn(curr_lov_idx), 0,
                 lovModifiedOn(curr_lov_idx), cellClassName, cellId, 1, sysdate );

            valId := GetNewWCID;
            epmDocumentId := getEPMDocument(instpiv, ilDomainId);
            numVal := null; strVal := null;
            valType := getFeatureValType(featureValueTypes(t));
            if valType = WCINTTYPE or valType = WCBOOLTYPE or valType = WCFLOATTYPE then
              numVal := featureValueNumbers(t);
            elsif valType = WCSTRTYPE then
              strVal := featureValueStrings(t);
            end if;

            begin
              insert into EPMFeatureValue
                ( CLASSNAMEKEYA4, IDA3A4, NAME, NUMBERVALUE,
                  STRINGVALUE, CREATESTAMPA2, MARKFORDELETEA2, MODIFYSTAMPA2,
                  CLASSNAMEA2A2, IDA2A2, UPDATECOUNTA2, UPDATESTAMPA2, VALUETYPE )
                values
                ( epmDocumentClassName, epmDocumentId, featureDefName, numVal,
                  strVal, lovCreatedOn(curr_lov_idx), 0, lovModifiedOn(curr_lov_idx),
                  featureValClassName, valId, 1, sysdate, valType );
            exception when DUP_VAL_ON_INDEX then
              null; -- ignore since we have already entered this value
            end;
  --           putpipe('inserted in epmfamilytablecell');
          end loop;  -- end of loop for parameters
        end if; -- end of if count of features for this lov is zero

        -- derived attribute
        if attrsPerLOVCount(curr_lov_idx) > 0 then
          for j in 1..attrsPerLOVCount(curr_lov_idx) LOOP
            curr_attr_idx := curr_attr_idx + 1;
            t := curr_attr_idx;
            attrDefId := attrDefIds(t);
  --        putpipe('attrDefid is '||attrDefId);

            instpiv := aInstPIVIDs(t);

              -- create family table attribute if it does not exist already
            if not famTabAttrs.exists(attrDefId) then
              ftAttrName := attrNames(t);
              -- one column for one attrid
              ftAttrId := GetNewWCID;
              insert into EPMFamilyTableAttribute
                     ( attribute, columnType,
                     classnamekeyA3, idA3A3, name, createStampA2,
                     markForDeleteA2, modifyStampA2, classnameA2A2,
                     idA2A2, updateCountA2, updateStampA2, title )
              values
                     ( aAttributes(t), aColumnTypes(t),
                       epmSepFTClassName, famTabId, ftAttrName, lovCreatedOn(curr_lov_idx),
                       0, lovModifiedOn(curr_lov_idx), attrClassName,
                       ftAttrId, 1, sysdate, aTitles(t));
              famTabAttrs(attrDefId) := ftAttrId;
  --              putpipe('famtabattribute inserted');
            end if;

            ftAttrId := famTabAttrs(attrDefId);

  --          putpipe('ftAttrId is '||ftAttrId);
            epmContainedInId := getContainedInId(lovid, instpiv, ilDomainId);
            cellId := GetNewWCID;
            insert into EPMFamilyTableCell
                 ( classnamekeyB3, idA3B3, classnamekeyA3, idA3A3,
                   definedHere, inherited, createStampA2, markForDeleteA2,
                   modifyStampA2, classnameA2A2, idA2A2,
                   updateCountA2, updateStampA2 )
            values
                 ( attrClassName, ftAttrId, containedLinkClassName, epmContainedInId,
                   aDefinedHere(t), aOverridable(t), lovCreatedOn(curr_lov_idx), 0,
                   lovModifiedOn(curr_lov_idx), cellClassName, cellId,
                   1, sysdate );
  --          putpipe('inserted in epmfamilytablecell');
          end LOOP;
        end if;

        v_lovid := lovid;
--        putpipe('lovid is :'||lovid);
        update lovtowcstatus set propstatus = 1 where lovid = v_lovid;

        null;
      end loop;  -- end of loop for lovs
      if curr_param_idx > 0 then
	      valType := getPIIPValType(piipValueTypes(curr_param_idx));
	      paramDefName := piipNames(curr_param_idx);
	      if paramDefs.exists(paramDefName) then
		 paramDefId := paramDefs(paramDefName);
		 update EPMParameterDefinition
		   set
		      INTERNALID=piipInternalIds(curr_param_idx),
		      VALUETYPE=valType
		   where ida2a2=paramDefId
			and ida3a3 = famTabMasterId;
		end if;
	end if;
    end loop;  -- end of loop for los

    end if;

--    putpipe('----- Ending SP--- '||to_char(sysdate,'hh24:mi:ss'));
    return 1;
--  EXCEPTION WHEN OTHERS THEN
--            putpipe('sqlcode '||SQLCODE);
--            putpipe('sql error message '||SQLERRM);
  END insertLOProps;

  ----------------------------------------------------------------------------------
  FUNCTION updateAttrStatus ( IlinkDomainId VARCHAR2,
                              success_code NUMBER,

                              piIDs TABLE_OF_NUMBER,
                              pivIDs TABLE_OF_NUMBER,
                              depIDs TABLE_OF_NUMBER ) RETURN NUMBER IS

    ilDomainId NUMBER := to_number(IlinkDomainId);

  BEGIN

--    putpipe('----- starting SP--- domain is '||ilinkDomainId||' success_code is '||success_code);
--    if (piIDs.COUNT <> 0) then
--      putpipe('first piid is '||piIDs(piIDs.FIRST)||' and last piid is '||piIDs(piIDs.LAST));
--    end if;
    if (piIDs.COUNT <> 0) then
      FORALL i in piIDs.FIRST..piIDs.LAST
        update PIToWCStatus set AttrStatus = success_code,
            AttrErrMsg = null, AttrLoadTime = sysdate
            where PIId = piIDs(i) and domainid = ilDomainId;
    end if;

    if (pivIDs.COUNT <> 0) then
      FORALL i in pivIDs.FIRST..pivIDs.LAST
        update PIVToWCStatus set AttrStatus = success_code,
            AttrErrMsg = null, AttrLoadTime = sysdate
            where PIVId = pivIDs(i) and domainid = ilDomainId;
    end if;

    if (depIDs.COUNT <> 0 ) then
      FORALL i in depIDs.FIRST..depIDs.LAST
        update DepToWCStatus set AttrStatus = success_code,
            AttrErrMsg = null, AttrLoadTime = sysdate
            where DGId = depIDs(i) and domainid = ilDomainId;
    end if;

    return 1;
  END updateAttrStatus;
  ----------------------------------------------------------------------------------
FUNCTION insertOrUpdateLinks(parentClassName                   VARCHAR2,
                           childClassName              VARCHAR2,
                           ilinkDomainId               VARCHAR2,
                           unit                            VARCHAR2,
                           memlinkida2TypeDefRef       NUMBER,
                           memlinkbranchida2TypeDefRef NUMBER,
                           reflinkida2TypeDefRef       NUMBER,
                           reflinkbranchida2TypeDefRef NUMBER,
                           operInt                     NUMBER,

                           depDGId_arr                 TABLE_OF_NUMBER,
                           depWCId_arr                 TABLE_OF_NUMBER,
                           linkType_arr                TABLE_OF_NUMBER,
                           asStoredChildName_arr       uzy_mig_TABLE_OF_VARCHAR2_200,
                           depType_arr                 TABLE_OF_NUMBER,
                           identifier_arr              TABLE_OF_NUMBER,
                           name_arr                    uzy_mig_TABLE_OF_VARCHAR2_200,
                           placed_arr                  TABLE_OF_NUMBER,
                           quantity_arr                TABLE_OF_NUMBER,
                           ufQuantity_arr              TABLE_OF_NUMBER,
                           required_arr                TABLE_OF_NUMBER,
                           ida3a5_parent_arr           TABLE_OF_NUMBER,
                           ida3b5_child_arr            TABLE_OF_NUMBER,
                           parentDocType_arr          TABLE_OF_NUMBER,
                           childDocType_arr           TABLE_OF_NUMBER,
                           suppressed_arr              TABLE_OF_NUMBER,
                           substitute_arr                                                       TABLE_OF_NUMBER,
                           skeletonMemb_arr           TABLE_OF_NUMBER,
                           uniqueLinkId_arr            TABLE_OF_NUMBER,

                           createdOn_arr               TABLE_OF_DATE,
                           modifiedOn_arr                  TABLE_OF_DATE,
                           uniqueNDId_arr                  uzy_mig_TABLE_OF_VARCHAR2_200,
                           compNum_arr                     TABLE_OF_NUMBER,
                           compRevNum_arr                  TABLE_OF_NUMBER,
                           compLayerIdx_arr                TABLE_OF_NUMBER,

                           rcIsNull_arr                    TABLE_OF_NUMBER,
                           rcGeomRestrRecur_arr            TABLE_OF_NUMBER,
                           rcGeomRestr_arr                 TABLE_OF_NUMBER,
                           rcScope_arr                     TABLE_OF_NUMBER,
                           rcViolRestr_arr                 TABLE_OF_NUMBER,

                           transIsNull_arr                 TABLE_OF_NUMBER,
                           e_00_arr                        TABLE_OF_NUMBER,
                           e_01_arr                        TABLE_OF_NUMBER,
                           e_02_arr                        TABLE_OF_NUMBER,
                           e_10_arr                        TABLE_OF_NUMBER,
                           e_11_arr                        TABLE_OF_NUMBER,
                           e_12_arr                        TABLE_OF_NUMBER,
                           e_20_arr                        TABLE_OF_NUMBER,
                           e_21_arr                        TABLE_OF_NUMBER,
                           e_22_arr                        TABLE_OF_NUMBER,
                           e_30_arr                        TABLE_OF_NUMBER,
                           e_31_arr                        TABLE_OF_NUMBER,
                           e_32_arr                        TABLE_OF_NUMBER,
                           referenceType_arr               uzy_mig_TABLE_OF_VARCHAR2_200
                           ) RETURN NUMBER IS

v_asStoredChildName     VARCHAR2(200);
v_authoringApplication  VARCHAR2(200);
v_depType               NUMBER;
v_identifier            NUMBER;
v_name                  VARCHAR2(200);
v_ownerApplication      VARCHAR2(200);
v_placed                NUMBER(1);
v_quantity              NUMBER;
v_ufQuantity                    NUMBER; -- used for unfinished dep's quantity
v_required              NUMBER(1);
v_ida3a5_parent         NUMBER;
v_ida3b5_child          NUMBER;
v_parentDocType        NUMBER;
v_childDocType         NUMBER;
v_suppressed            NUMBER(1);
v_substitute                                            NUMBER(1);
v_skeletonMemb			Number(1);
v_linkClassName         VARCHAR2(200);
v_ida2a2_link           NUMBER;
v_updatecounta2         NUMBER := 1; -- unless specified otherwise
v_uniqueLinkId          NUMBER;

v_uniqueNDId                    VARCHAR2(200);
v_compNum                               NUMBER;
v_compRevNum                    NUMBER;
v_compLayerIdx                  NUMBER;

v_rcIsNull                              NUMBER;
v_rcGeomRestrRecur              NUMBER;
v_rcGeomRestr                   NUMBER;
v_rcScope                               NUMBER;
v_rcViolRestr                   NUMBER;

v_transIsNull                   NUMBER;
v_e_00                                  NUMBER;
v_e_01                                  NUMBER;
v_e_02                                  NUMBER;
v_e_10                                  NUMBER;
v_e_11                                  NUMBER;
v_e_12                                  NUMBER;
v_e_20                                  NUMBER;
v_e_21                                  NUMBER;
v_e_22                                  NUMBER;
v_e_30                                  NUMBER;
v_e_31                                  NUMBER;
v_e_32                                  NUMBER;

v_depDGID               NUMBER;
v_depWCId               number;
v_linkType              NUMBER;

v_currIndex             NUMBER := 1;
v_linkIndex             NUMBER := 1;
v_memlinkIndex          NUMBER := 1;
v_reflinkIndex          NUMBER := 1;
v_unfinishedIndex               NUMBER := 1;

v_ilDomId NUMBER := to_number(ilinkDomainId);

v_createdOn DATE;
v_modifiedOn DATE;

v_message               VARCHAR2(2000);
v_referenceType                                 VARCHAR2(200);
v_annotated             NUMBER(1) := 0; --Change to populate ANNOTATED column in EPMMemberLink (X-10) .
                                        --Please refer to design note "14218347-14218861 - X-10 Support Assembly Structure Editing in Windchill." for further info on how to populate this column.
                                        --As of today it should be false. Extracted from the Document: "Upgrade should set the value of this field to false".
                                        --Just defaulting this variable to false.
v_fixed                 NUMBER(1) := 0; --Change to populate FIXED column in EPMMemberLink (X-20).
                                        --For migrated links it should be 0.So defaulting this variable to 0.
DEP_T_GENERIC  CONSTANT      number := 32;
BEGIN
--  putpipe('operation is :'||operInt);
  if operInt = DEP_CREATE then
    -- a. loop through the array of depDGID_arr
    FOR v_currIndex IN depDGId_arr.FIRST..depDGId_arr.LAST LOOP
      -- b. get the individual items from the arrays
      v_depDGId := depDGId_arr(v_currIndex);
      v_linkType := linkType_arr(v_currIndex);

      v_asStoredChildName := asStoredChildName_arr(v_currIndex);
      v_depType := depType_arr(v_currIndex);

      v_ida3a5_parent := ida3a5_parent_arr(v_currIndex);
      v_ida3b5_child := ida3b5_child_arr(v_currIndex);
      v_parentDocType := parentDocType_arr(v_currIndex);
      v_childDocType := childDocType_arr(v_currIndex);
      if v_linkType = MIGRATION_CANNOTDO then
          -- d. insert into deptowcstatus table
          if v_depType=DEP_T_GENERIC then
            v_message :='As per PDMLink requirement, Pro/Intralink dependency of type DEP_T_GENERIC is not migrated for DGId:'||v_depDGId||' to component ['||
                            v_asStoredChildName||'] with DepType = ['||
                          v_depType||'].';
          elsif v_parentDocType = WTDOCTYPE or v_childDocType = WTDOCTYPE then
            v_message := 'Can not create Link for DGId:'||v_depDGId||' to component ['||
                            v_asStoredChildName||'] with DepType = ['||
                          v_depType||']. Parent/Child cannot be WTDocuments.';
          else
            v_message := 'Can not create EPMMemberLink / EPMReferenceLink for DGId:'||v_depDGId||' to component [' || v_asStoredChildName ||
                        '] with DepType = [' || v_depType || '] different from Pro_E / USER_DEFINED / USER_BOM.';
          end if;
           insert into DEPTOWCSTATUS (DGID,
                                DOMAINID,
                                STATUS,
                                ERRID,
                                ERRMSG,
                                LINKTYPE,
                                EPMLINKID,
                                LOADTIME,
                                ATTRSTATUS,
                                ATTRERRID,
                                ATTRERRMSG,
                                ATTRLOADTIME)
                           values(v_depDGID,
                                    v_ilDomId,
                                    MIGRATION_CANNOTDO,
                                    0,
                                    v_message,
                                    null,  -- or, 0, does it really matter ?
                                    null,
                                    sysdate,
                                    null,
                                    null,
                                    null,
                                    null);
      elsif v_linkType = MIGRATION_UNFINISHED then
              v_ufQuantity := ufQuantity_arr(v_unfinishedIndex);

              v_unfinishedIndex := v_unfinishedIndex + 1;

                insert into DEPCACHE (DGID,
                                DOMAINID,
                                PARENTEPMID,
                                PARENTDOCTYPE,
                                CHILDEPMID,
                                CHILDDOCTYPE,
                                QUANTITY)
                           values(v_depDGID,
                                  v_ilDomId,
                                  v_ida3a5_parent,
                                  v_parentDocType,
                                  v_ida3b5_child,
                                  v_childDocType,
                                  v_ufQuantity);

               insert into DEPTOWCSTATUS (DGID,
                                DOMAINID,
                                STATUS,
                                ERRID,
                                ERRMSG,
                                LINKTYPE,
                                EPMLINKID,
                                LOADTIME,
                                ATTRSTATUS,
                                ATTRERRID,
                                ATTRERRMSG,
                                ATTRLOADTIME)
                           values(v_depDGID,
                                    v_ilDomId,
                                    MIGRATION_UNFINISHED,
                                    0,
                                    null,
                                    null,  -- or 2 for WTPartUsageLink, set after SUCCESS?
                                    null,
                                    sysdate,
                                    null,
                                    null,
                                    null,
                                    null);
      else
          v_createdOn := createdOn_arr(v_linkIndex);
          v_modifiedOn := modifiedOn_arr(v_linkIndex);
          v_required := required_arr(v_linkIndex);
          v_uniqueLinkId := uniqueLinkId_arr(v_linkIndex);
          v_uniqueNDId := uniqueNDId_arr(v_linkIndex);

          v_linkIndex := v_linkIndex + 1;

          -- get uniquelink id from sequence if the one provided is null
          if v_uniqueLinkId = 0 or v_uniqueLinkId = -1 or v_uniqueLinkId is null then
              v_uniqueLinkId := GetNewWCID;
          end if;

          -- pick the primary key for the link from the id_sequence
          v_ida2a2_link := GetNewWCID;
          -- c. insert into relevent link table
          if v_linkType = REFERENCE_LINK then
              v_linkClassName := 'wt.epm.structure.EPMReferenceLink';
              v_referenceType := referenceType_arr(v_reflinkIndex);
              v_reflinkIndex := v_reflinkIndex + 1;
              insert into EPMReferenceLink(ASSTOREDCHILDNAME,
                                       DEPTYPE,
                                       HASIBAVALUES,
                                       REQUIRED,
                                       CLASSNAMEKEYROLEAOBJECTREF,
                                       IDA3A5,
                                       CLASSNAMEKEYROLEBOBJECTREF,
                                       IDA3B5,
                                       CREATESTAMPA2,
                                       MARKFORDELETEA2,
                                       MODIFYSTAMPA2,
                                       CLASSNAMEA2A2,
                                       IDA2A2,
                                       UPDATECOUNTA2,
                                       UPDATESTAMPA2,
                                       BRANCHIDA2TYPEDEFINITIONREFE,
                                       IDA2TYPEDEFINITIONREFERENCE,
                                       UNIQUELINKID,
                                       UNIQUENDID,
                                       REFERENCETYPE)
                            values (v_asStoredChildName,
                            v_depType,
                            0,
                            v_required,
                            parentClassName,
                            v_ida3a5_parent,
                            childClassName,
                            v_ida3b5_child,
                            v_createdOn,
                            0,
                            v_modifiedOn,
                            v_linkClassName,
                            v_ida2a2_link,
                            v_updatecounta2,
                            sysdate,
                            reflinkbranchida2TypeDefRef,
                            reflinkida2TypeDefRef,
                            v_uniqueLinkId,
                            v_uniqueNDId,
                            v_referenceType);
         else -- v_linkType = MEMBER_LINK
             v_linkClassName := 'wt.epm.structure.EPMMemberLink';
             v_identifier := identifier_arr(v_memlinkIndex);
             v_name := name_arr(v_memlinkIndex);
             v_placed := placed_arr(v_memlinkIndex);
             v_quantity := quantity_arr(v_memlinkIndex);
             v_suppressed := suppressed_arr(v_memlinkIndex);
             v_substitute := substitute_arr(v_memlinkIndex);
             v_skeletonMemb := skeletonMemb_arr(v_memlinkIndex);
              v_compNum := compNum_arr(v_memlinkIndex);
              v_compRevNum := compRevNum_arr(v_memlinkIndex);
              v_compLayerIdx := compLayerIdx_arr(v_memlinkIndex);

              v_rcIsNull := rcIsNull_arr(v_memlinkIndex);
              v_rcGeomRestrRecur := rcGeomRestrRecur_arr(v_memlinkIndex);
              v_rcGeomRestr := rcGeomRestr_arr(v_memlinkIndex);
              v_rcScope := rcScope_arr(v_memlinkIndex);
              v_rcViolRestr := rcViolRestr_arr(v_memlinkIndex);

              v_transIsNull := transIsNull_arr(v_memlinkIndex);
              v_e_00 := e_00_arr(v_memlinkIndex);
              v_e_01 := e_01_arr(v_memlinkIndex);
              v_e_02 := e_02_arr(v_memlinkIndex);
              v_e_10 := e_10_arr(v_memlinkIndex);
              v_e_11 := e_11_arr(v_memlinkIndex);
              v_e_12 := e_12_arr(v_memlinkIndex);
              v_e_20 := e_20_arr(v_memlinkIndex);
              v_e_21 := e_21_arr(v_memlinkIndex);
              v_e_22 := e_22_arr(v_memlinkIndex);
              v_e_30 := e_30_arr(v_memlinkIndex);
              v_e_31 := e_31_arr(v_memlinkIndex);
              v_e_32 := e_32_arr(v_memlinkIndex);

             v_memlinkIndex := v_memlinkIndex + 1;

             insert into EPMMemberLink (ANNOTATED,
                                   ASSTOREDCHILDNAME,
                                   DEPTYPE,
                                   FIXED,
                                   HASIBAVALUES,
                                   IDENTIFIER,
                                   NAME,
                                   PLACED,
                                   REQUIRED,
                                   CLASSNAMEKEYROLEAOBJECTREF,
                                   IDA3A5,
                                   CLASSNAMEKEYROLEBOBJECTREF,
                                   IDA3B5,
                                   SUPPRESSED,
                                   SUBSTITUTE,
                                   CREATESTAMPA2,
                                   MARKFORDELETEA2,
                                   MODIFYSTAMPA2,
                                   CLASSNAMEA2A2,
                                   IDA2A2,
                                   UPDATECOUNTA2,
                                   UPDATESTAMPA2,
                                   TRANSFORMISNULL,
                                   ROTATION1_0A7,
                                   ROTATION1_1A7,
                                   ROTATION1_2A7,
                                   ROTATION2_0A7,
                                   ROTATION2_1A7,
                                   ROTATION2_2A7,
                                   ROTATION3_0A7,
                                   ROTATION3_1A7,
                                   ROTATION3_2A7,
                                   TRANSLATION_0A7,
                                   TRANSLATION_1A7,
                                   TRANSLATION_2A7,
                                   REFERENCECONTROLISNULL,
                                   GEOMRESTRB7,
                                   GEOMRESTRRECURSIVEB7,
                                   SCOPEB7,
                                   VIOLRESTRICTIONB7,
                                   COMPLAYERIDX,
                                   COMPNUMBER,
                                   COMPREVNUMBER,
                                   AMOUNTC7,
                                   UNITC7,
                                   BRANCHIDA2TYPEDEFINITIONREFE,
                                   IDA2TYPEDEFINITIONREFERENCE,
                                   UNIQUELINKID,
                                   UNIQUENDID)
                 values (v_annotated,
                 v_asStoredChildName,
                 v_depType,
                 v_fixed,
                 0,
                 v_identifier,
                 v_name,
                 v_placed,
                 v_required,
                 parentClassName,
                 v_ida3a5_parent,
                 childClassName,
                 v_ida3b5_child,
                 v_suppressed,
                 v_substitute,
                 v_createdOn,
                 0,
                 v_modifiedOn,
                 v_linkClassName,
                 v_ida2a2_link,
                 v_updatecounta2,
                 sysdate,
                 v_transIsNull,
                  v_e_00,
                  v_e_01,
                  v_e_02,
                  v_e_10,
                  v_e_11,
                  v_e_12,
                  v_e_20,
                  v_e_21,
                  v_e_22,
                  v_e_30,
                  v_e_31,
                  v_e_32,
                  v_rcIsNull,
                  v_rcGeomRestr,
                  v_rcGeomRestrRecur,
                  v_rcScope,
                  v_rcViolRestr,
                  v_compLayerIdx,
                  v_compNum,
                  v_compRevNum,
                  v_quantity,
                  unit,
                  memlinkbranchida2TypeDefRef,
                  memlinkida2TypeDefRef,
                 v_uniqueLinkId,
                 v_uniqueNDId);
                --using v_ida3b5_child (which is essentially DocumentMaster ID), set DOCSUBTYPE to "SKEL_MODEL"
                if v_skeletonMemb = SKELETON_MEMB_DEP then
                      update epmdocumentmaster set DOCSUBTYPE = SKEL_MODEL
                         where ida2a2 = v_ida3b5_child;
                end if;

          end if; -- if reference or member link
          -- d. insert into deptowcstatus table
          insert into DEPTOWCSTATUS (DGID,
                               DOMAINID,
                               STATUS,
                               ERRID,
                               ERRMSG,
                               LINKTYPE,
                               EPMLINKID,
                               LOADTIME,
                               ATTRSTATUS,
                               ATTRERRID,
                               ATTRERRMSG,
                               ATTRLOADTIME)
                          values(v_depDGID,
                                   v_ilDomId,
                                   MIGRATION_SUCCESS,
                                   0,
                                   null,
                                   v_linkType,
                                   v_ida2a2_link,
                                   sysdate,
                                   null,
                                   null,
                                   null,
                                   null);
      end if; -- if migratable kind of link or not
 -- e. loop complete
    END LOOP;
  else -- UPDATE Action
    v_memlinkIndex := 1;
--    putpipe('index is from '||depDGId_arr.FIRST||' to '||depDGId_arr.LAST);
--    putpipe('required arr is from '||required_arr.FIRST||' to '||required_arr.LAST);
    FOR v_currIndex IN depDGId_arr.FIRST..depDGId_arr.LAST LOOP
      -- get the individual items to update from the arrays
--      putpipe('inside loop, index is : '||v_currIndex);
      v_depDGId := depDGId_arr(v_currIndex);
      v_depWCId := depWCId_arr(v_currIndex);
      v_linkType := linkType_arr(v_currIndex);
      v_asStoredChildName := asStoredChildName_arr(v_currIndex);
      v_depType := depType_arr(v_currIndex);

      v_ida3a5_parent := ida3a5_parent_arr(v_currIndex);
      v_ida3b5_child := ida3b5_child_arr(v_currIndex);
      v_parentDocType := parentDocType_arr(v_currIndex);
      v_childDocType := childDocType_arr(v_currIndex);

      if v_linkType = MIGRATION_CANNOTDO then
        -- update deptowcstatus table with error message
        if v_depType=DEP_T_GENERIC then
          v_message :='As per PDMLink requirement, Pro/Intralink dependency of type DEP_T_GENERIC is not migrated for DGId:'||v_depDGId||' to component ['||
	                                v_asStoredChildName||'] with DepType = ['||
                          v_depType||'].';
        elsif v_parentDocType = WTDOCTYPE or v_childDocType = WTDOCTYPE then
          v_message := 'Can not create Link for DGId:'||v_depDGId||' to component ['||
                            v_asStoredChildName||'] with DepType = ['||
                          v_depType||']. Parent/Child cannot be WTDocuments.';
        else
          v_message := 'Can not create EPMMemberLink / EPMReferenceLink for DGId:'||v_depDGId||' to component [' || v_asStoredChildName ||
                        '] with DepType = [' || v_depType || '] different from Pro_E / USER_DEFINED / USER_BOM.';
        end if;
        update deptowcstatus set status = MIGRATION_CANNOTDO, errmsg = v_message where dgid = v_depDGId and domainid = v_ilDomId;
      elsif v_linkType = MIGRATION_UNFINISHED then
              v_ufQuantity := ufQuantity_arr(v_unfinishedIndex);

              v_unfinishedIndex := v_unfinishedIndex + 1;

                insert into DEPCACHE (DGID,
                                DOMAINID,
                                PARENTEPMID,
                                PARENTDOCTYPE,
                                CHILDEPMID,
                                CHILDDOCTYPE,
                                QUANTITY)
                           values(v_depDGID,
                                  v_ilDomId,
                                  v_ida3a5_parent,
                                  v_parentDocType,
                                  v_ida3b5_child,
                                  v_childDocType,
                                  v_ufQuantity);

           update deptowcstatus set status = MIGRATION_UNFINISHED where dgid = v_depDGId and domainid = v_ilDomId;
      else
--        putpipe('linktype is '||V_linkType);
        v_required := required_arr(v_currIndex);
        v_uniqueLinkId := uniqueLinkId_arr(v_currIndex);
        v_uniqueNDId := uniqueNDId_arr(v_currIndex);
        -- set uniqLinkId to null if not provided by intralink so update will not change it
        if v_uniqueLinkId = 0 or v_uniqueLinkId = -1 then
          v_uniqueLinkId := NULL;
        end if;

        -- update the epmmemberlink or epmreferencelink table
        if v_linkType = REFERENCE_LINK then
          v_linkClassName := 'wt.epm.structure.EPMReferenceLink';
          update EPMReferenceLink set ASSTOREDCHILDNAME = v_asStoredChildName,
                                      DEPTYPE = v_depType,
                                      REQUIRED = v_required,
                                      -- MODIFYSTAMPA2 = sysdate, should we change this??
                                      UPDATECOUNTA2 = UPDATECOUNTA2 + 1,
                                      UPDATESTAMPA2 = sysdate,
                                      UNIQUELINKID = nvl(v_uniqueLinkId, uniquelinkid),
                                      UNIQUENDID = v_uniqueNDId
                                where IDA2A2 = v_depWCId
                                  and CLASSNAMEA2A2 = v_linkClassName;
        else -- v_linkType = MEMBER_LINK
          v_linkClassName := 'wt.epm.structure.EPMMemberLink';
          v_identifier := identifier_arr(v_memlinkIndex);
          v_name := name_arr(v_memlinkIndex);
          v_placed := placed_arr(v_memlinkIndex);
          v_quantity := quantity_arr(v_memlinkIndex);
          v_suppressed := suppressed_arr(v_memlinkIndex);

          v_compNum := compNum_arr(v_memlinkIndex);
          v_compRevNum := compRevNum_arr(v_memlinkIndex);
          v_compLayerIdx := compLayerIdx_arr(v_memlinkIndex);

          v_rcIsNull := rcIsNull_arr(v_memlinkIndex);
          v_rcGeomRestrRecur := rcGeomRestrRecur_arr(v_memlinkIndex);
          v_rcGeomRestr := rcGeomRestr_arr(v_memlinkIndex);
          v_rcScope := rcScope_arr(v_memlinkIndex);
          v_rcViolRestr := rcViolRestr_arr(v_memlinkIndex);

          v_transIsNull := transIsNull_arr(v_memlinkIndex);
          v_e_00 := e_00_arr(v_memlinkIndex);
          v_e_01 := e_01_arr(v_memlinkIndex);
          v_e_02 := e_02_arr(v_memlinkIndex);
          v_e_10 := e_10_arr(v_memlinkIndex);
          v_e_11 := e_11_arr(v_memlinkIndex);
          v_e_12 := e_12_arr(v_memlinkIndex);
          v_e_20 := e_20_arr(v_memlinkIndex);
          v_e_21 := e_21_arr(v_memlinkIndex);
          v_e_22 := e_22_arr(v_memlinkIndex);
          v_e_30 := e_30_arr(v_memlinkIndex);
          v_e_31 := e_31_arr(v_memlinkIndex);
          v_e_32 := e_32_arr(v_memlinkIndex);

          v_memlinkIndex := v_memlinkIndex + 1;

          update EPMMemberLink set ASSTOREDCHILDNAME = v_asStoredChildName,
                                     DEPTYPE = v_depType,
                                     FIXED = v_fixed,
                                     IDENTIFIER = v_identifier,
                                     NAME = v_name,
                                     PLACED = v_placed,
                                     REQUIRED = v_required,
                                     SUPPRESSED = v_suppressed,
                                     UPDATECOUNTA2 = v_updatecounta2 + 1,
                                     UPDATESTAMPA2 = sysdate,
                                     TRANSFORMISNULL = v_transIsNull,
                                     ROTATION1_0A7 = v_e_00,
                                     ROTATION1_1A7 = v_e_01,
                                     ROTATION1_2A7 = v_e_02,
                                     ROTATION2_0A7 = v_e_10,
                                     ROTATION2_1A7 = v_e_11,
                                     ROTATION2_2A7 = v_e_12,
                                     ROTATION3_0A7 = v_e_20,
                                     ROTATION3_1A7 = v_e_21,
                                     ROTATION3_2A7 = v_e_22,
                                     TRANSLATION_0A7 = v_e_30,
                                     TRANSLATION_1A7 = v_e_31,
                                     TRANSLATION_2A7 = v_e_32,
                                     REFERENCECONTROLISNULL = v_rcIsNull,
                                     GEOMRESTRB7 = v_rcGeomRestr,
                                     GEOMRESTRRECURSIVEB7 = v_rcGeomRestrRecur,
                                     SCOPEB7 = v_rcScope,
                                     VIOLRESTRICTIONB7 = v_rcViolRestr,
                                     COMPLAYERIDX = v_compLayerIdx,
                                     COMPNUMBER = v_compNum,
                                     COMPREVNUMBER = v_compRevNum,
                                     AMOUNTC7 = v_quantity,
                                     UNIQUELINKID = nvl(v_uniqueLinkId, uniquelinkid),
                                     UNIQUENDID = v_uniqueNDId
                              where  IDA2A2 = v_depWCId
                                and  CLASSNAMEA2A2 = v_linkClassName;
        end if;

        -- update deptowcstatus table
        update deptowcstatus set status = MIGRATION_SUCCESS where dgid = v_depDGId and domainid = v_ilDomId;
      end if;
    end loop;
  end if;
 return 1;
end insertOrUpdateLinks;

FUNCTION GetNewWCID RETURN NUMBER IS

BEGIN

  gbl_curr_seq_id := gbl_curr_seq_id + 1;

  if gbl_curr_seq_id = gbl_end_seq_id then -- we need to get a new id from the sequence
    select id_sequence.NEXTVAL into gbl_curr_seq_id from dual;
    gbl_end_seq_id := gbl_curr_seq_id + 100;
  end if;
  return gbl_curr_seq_id;

END GetNewWCID;
/*
  Procedure insertInStatusTables(
              ilDomainId          number,
              piIdArr           MY_TABLE_OF_NUMBER,
              dMIdArr           MY_TABLE_OF_NUMBER,
              piStatusArr       MY_TABLE_OF_NUMBER,
              pivIdArr          MY_TABLE_OF_NUMBER,
              docIdArr          MY_TABLE_OF_NUMBER,
              dgIdArr           MY_TABLE_OF_NUMBER,
              linkIdArr         MY_TABLE_OF_NUMBER,
              depTypeArr        MY_TABLE_OF_NUMBER  ) IS

  MIG_UPDATING CONSTANT number := 5; -- from ILObject.java

BEGIN

  FORALL i in piIdArr.FIRST..piIdArr.LAST
    insert into PItoWCStatus(PIId, DomainId, EPMDocumentMasterId, Status)
    values(piIdArr(i), ilDomainId, dMIdArr(i), piStatusArr(i));

  FORALL i in pivIdArr.FIRST..pivIdArr.LAST
    insert into PIVtoWCStatus(PIVId, DomainId, EPMDocumentId, Status)
    values(pivIdArr(i), ilDomainId, docIdArr(i), MIG_UPDATING);

  FORALL i in dgIdArr.FIRST..dgIdArr.LAST
    insert into DeptoWCStatus(DGId, DomainId, EPMLinkId, LinkType, Status)
    values(dgIdArr(i), ilDomainId, linkIdArr(i), depTypeArr(i), MIG_UPDATING);
END insertInStatusTables; */

/*--------------------------------------------------------------------------------------------------*/

FUNCTION DeleteIBAValuesByHolders(iba_holder_list IN TABLE_OF_NUMBER,
                                    iba_holder_classname IN VARCHAR2) RETURN NUMBER IS

  delete_count NUMBER := 0;

BEGIN

  BEGIN

    FORALL i IN 1..iba_holder_list.count
    DELETE FROM  BooleanValue
          WHERE  IDA3A4 = iba_holder_list(i) AND
                 CLASSNAMEKEYA4 = iba_holder_classname;
    delete_count := delete_count + SQL%ROWCOUNT;

    FORALL i IN 1..iba_holder_list.count
    DELETE FROM  FloatValue
          WHERE  IDA3A4 = iba_holder_list(i) AND
                 CLASSNAMEKEYA4 = iba_holder_classname;
    delete_count := delete_count + SQL%ROWCOUNT;

    FORALL i IN 1..iba_holder_list.count
    DELETE FROM  IntegerValue
          WHERE  IDA3A4 = iba_holder_list(i) AND
                 CLASSNAMEKEYA4 = iba_holder_classname;
    delete_count := delete_count + SQL%ROWCOUNT;

    FORALL i IN 1..iba_holder_list.count
    DELETE FROM  StringValue
          WHERE  IDA3A4 = iba_holder_list(i) AND
                 CLASSNAMEKEYA4 = iba_holder_classname;
    delete_count := delete_count + SQL%ROWCOUNT;

    FORALL i IN 1..iba_holder_list.count
    DELETE FROM  TimeStampValue
          WHERE  IDA3A4 = iba_holder_list(i) AND
                 CLASSNAMEKEYA4 = iba_holder_classname;
    delete_count := delete_count + SQL%ROWCOUNT;

    FORALL i IN 1..iba_holder_list.count
    DELETE FROM  EPMParameterMap
          WHERE  IDA3A4 = iba_holder_list(i) AND
                 CLASSNAMEKEYA4 = iba_holder_classname;

  EXCEPTION  -- exception handlers begin
    WHEN OTHERS THEN  -- handles all other errors
        RETURN -1;

  END;

  RETURN delete_count;
END deleteIBAValuesByHolders;
/*--------------------------------------------------------------------------------------------------*/


FUNCTION InsertEPMParameterMapValues(param_map_list IN INSERT_EPM_PARAMETER_MAP_LIST,
                                     iba_holder_classname IN VARCHAR2) RETURN NUMBER IS
  insert_count NUMBER := 0;

BEGIN
  BEGIN
        INSERT INTO EPMParameterMap (HIERARCHYIDB4,CLASSNAMEKEYB4,IDA3B4,
             PARAMETERNAME,CLASSNAMEKEYA4,IDA3A4,
            CREATESTAMPA2,MODIFYSTAMPA2,CLASSNAMEA2A2,IDA2A2,UPDATECOUNTA2,
            UPDATESTAMPA2,MARKFORDELETEA2)
        select	hierarchyIDB4,
            classnamekeyB4,
                 idA3B4,
                 parameterName,
             iba_holder_classname,
             IDA3A4,
             sysdate,sysdate,
                 'wt.epm.attributes.EPMParameterMap',
                 getNewWCId,1,sysdate,0
    from table(cast(param_map_list as INSERT_EPM_PARAMETER_MAP_LIST));

  insert_count := SQL%ROWCOUNT;

  EXCEPTION  -- exception handlers begin
    WHEN OTHERS THEN  -- handles all other errors
        RETURN -1;

  END;

  RETURN insert_count;

END InsertEPMParameterMapValues;

procedure countEPMObjects(
        ilDomainId IN number,
        sessionId IN varchar2,
        epmDocMCount OUT number,
        epmDocCount OUT number,
        wtDocMCount OUT number,
        wtDocCount OUT number,
        membLinkCount OUT number,
        refLinkCount OUT number,
        fileItemCount OUT number,
        epmBLCountDoc OUT number,
        epmBLCountPart OUT number,
        loCount OUT number,
        lovCount OUT number,
        epmDocMAttrs OUT number,
        epmDocAttrs OUT number,
        linkAttrs OUT number,
        wtPartCount OUT number) IS

  piStTable varchar2(40);
  pivStTable varchar2(40);
  loStTable varchar2(40);
  lovStTable varchar2(40);
  depStTable varchar2(40);
  sqlstmt varchar2(400);
  wtPartCnt1 NUMBER := 0;
  wtPartCnt2 NUMBER := 0;
  v_lovFileItemCount number := 0;

BEGIN
--  piStTable := 'pitowcstatus_'||sessionId;
--  pivStTable := 'pivtowcstatus_'||sessionId;
--  depStTable := 'deptowcstatus_'||sessionId;
--  sqlstmt := 'create table '||piStTable||' as '||
--             'select piid, domainid, documenttype, status, epmdocumentmasterid, attrstatus '||
--             ' from pitowcstatus where domainid = '||ilDomainId;
--  execute immediate sqlstmt;
--  sqlstmt := 'create index piStIdx'||sessionId||' on '||piStTable||' (epmdocumentmasterid ASC)';
--  execute immediate sqlstmt;
--  sqlstmt := 'create table '||pivStTable||' as '||
--             'select pivid, domainid, documenttype, status, epmdocumentid, attrstatus '||
--             ' from pivtowcstatus where domainid = '||ilDomainId;
--  execute immediate sqlstmt;
--  sqlstmt := 'create index pivStIdx'||sessionId||' on '||pivStTable||' (epmdocumentid ASC)';
--  execute immediate sqlstmt;
--  sqlstmt := 'create table '||depStTable||' as '||
--             'select dgid, domainid, linktype, status, epmlinkid, attrstatus '||
--             ' from deptowcstatus where domainid = '||ilDomainId;
--  execute immediate sqlstmt;
--  sqlstmt := 'create index depStIdx'||sessionId||' on '||depStTable||' (epmlinkId ASC)';
--  execute immediate sqlstmt;
--
--  sqlstmt := 'select count(ida2a2) from epmdocumentmaster m, '||piStTable||' st '||
--             'where m.ida2a2 = st.epmdocumentmasterid and st.documenttype = '||EPMDOCTYPE;
--  execute immediate sqlstmt into epmDocMCount;
    select count(epmdocumentmasterid) into epmDocMCount from pitowcstatus
     where documenttype = EPMDOCTYPE
       and (status = MIGRATION_SUCCESS or status = MIGRATION_UNFINISHED) and domainid = ilDomainId;
--  sqlstmt := 'select count(ida2a2) from wtdocumentmaster m, '||piStTable||' st '||
--             'where m.ida2a2 = st.epmdocumentmasterid and st.documenttype = '||WTDOCTYPE;
--  execute immediate sqlstmt into wtDocMCount;
    select count(epmdocumentmasterid) into wtDocMCount from pitowcstatus
     where documenttype = WTDOCTYPE
       and (status = MIGRATION_SUCCESS or status = MIGRATION_UNFINISHED) and domainid = ilDomainId;
--  sqlstmt := 'select count(ida2a2) from epmdocument d, '||pivStTable||' st '||
--             'where d.ida2a2 = st.epmdocumentid and st.documenttype = '||EPMDOCTYPE;
--  execute immediate sqlstmt into epmDocCount;
    select count(epmdocumentid) into epmDocCount from pivtowcstatus
     where documenttype = EPMDOCTYPE and status = MIGRATION_SUCCESS and domainid = ilDomainId;
--  sqlstmt := 'select count(ida2a2) from wtdocument d, '||pivStTable||' st '||
--             'where d.ida2a2 = st.epmdocumentid and st.documenttype = '||WTDOCTYPE;
--  execute immediate sqlstmt into wtDocCount;
    select count(epmdocumentid) into wtDocCount from pivtowcstatus
     where documenttype = WTDOCTYPE and status = MIGRATION_SUCCESS and domainid = ilDomainId;
--  sqlstmt := 'select count(ida2a2) from epmmemberlink l, '||depStTable||' st '||
--             'where l.ida2a2 = st.epmlinkid and st.linktype = '||MEMBER_LINK;
--  execute immediate sqlstmt into membLinkCount;
    select count(epmlinkid) into membLinkCount from deptowcstatus
     where linktype = MEMBER_LINK and status = MIGRATION_SUCCESS and domainid = ilDomainId;
--  sqlstmt := 'select count(ida2a2) from epmreferencelink l, '||depStTable||' st '||
--             'where l.ida2a2 = st.epmlinkid and st.linktype = '||REFERENCE_LINK;
--  execute immediate sqlstmt into refLinkCount;
    select count(epmlinkid) into refLinkCount from deptowcstatus
     where linktype = REFERENCE_LINK and status = MIGRATION_SUCCESS and domainid = ilDomainId;

    select count(distinct fileid) into fileItemCount from pivtowcstatus
     where filestatus = MIGRATION_SUCCESS and domainid = ilDomainId;

     select count(distinct fileid) into v_lovFileItemCount from lovtowcstatus
     where filestatus = MIGRATION_SUCCESS and domainid = ilDomainId;

     fileItemCount := fileItemCount + v_lovFileItemCount;

    select count(distinct blid) into epmBLCountDoc from baselinetowcstatus
     where status = MIGRATION_UNFINISHED and domainid = ilDomainId;

    select count(distinct blid) into epmBLCountPart from baselinetowcstatus
     where status = MIGRATION_SUCCESS and domainid = ilDomainId;

--
--  sqlstmt := 'select count(piid) from '||piStTable||' where '||
--             'status = '||MIGRATION_SUCCESS||' and (attrstatus <> '||MIGRATION_SUCCESS||
--             ' or attrstatus is null)';
--  execute immediate sqlstmt into epmDocMAttrs;
    select count(piid) into epmDocMAttrs from pitowcstatus
     where status = MIGRATION_SUCCESS and documenttype <> SECDOCTYPE
       and (attrstatus <> MIGRATION_SUCCESS or attrstatus is null) and domainid = ilDomainId;
--
--  sqlstmt := 'select count(pivid) from '||pivStTable||' where '||
--             'status = '||MIGRATION_SUCCESS||' and (attrstatus <> '||MIGRATION_SUCCESS||
--             ' or attrstatus is null)';
--  execute immediate sqlstmt into epmDocAttrs;
    select count(pivid) into epmDocAttrs from pivtowcstatus
     where status = MIGRATION_SUCCESS and documenttype <> SECDOCTYPE
       and (attrstatus <> MIGRATION_SUCCESS or attrstatus is null) and domainid = ilDomainId;

    select count(loid) into loCount from lotowcstatus
     where (status = MIGRATION_SUCCESS or status = MIGRATION_UNFINISHED) and domainid = ilDomainId;

    select count(lovid) into lovCount from lovtowcstatus
     where (status = MIGRATION_SUCCESS or status = MIGRATION_UNFINISHED) and domainid = ilDomainId;

--
--  sqlstmt := 'select count(dgid) from '||depStTable||' where '||
--             'status = '||MIGRATION_SUCCESS||' and (attrstatus <> '||MIGRATION_SUCCESS||
--             ' or attrstatus is null)';
--  execute immediate sqlstmt into linkAttrs;
    select count(dgid) into linkAttrs from deptowcstatus
     where status = MIGRATION_SUCCESS
       and (attrstatus <> MIGRATION_SUCCESS or attrstatus is null) and domainid = ilDomainId;

         select count(piid) into wtPartCnt1 from pitowcstatus p
             where partstatus in (MIGRATION_SUCCESS, MIGRATION_CANNOTDO)  and domainid = ilDomainId
             and documenttype in (EPMDOCTYPE, WTDOCTYPE) and status = MIGRATION_SUCCESS
             and exists (select 1 from createpartonmig where piid = p.piid and domainid = p.domainId);

    select count(distinct(piid)) into wtPartCnt2 from createpartonmig p
    where domainid = ilDomainId
    and exists(select piid from pitowcstatus where piid = p.piid and documenttype in (EPMDOCTYPE, WTDOCTYPE) and status = MIGRATION_SUCCESS and domainid = p.domainId);

    IF wtPartCnt2 = 0 THEN
      wtPartCount:= 0;
    ELSE
    wtPartCount:= (wtPartCnt2 - wtPartCnt1);
    END IF;

--
--  sqlstmt := 'drop table '||piStTable;
--  execute immediate sqlstmt;
--  sqlstmt := 'drop table '||pivStTable;
--  execute immediate sqlstmt;
--  sqlstmt := 'drop table '||depStTable;
--  execute immediate sqlstmt;

END countEPMObjects;

FUNCTION InsertIBAValues(ibaHolderClassName VARCHAR2,
                         referenceClassName VARCHAR2,
                         referenceId NUMBER,

                         floatValueClassName VARCHAR2,
                         booleanValueClassName VARCHAR2,
                         integerValueClassName VARCHAR2,
                         stringValueClassName VARCHAR2,
                         timestampValueClassName VARCHAR2,

                         attrDefCount NUMBER,
                         definitionClassNames uzy_mig_TABLE_OF_VARCHAR2_200,
                         definitionIds TABLE_OF_NUMBER,
                         definitionHIds uzy_mig_TABLE_OF_VARCHAR2_150,

                         boolCount NUMBER,
                         boolHolderIds TABLE_OF_NUMBER,
                         boolAttrDefIds TABLE_OF_NUMBER,
                         boolValues TABLE_OF_NUMBER,

                         float_precision NUMBER,
                         flCount NUMBER,
                         flHolderIds TABLE_OF_NUMBER,
                         flAttrDefIds TABLE_OF_NUMBER,
                         flValues TABLE_OF_NUMBER,

                         intCount NUMBER,
                         intHolderIds TABLE_OF_NUMBER,
                         intAttrDefIds TABLE_OF_NUMBER,
                         intValues TABLE_OF_NUMBER,

                         strCount NUMBER,
                         strHolderIds TABLE_OF_NUMBER,
                         strAttrDefIds TABLE_OF_NUMBER,
                         strValues uzy_mig_TABLE_OF_VARCHAR2_6000,

                         tsCount NUMBER,
                         tsHolderIds TABLE_OF_NUMBER,
                         tsAttrDefIds TABLE_OF_NUMBER,
                         tsValues TABLE_OF_DATE,

                         paramMapClassName VARCHAR2,
                         pMapHolderIds TABLE_OF_NUMBER,
                         pMapNames uzy_mig_TABLE_OF_VARCHAR2_200,
                         pMapDefIds TABLE_OF_NUMBER) RETURN NUMBER IS

  insert_count NUMBER := 0; j number := 0; defId number; k number := 0;
  defHId varchar2(150); paramName varchar2(200); defClassName varchar2(200);

  hidArray TABLE_OF_NUMBER := TABLE_OF_NUMBER();
  idArray TABLE_OF_NUMBER := TABLE_OF_NUMBER();
  defClassNameArray uzy_mig_TABLE_OF_VARCHAR2_6000 := uzy_mig_TABLE_OF_VARCHAR2_6000();

  --defClassNames ArrayVarchar200;
  defClassNames ArrayVarcharV6;
  --defHids ArrayVarchar150;
  defHids ArrayVarcharV6;
  linkUpdateIds ArrayNumber;

  v_time1 timestamp := null;
  updateIBA boolean := false; membTable boolean := false; i_upd number; updct number;
  createPMap boolean := false; allCt number := 0;
  v_temp_j number;

BEGIN
--  select systimestamp into v_time1 from dual;
--  putpipe('start:   '||to_char(v_time1, 'hh:mi:ss.ff3'));

  if ibaHolderClassName = 'wt.epm.structure.EPMMemberLink' then
    updateIBA := true;
    membTable := true;
  elsif ibaHolderClassName = 'wt.epm.structure.EPMReferenceLink' then
    updateIBA := true;
    membTable := false;
  end if;

  if pMapDefIds.COUNT > 0 then
    createPMap := true;
  end if;

  linkUpdateIds.delete;
  defClassNames.delete;
  defHids.delete;
  v_temp_j := 0;
  for j in definitionIds.FIRST..definitionIds.LAST loop
    v_temp_j := j;
    defId := definitionIds(j);
    --defClassNames(defId) := definitionClassNames(j);
    defClassNames(to_char(defId)) := definitionClassNames(j);
    --defHIds(defId) := definitionHIds(j);
    defHIds(to_char(defId)) := definitionHIds(j);
  end loop;

  -- create boolean arrays
  if boolCount > 0 then
    hidArray.extend(boolCount);
    defClassNameArray.extend(boolCount);
    idArray.extend(boolCount);
    for j in boolHolderIds.FIRST..boolHolderIds.LAST loop
      defId := boolAttrDefIds(j);
      hidArray(j) := defHids(to_char(defId));
      defClassNameArray(j) := defClassNames(to_char(defId));
      idArray(j) := GetNewWCID;
      if updateIBA then
        linkUpdateIds(linkUpdateIds.COUNT + 1) := boolHolderIds(j);
      end if;
    end loop;

    forall j in boolHolderIds.FIRST..boolHolderIds.LAST
        INSERT INTO BooleanValue (CLASSNAMEKEYA5,IDA3A5,HIERARCHYIDA6,
                  CLASSNAMEKEYA6,IDA3A6,CLASSNAMEKEYA4,IDA3A4,CREATESTAMPA2,
                  MODIFYSTAMPA2,CLASSNAMEA2A2,IDA2A2,UPDATECOUNTA2,UPDATESTAMPA2,
                  VALUE,MARKFORDELETEA2)
             values (referenceClassName, referenceId, hidArray(j),
               defClassNameArray(j), boolAttrDefIds(j), ibaHolderClassName, boolHolderIds(j), sysdate,
               sysdate, booleanValueClassName, idArray(j), 1, sysdate, boolValues(j), 0);

    insert_count := insert_count + idArray.Count;
  end if;

  -- create float arrays
  if flCount > 0 then
    hidArray.delete;
    hidArray.extend(flCount);
    defClassNameArray.delete;
    defClassNameArray.extend(flCount);
    idArray.delete;
    idArray.extend(flCount);
    for j in flHolderIds.FIRST..flHolderIds.LAST loop
      defId := flAttrDefIds(j);
      hidArray(j) := defHids(to_char(defId));
      defClassNameArray(j) := defClassNames(to_char(defId));
      idArray(j) := GetNewWCID;
      if updateIBA then
        linkUpdateIds(linkUpdateIds.COUNT + 1) := flHolderIds(j);
      end if;
    end loop;

    forall j in flHolderIds.FIRST..flHolderIds.LAST
        INSERT INTO FloatValue (CLASSNAMEKEYA5,IDA3A5,HIERARCHYIDA6, CLASSNAMEKEYA6,
               IDA3A6,WTPRECISION,CLASSNAMEKEYA4,IDA3A4,CREATESTAMPA2,
                  MODIFYSTAMPA2,CLASSNAMEA2A2,IDA2A2,UPDATECOUNTA2,UPDATESTAMPA2,
                  VALUE,MARKFORDELETEA2)
             values (referenceClassName, referenceId, hidArray(j), defClassNameArray(j),
               flAttrDefIds(j), float_precision, ibaHolderClassName, flHolderIds(j), sysdate,
               sysdate, floatValueClassName, idArray(j), 1, sysdate, flValues(j), 0);

    insert_count := insert_count + idArray.Count;
  end if;

  -- create int arrays
  if intCount > 0 then
    hidArray.delete;
    hidArray.extend(intCount);
    defClassNameArray.delete;
    defClassNameArray.extend(intCount);
    idArray.delete;
    idArray.extend(intCount);
    for j in intHolderIds.FIRST..intHolderIds.LAST loop
      defId := intAttrDefIds(j);
      hidArray(j) := defHids(to_char(defId));
      defClassNameArray(j) := defClassNames(to_char(defId));
      idArray(j) := GetNewWCID;
      if updateIBA then
        linkUpdateIds(linkUpdateIds.COUNT + 1) := intHolderIds(j);
      end if;
    end loop;

    forall j in intHolderIds.FIRST..intHolderIds.LAST
        INSERT INTO IntegerValue (CLASSNAMEKEYA5,IDA3A5,HIERARCHYIDA6, CLASSNAMEKEYA6,
               IDA3A6,CLASSNAMEKEYA4,IDA3A4,CREATESTAMPA2,
                  MODIFYSTAMPA2,CLASSNAMEA2A2,IDA2A2,UPDATECOUNTA2,UPDATESTAMPA2,
                  VALUE,MARKFORDELETEA2)
             values (referenceClassName, referenceId, hidArray(j), defClassNameArray(j),
               intAttrDefIds(j), ibaHolderClassName, intHolderIds(j), sysdate,
               sysdate, integerValueClassName, idArray(j), 1, sysdate, intValues(j), 0);

    insert_count := insert_count + idArray.Count;
  end if;

  -- create string arrays
  if strCount > 0 then
    hidArray.delete;
    hidArray.extend(strCount);
    defClassNameArray.delete;
    defClassNameArray.extend(strCount);
    idArray.delete;
    idArray.extend(strCount);
    for j in strHolderIds.FIRST..strHolderIds.LAST loop
      defId := strAttrDefIds(j);
      hidArray(j) := defHids(to_char(defId));
      defClassNameArray(j) := defClassNames(to_char(defId));
      idArray(j) := GetNewWCID;
      if updateIBA then
        linkUpdateIds(linkUpdateIds.COUNT + 1) := strHolderIds(j);
      end if;
    end loop;

    forall j in strHolderIds.FIRST..strHolderIds.LAST
        INSERT INTO StringValue (CLASSNAMEKEYA5,IDA3A5,HIERARCHYIDA6, CLASSNAMEKEYA6,
               IDA3A6,CLASSNAMEKEYA4,IDA3A4,CREATESTAMPA2,
                  MODIFYSTAMPA2,CLASSNAMEA2A2,IDA2A2,UPDATECOUNTA2,UPDATESTAMPA2,
                  VALUE2,VALUE,MARKFORDELETEA2)
             values (referenceClassName, referenceId, hidArray(j), defClassNameArray(j),
               strAttrDefIds(j), ibaHolderClassName, strHolderIds(j), sysdate,
               sysdate, stringValueClassName, idArray(j), 1, sysdate, strValues(j), UPPER(strValues(j)), 0);

    insert_count := insert_count + idArray.Count;
  end if;

  -- create timestamp arrays
  if tsCount > 0 then
    hidArray.delete;
    hidArray.extend(tsCount);
    defClassNameArray.delete;
    defClassNameArray.extend(tsCount);
    idArray.delete;
    idArray.extend(tsCount);
    for j in tsHolderIds.FIRST..tsHolderIds.LAST loop
      defId := tsAttrDefIds(j);
      hidArray(j) := defHids(to_char(defId));
      defClassNameArray(j) := defClassNames(to_char(defId));
      idArray(j) := GetNewWCID;
      if updateIBA then
        linkUpdateIds(linkUpdateIds.COUNT + 1) := tsHolderIds(j);
      end if;
    end loop;

    forall j in tsHolderIds.FIRST..tsHolderIds.LAST
        INSERT INTO TimestampValue (CLASSNAMEKEYA5,IDA3A5,HIERARCHYIDA6, CLASSNAMEKEYA6,
               IDA3A6,CLASSNAMEKEYA4,IDA3A4,CREATESTAMPA2,
                  MODIFYSTAMPA2,CLASSNAMEA2A2,IDA2A2,UPDATECOUNTA2,UPDATESTAMPA2,
                  VALUE,MARKFORDELETEA2)
             values (referenceClassName, referenceId, hidArray(j), defClassNameArray(j),
               tsAttrDefIds(j), ibaHolderClassName, tsHolderIds(j), sysdate,
               sysdate, timestampValueClassName, idArray(j), 1, sysdate, tsValues(j), 0);

    insert_count := insert_count + idArray.Count;
  end if;

  -- insert into epmparametermap if necessary
  if createPMap then
    for j in pMapDefIds.FIRST..pMapDefIds.LAST loop
      paramName := pMapNames(j);
      defId := pMapDefIds(j);
      defHId := defHids(to_char(defId));
      defClassName := defClassNames(to_char(defId));

      allCt := pMapHolderIds.COUNT;
      idArray.delete;
      idArray.extend(allCt);
      for k IN 1..allCt loop
        idArray(k) := getNewWCId;
      end loop;
      forall k IN 1..allCt
                INSERT INTO EPMParameterMap (HIERARCHYIDB4,CLASSNAMEKEYB4,IDA3B4,
                     PARAMETERNAME,CLASSNAMEKEYA4,IDA3A4,
                    CREATESTAMPA2,MODIFYSTAMPA2,CLASSNAMEA2A2,IDA2A2,UPDATECOUNTA2,
                    UPDATESTAMPA2,MARKFORDELETEA2)
                values (defHid, defClassName, defId, paramName,
                        ibaHolderClassName, pMapHolderIds(k),
                        sysdate, sysdate, paramMapClassName, idArray(k), 1,
                        sysdate, 0);

        end loop;
  end if;

  -- update hasibavalues flag in link tables if necessary
  if updateIBA then
    updct := linkUpdateIds.COUNT;
    if updct > 0 then
      if membTable then
        forall i_upd IN 1..updct
          update EPMMemberLink set hasibavalues = 1 where ida2a2 = linkUpdateIds(i_upd);
      else
        forall i_upd IN 1..updct
          update EPMReferenceLink set hasibavalues = 1 where ida2a2 = linkUpdateIds(i_upd);
      end if;
    end if;
  end if;

--  select systimestamp into v_time1 from dual;
--  putpipe('end:  '||to_char(v_time1, 'hh:mi:ss.ff3'));
  return insert_count;

--EXCEPTION  -- exception handlers begin
--    WHEN OTHERS THEN  -- handles all other errors
--        return -1;

END InsertIBAValues;


FUNCTION migInsertAsStoredMembers (as_stored_owner_oid_list IN MIG_EPM_AS_STORED_MEMBER_TABLE,
                                   as_stored_epmmem_oid_list IN MIG_EPM_AS_STORED_MEMBER_TABLE,
                                   as_stored_wtmem_oid_list IN MIG_EPM_AS_STORED_MEMBER_TABLE) RETURN NUMBER IS

    total_rows NUMBER;


  BEGIN

      UPDATE EPMAsStoredMember emem
      SET emem.owner = 0
      WHERE emem.ida3b5 in (select id from table(cast(as_stored_owner_oid_list as MIG_EPM_AS_STORED_MEMBER_TABLE)))
      and emem.owner=1;

      INSERT INTO EPMAsStoredMember (classnamekeyroleAObjectRef,
                                   idA3A5,
                                   classnamekeyroleBObjectRef,
                                   idA3B5,
                                   owner, createStampA2, modifyStampA2, classnameA2A2,
                                   idA2A2, updateCountA2,  updateStampA2, markForDeleteA2)
      select 'wt.epm.workspaces.EPMAsStoredConfig',
              oid,
             'wt.epm.EPMDocument',
              id,
             1, sysdate, sysdate, 'wt.epm.workspaces.EPMAsStoredMember', getNewWCId(), 1, sysdate, 0
      from table(cast(as_stored_owner_oid_list as MIG_EPM_AS_STORED_MEMBER_TABLE));

    total_rows := SQL%ROWCOUNT;

    INSERT INTO EPMAsStoredMember (classnamekeyroleAObjectRef,
                                   idA3A5,
                                   classnamekeyroleBObjectRef,
                                   idA3B5,
                                   owner, createStampA2, modifyStampA2, classnameA2A2,
                                   idA2A2, updateCountA2,  updateStampA2, markForDeleteA2)
      select 'wt.epm.workspaces.EPMAsStoredConfig',
              oid,
             'wt.epm.EPMDocument',
              id,
             0, sysdate, sysdate, 'wt.epm.workspaces.EPMAsStoredMember', getNewWCId(), 1, sysdate, 0
      from table(cast(as_stored_epmmem_oid_list as MIG_EPM_AS_STORED_MEMBER_TABLE));

    total_rows := total_rows + SQL%ROWCOUNT;

    INSERT INTO EPMAsStoredMember (classnamekeyroleAObjectRef,
                                   idA3A5,
                                   classnamekeyroleBObjectRef,
                                   idA3B5,
                                   owner, createStampA2, modifyStampA2, classnameA2A2,
                                   idA2A2, updateCountA2,  updateStampA2, markForDeleteA2)
      select 'wt.epm.workspaces.EPMAsStoredConfig',
              oid,
             'wt.doc.WTDocument',
              id,
             0, sysdate, sysdate, 'wt.epm.workspaces.EPMAsStoredMember', getNewWCId(), 1, sysdate, 0
      from table(cast(as_stored_wtmem_oid_list as MIG_EPM_AS_STORED_MEMBER_TABLE));

    total_rows := total_rows + SQL%ROWCOUNT;

  RETURN total_rows ;

--    EXCEPTION  -- exception handlers begin
--    WHEN OTHERS THEN        -- handles all other errors
--          RETURN -1;

END migInsertAsStoredMembers;


--

FUNCTION bitor(p_dec1 number, p_dec2 number) return number is
BEGIN
  return p_dec1-bitand(p_dec1,p_dec2)+p_dec2;
END bitor;

--

FUNCTION bitxor(p_dec1 number, p_dec2 number) return number is
BEGIN
  return bitor(p_dec1,p_dec2)-bitand(p_dec1,p_dec2);
  -- or you could use: return p_dec1-2*bitand(p_dec1,p_dec2)+p_dec2;
END bitxor;

---

FUNCTION markForMerge (ilDomainId VARCHAR2) return NUMBER IS

  v_selPIstmt VARCHAR2(4000);
  v_selPIVstmt VARCHAR2(4000);
  v_selPIVWithNoMatchingDoc VARCHAR2(4000);
  v_selDupDepStmt VARCHAR2(4000);
  v_updateDupDepStmt VARCHAR2(4000);
  v_insertDepStmt VARCHAR2(4000);
  v_insertThirdPartyDataStmt VARCHAR2(4000);
  v_delDupDepIfUnion VARCHAR2(4000);
  piv_insertstmt VARCHAR2(4000);
  pi_insertstmt VARCHAR2(4000);
  pidupUpdate_stmt VARCHAR2(4000);
  pivdupUpdate_stmt VARCHAR2(4000);
  pivSecFileStatusUpdate_stmt VARCHAR2(4000);
  piid NUMBER;
  status NUMBER;
  docmasterid NUMBER;
  ilmaster NUMBER(1);
  pidupInfo RefCur;
  pivdupInfo RefCur;
  depDupInfo RefCur;
  allPIVMatch NUMBER(1);
  noMatchCount NUMBER;
  pivid NUMBER;
  pivid2 NUMBER;
  epmdocumentid NUMBER;
  epmdocumentid2 NUMBER;
  docclassname VARCHAR2(200);
  total NUMBER;
  myDomainId NUMBER := to_number(ilDomainId);
  hole_and_update NUMBER;
  dgid NUMBER;
	linkid NUMBER;
  linktype NUMBER;
BEGIN
  v_selPIstmt :=  'select piid, status, docmasterid, ilmaster from pitowcduplicate '||
          ' where ignore = 0 and migrationPK.checkFlag(status, '||EQUAL_FLAG||') = 1'||
          ' and migrationPK.checkFlag(status, '||MARKED_FOR_MERGE_FLAG||') = 0'||
          ' and domainid = '||myDomainId;
  v_selPIVWithNoMatchingDoc :=  'select count(*) from pivtowcduplicate where piid = :piid '||
         ' and domainid = :myDomainId and (docid is null or docid <= 0)';
  piv_insertstmt := 'insert into pivtowcstatus '||
      ' (pivid, domainid, status, epmdocumentid, documenttype, loadtime, attrstatus, filestatus) '||
      ' values (:1,:2,:3, :4, :5, :6, :7, :8)';
  pi_insertstmt := 'insert into pitowcstatus '||
      ' (piid, domainid, status, epmdocumentmasterid, documenttype, loadtime, attrstatus, partstatus) '||
      ' values (:1,:2,:3, :4, :5, :6, :7, :8)';
  v_insertDepStmt := 'insert into deptowcstatus '||
	  ' (dgid, domainid, status, epmlinkid, linktype, loadtime, attrstatus) '||
      ' values (:1,:2,:3, :4, :5, :6, :7)';
  v_updateDupDepStmt := 'update deptowcduplicate set status = MigrationPK.bitor(status, '||MARKED_FOR_MERGE_FLAG||') '||
	  ' where dgid= :dgid and domainid = :myDomainId';
  v_selDupDepStmt := 'select dgid, linkid, linktype from deptowcduplicate '||
	  ' where domainid = :myDomainId and pivid = :pivid';
  v_insertThirdPartyDataStmt := 'insert into ThirdPartyData '||
      ' (EPMDocumentMasterId, DomainId) values (:1, :2)';
  total := 0;

  -- Delete from deptowcduplicate for piv marked for union.
  v_delDupDepIfUnion := 'delete from deptowcduplicate ' ||
  						' where pivid in ( select dup_piv.pivid from pitowcduplicate dup_pi, pivtowcduplicate dup_piv '||
										 ' where  dup_pi.ignore = 0 and migrationPK.checkFlag(dup_pi.status, '||EQUAL_FLAG||') = 1'||
		                                 ' and migrationPK.checkFlag(dup_pi.status,  '||MARKED_FOR_MERGE_FLAG||') = 0'||
		                                 ' and dup_pi.domainid = '||myDomainId||
		                                 ' and dup_piv.piid = dup_pi.piid and dup_piv.domainid = '||myDomainId||
		                                 ' and dup_piv.docid is null) ' ||
		                       'and domainid = '||myDomainId;
  execute immediate v_delDupDepIfUnion;

  open pidupInfo for v_selPIstmt;
  loop
    fetch pidupInfo into piid, status, docmasterid, ilmaster;
    exit when pidupInfo%NOTFOUND;

    -- Find if there are no matches.
    noMatchCount := 0;
    allPIVMatch := 1;
    hole_and_update := 0;
    execute immediate v_selPIVWithNoMatchingDoc into noMatchCount using piid, myDomainId;

    if noMatchCount > 0 then
      begin
        allPIVMatch := 0;
      end;
    end if;

    v_selPIVstmt :=  'select pivid, docid, docclassname from pivtowcduplicate '||
          ' where piid = '||piid||' and domainid = '||myDomainId;

		--insert DocMasterId in ThirdPartyData table
		begin
				execute immediate v_insertThirdPartyDataStmt using docmasterid, myDomainId;
		end;
		if ilmaster = 1 then
				open pivdupInfo for v_selPIVstmt;
				loop
						fetch pivdupInfo into pivid, epmdocumentid, docclassname;
						pivid2 :=pivid;
						epmdocumentid2 := epmdocumentid;
						exit when pivdupInfo%NOTFOUND;
						if (pivid > 0 and epmdocumentid > 0) then
								  begin
                      							execute immediate piv_insertstmt using pivid, myDomainId, MIGRATION_UPDATING, epmdocumentid, EPMDOCTYPE, sysdate, MIGRATION_UPDATING, MIGRATION_WILL_NOT_MIGRATE; -- update
								   exception when others then
                      							update pivtowcstatus  set status=MIGRATION_UPDATING, filestatus=MIGRATION_WILL_NOT_MIGRATE, epmdocumentid=epmdocumentid2, documenttype=EPMDOCTYPE, loadtime=sysdate, attrstatus=5 where pivid=pivid2 and domainid=myDomainId ;
                                                  		  end;
						end if;
						-- update dep status
						open depDupInfo for v_selDupDepStmt using myDomainId,pivid;
						loop
								fetch depDupInfo into dgid, linkid, linktype;
								exit when depDupInfo%NOTFOUND;
								begin
								execute immediate v_insertDepStmt using dgid, myDomainid, 5, linkid, linktype, sysdate, 5;
								execute immediate v_updateDupDepStmt using dgid, myDomainid;
								end;
						end loop;
				end loop;
				if allPIVMatch = 1 then
						begin
								execute immediate pi_insertstmt using piid, myDomainId, MIGRATION_UPDATING, docmasterid, EPMDOCTYPE, sysdate, MIGRATION_UPDATING, MIG_UNDECIDED; -- update
--                putpipe('inserted pi '||piid||' and doctype 1 and status 5');
						end;
				else
						begin
						-- MIGRATION_HOLES_AND_UPDATING = 6
						execute immediate pi_insertstmt using piid, myDomainId, MIGRATION_HOLES_AND_UPDATING, docmasterid, EPMDOCTYPE, sysdate, MIGRATION_UPDATING, MIG_UNDECIDED; -- update with hole
--                putpipe('inserted pi '||piid||' and doctype 1 and status 6');
						end;
				end if;
    else --PDMLink is master
				open pivdupInfo for v_selPIVstmt;
				loop
						fetch pivdupInfo into pivid, epmdocumentid, docclassname;
						pivid2 :=pivid;
						epmdocumentid2 := epmdocumentid;
						exit when pivdupInfo%NOTFOUND;
						if (pivid > 0 and epmdocumentid > 0) then
								begin
                   							execute immediate piv_insertstmt using pivid, myDomainId, MIGRATION_SUCCESS, epmdocumentid, EPMDOCTYPE, sysdate, MIGRATION_SUCCESS, MIGRATION_WILL_NOT_MIGRATE; -- success
								exception when others then
                   							update pivtowcstatus  set status=MIGRATION_SUCCESS, filestatus=MIGRATION_WILL_NOT_MIGRATE, epmdocumentid=epmdocumentid2, documenttype=EPMDOCTYPE, loadtime=sysdate, attrstatus=1 where pivid=pivid2 and domainid=myDomainId ;
                                                  		 end;
						end if;
						-- update dep status
						open depDupInfo for v_selDupDepStmt using myDomainId,pivid;
						loop
								fetch depDupInfo into dgid, linkid, linktype;
								exit when depDupInfo%NOTFOUND;
								begin
								execute immediate v_insertDepStmt using dgid, myDomainid, 1, linkid, linktype, sysdate, 1;
								execute immediate v_updateDupDepStmt using dgid, myDomainid;
								end;
						end loop;
				end loop;
				if allPIVMatch = 1 then
						begin
								execute immediate pi_insertstmt using piid, myDomainId, MIGRATION_SUCCESS, docmasterid, EPMDOCTYPE, sysdate, MIGRATION_SUCCESS, MIG_UNDECIDED; -- success
						end;
				else
						begin
						-- MIGRATION_HOLES = 7
						execute immediate pi_insertstmt using piid, myDomainId, MIGRATION_HOLES, docmasterid, EPMDOCTYPE, sysdate, MIGRATION_SUCCESS, MIG_UNDECIDED; -- hole
						end;
				end if;
  end if;

    -- Finally update PIV Duplicate status to MARKED_FOR_MERGE.
    pivdupUpdate_stmt := 'update pivtowcduplicate set status = MigrationPK.bitor(status, '||MARKED_FOR_MERGE_FLAG||') '||
                        ' where piid = :piid and domainid = :myDomainId';

    execute immediate pivdupUpdate_stmt using piid, myDomainId;

    -- Finally update PI Duplicate status to MARKED_FOR_MERGE.
    pidupUpdate_stmt := 'update pitowcduplicate set status = MigrationPK.bitor(status, '||MARKED_FOR_MERGE_FLAG||') '||
                        ' where piid = :piid and domainid = :myDomainId';

    execute immediate pidupUpdate_stmt using piid, myDomainId;

    total := total + 1;

  end loop;
  close pidupInfo;
  -- Finally update fileStatus for secondaryPIVs whose primary's fileStatus is DOM_SUCCESS
  pivSecFileStatusUpdate_stmt := 'update pivtowcstatus secSt set secSt.filestatus='||MIGRATION_WILL_NOT_MIGRATE||
        ' where secSt.domainid =:myDomainId'||
        ' and secSt.documenttype=2'||
        ' and exists (select 1 from pivtowcstatus primSt, secondarypivs sp'||
        '             where sp.secondarypivid=secSt.pivid and sp.primarypivid=primSt.pivid'||
        '             and primSt.filestatus='||MIGRATION_WILL_NOT_MIGRATE||' and primSt.hasSecondary=1'||
        '             and primSt.domainid = sp.domainid and sp.domainid = secSt.domainid)';
  execute immediate pivSecFileStatusUpdate_stmt using myDomainId;

  return total;


END markForMerge;

function setEqual (status in number) return number is

  tstatus number := 0;
  t2status number := 0;
  fstatus number := 0;

begin
  -- first turn on equality bit
  tstatus := status + EQUAL_FLAG - bitand(status, EQUAL_FLAG);

  -- now turn off inequality bit
  t2status :=  bitand(tstatus, NOT_UNEQUAL_FLAG);

  -- now turn off the bit check_equality_needed
  fstatus :=  bitand(t2status, NOT_CHECK_FOR_EQUALITY_FLAG);

--  putpipe('EQUAL status: ' ||status||', tstatus: '||tstatus||', t2status: '||t2status||', fstatus: '||fstatus);
  return fstatus;
end setEqual;

function setUnEqual (status in number) return number is

  tstatus number := 0;
  t2status number := 0;
  fstatus number := 0;

begin
  -- first turn off the equality bit

  tstatus := bitand(status, NOT_EQUAL_FLAG);

  -- now turn off the bit check_equality_needed
  t2status :=  bitand(tstatus, NOT_CHECK_FOR_EQUALITY_FLAG);

  -- now turn on the inequality bit
  fstatus := t2status + UNEQUAL_FLAG - bitand(t2status, UNEQUAL_FLAG);

--  putpipe('UNEQUAL status: ' ||status||', tstatus: '||tstatus||', t2status: '||t2status||', fstatus: '||fstatus);

  return fstatus;
end setUnEqual;

function setCheckForEquality (status in number) return number is

  fstatus number := 0;

begin

  -- turn on the bit check_equality_needed
  fstatus :=  status + CHECK_FOR_EQUALITY_FLAG - bitand(status, CHECK_FOR_EQUALITY_FLAG);

  return fstatus;
end setCheckForEquality;

function checkFlag (status in number, flag in number) return number is

begin

  if bitand(status, flag) = 0 then
    return 0;
  else
    return 1;
  end if;

end checkFlag;

Procedure cwpRegisverPIPIV (WCDBLinkName VARCHAR2, ildomainid varchar2) is
    v_insertsql varchar2(4000);
    begin
          ---   create table cwp_registerPIPIV
             execute immediate 'truncate table cwp_registerpipiv';
             /*v_insertsql:=' insert into cwp_registerpipiv  '||
                              ' select pi.ownership,
                               decode( instr(pi.globalid, ''|''), 0,  substr(pi.globalid, 1, instr(pi.globalid,''@'')-1),
                               substr(pi.globalid, 1, instr(pi.globalid,''|'')-1)) remoteobjectid,  pi.localpiid pipivid, rp.ida2a2 birthid, rp.guid, '||
                              ' rp.lastknowndomain, st.epmdocumentmasterid mdid , ''wt.epm.EPMDocumentMaster'' classname, null REVISION, null VERSION, '||
                              ' null RELSCHEME, null RELLEVEL, null LOCATION, pi.createdon importedtime '||
                              ' from  cwp_registerPI@'||WCDBLinkName||' pi, pitowcstatus st, repository rp '||
                              ' where pi.localpiid = st.piid  and st.domainid= '||ildomainid||' and st.status !='||MIGRATION_CANNOTDO||' and st.status !='||MIGRATION_REPLICA_SUCCESS||
                              ' and decode (instr(pi.ownership, ''@''), 0 ,pi.ownership||''@UNKNOWN'', pi.ownership)=rp.guid||''@''||rp.lastknowndomain '||
                              ' and instr(pi.globalid,''@'')>1 '||
                              '  UNION ALL'||
                              ' select pi.ownership,
                               decode( instr(piv.globalid, ''|''), 0,  substr(piv.globalid, 1, instr(piv.globalid,''@'')-1),
                               substr(piv.globalid, 1, instr(piv.globalid,''|'')-1)) remoteobjectid,  piv.localpivid, rp.ida2a2 birthid, rp.guid,'||
                              ' rp.lastknowndomain, st.epmdocumentid mdid, ''wt.epm.EPMDocument'', REVISION,VERSION,RELSCHEME,RELLEVEL,LOCATION , piv.createdon importedtime '||
                              ' from  cwp_registerPI@'||WCDBLinkName||' pi,cwp_registerPIV@'||WCDBLinkName||' piv, pivtowcstatus st, repository rp '||
                              ' where pi.globalid=piv.pi_globalid and piv.localpivid = st.pivid  and st.domainid= '||ildomainid||' and st.status !='||MIGRATION_CANNOTDO ||' and st.status !='||MIGRATION_REPLICA_SUCCESS ||
                              ' and decode (instr(pi.ownership, ''@''), 0 ,pi.ownership||''@UNKNOWN'', pi.ownership)=rp.guid||''@''||rp.lastknowndomain '||
                              ' and instr(pi.globalid,''@'')>1 ';*/

             v_insertsql:=' insert into cwp_registerpipiv '||
                              ' select pi.ownership,
                               decode( instr(pi.globalid, ''|''), 0,  substr(pi.globalid, 1, instr(pi.globalid,''@'')-1),
                               substr(pi.globalid, 1, instr(pi.globalid,''|'')-1)) remoteobjectid,  pi.localpiid pipivid, rp.ida2a2 birthid, rp.guid, '||
                              ' rp.lastknowndomain, st.epmdocumentmasterid mdid , ''wt.epm.EPMDocumentMaster'' classname, null REVISION, null VERSION, '||
                              ' null RELSCHEME, null RELLEVEL, null LOCATION, pi.createdon importedtime,''OWNING_REPOSITORY'' repotype,docmas.branchida2typedefinitionrefe branchida2,docmas.ida2typedefinitionreference ida2type '||
                              ' from  cwp_registerPI@'||WCDBLinkName||' pi, epmdocumentmaster docmas,pitowcstatus st, repository rp '||
                              ' where pi.localpiid = st.piid  and st.epmdocumentmasterid = docmas.ida2a2 and st.domainid= '||ildomainid||' and st.status !='||MIGRATION_CANNOTDO||' and st.status !='||MIGRATION_REPLICA_SUCCESS||
                              ' and decode (instr(pi.ownership, ''@''), 0 ,pi.ownership||''@UNKNOWN'', pi.ownership)=rp.guid||''@''||rp.lastknowndomain '||
                              ' and instr(pi.globalid,''@'')>1 '||
                              '  UNION ALL'||
                              ' select pi.ownership,
                               decode( instr(piv.globalid, ''|''), 0,  substr(piv.globalid, 1, instr(piv.globalid,''@'')-1),
                               substr(piv.globalid, 1, instr(piv.globalid,''|'')-1)) remoteobjectid,  piv.localpivid, rp.ida2a2 birthid, rp.guid,'||
                              ' rp.lastknowndomain, st.epmdocumentid mdid, ''wt.epm.EPMDocument'', REVISION,VERSION,RELSCHEME,RELLEVEL,LOCATION , piv.createdon importedtime,''OWNING_REPOSITORY'' repotype,doc.branchida2typedefinitionrefe branchida2,doc.ida2typedefinitionreference ida2type '||
                              ' from  cwp_registerPI@'||WCDBLinkName||' pi,cwp_registerPIV@'||WCDBLinkName||' piv, epmdocument doc,pivtowcstatus st, repository rp '||
                              ' where pi.globalid=piv.pi_globalid and piv.localpivid = st.pivid  and st.epmdocumentid = doc.ida2a2 and st.domainid= '||ildomainid||' and st.status !='||MIGRATION_CANNOTDO ||' and st.status !='||MIGRATION_REPLICA_SUCCESS ||
                              ' and decode (instr(pi.ownership, ''@''), 0 ,pi.ownership||''@UNKNOWN'', pi.ownership)=rp.guid||''@''||rp.lastknowndomain '||
                              ' and instr(pi.globalid,''@'')>1 ';

             execute immediate v_insertsql;

            begin
              execute immediate 'CREATE INDEX IDX1_cwp_registerpipiv ON cwp_registerpipiv (remoteobjectid) tablespace indx ';
              execute immediate 'CREATE INDEX IDX2_cwp_registerpipiv ON cwp_registerpipiv (birthid)   tablespace indx';
              execute immediate 'CREATE INDEX IDX3_cwp_registerpipiv ON cwp_registerpipiv (pipivid)   tablespace indx';
              execute immediate 'CREATE INDEX IDX4_cwp_registerpipiv ON cwp_registerpipiv (classname) tablespace indx ';
             exception when others then
               null;
            end;

           commit;
end cwpRegisverPIPIV;

PROCEDURE cwpRemoteInfo (ilDomainId VARCHAR2, WCDBLinkName  VARCHAR2)
        is
        MIGRATION_CWP_UFID_CREATE number :=14;
        MAX_PIVID_FOR_CWP number :=16;
        MAX_DOCID_FOR_CWP_RECIPE_FILE number := 17;
        v_maxdocid number;
        v_maxdocid2 number;
        v_maxpivid number;
        v_maxpivid2 number;
        v_insertsql varchar2(2000);
        v_updatesql varchar2(2000);
        v_deletesql varchar2(2000);
        v_cwpbirthupdatesql varchar2(2000);
        begin

       --create repositories
       v_insertsql:=
       'INSERT INTO Repository(idA2A2,classnameA2A2,updateCountA2,local,markForDeleteA2,
                            updateStampA2,createStampA2,modifyStampA2,guid,lastKnownDomain)
        select MigrationPK.GetNewWCID, ''wt.ufid.Repository'' , 1,0,0, sysdate, sysdate, sysdate, guid, domain
        from
        (
          select distinct decode(instr(ownership, ''@''), 0, ownership, substr(ownership, 1,instr(ownership, ''@'')-1)) guid,
                          decode(instr(ownership, ''@''), 0, ''UNKNOWN'', substr(ownership, instr(ownership, ''@'')+1)) domain
          from cwp_registerpi@'||WCDBLinkName||' rp
          where exists  (select 1 from pitowcstatus st where st.piid = localpiid and
                           st.domainid ='''||ilDomainid||'''  and st.status!='||MIGRATION_CANNOTDO||
                        ' ) and
                not exists ( select 1 from Repository
                            where guid=decode(instr(rp.ownership, ''@''), 0, rp.ownership, substr(rp.ownership, 1,instr(rp.ownership, ''@'')-1))

                )
          )';
        execute immediate v_insertsql;

        --create temp table
        cwpRegisverPIPIV(WCDBLinkName, ilDomainid);
             /*
        -- case 1: the exported objects  has not been imported to target system
                      --that means the objects don't exist in the remoteobjectinfo table in the target system
                      --but they exist at cwp_registerpi, cwp_registerpiv in the source system
             --to do:
               --1) check if repository exists? (done by java) , if not need created it  (need put the infor to onceprocess
               --2) Migrate GlobalId -> create entries in remoteobjectinfo and owningrepositoryLocalObject


          --case 3: the imported objects exported by cwp not from target system
                --to do:
                 --need to migrate birthinfo  from Pro/I to PDMLink
                   --use CWP_RegisterPIV and map it to CWPBirthInfo
                   --In X20 cwpbirthinfo changed to collaborationinfo

                  Create new Java Class: CWPMigrator.java
                  (case1 and case3 difference are case1 ownership=ildomainid but case3  ownership!=ildomainid)
                  (case1 and cas3 both objects not exists in target system)
                  1. for case 1
                  need do:

                   --1) check if repository exists? (done by java) , if not need created it  (need put the infor to onceprocess
                   --2) Migrate GlobalId -> create entries in remoteobjectinfo and owningrepositoryLocalObject  need maxid for max pivid

                   select
                   from pitowcstaus, pivtowcstatus
                   where status=1 and the pi in the exported pi or pivs
                   and pivid>maxid
                   insert into  remoteobjectinfo

                 2. for case 3 is similar to case1
                          --1) check if repository exists? (done by java) , if not need created it  (need put the infor to onceprocess
                           --2) Migrate GlobalId -> create entries in remoteobjectinfo and owningrepositoryLocalObject  need maxid for max pivid
                           3) migrate birthinfo

    /*
           From Harish
           LABELB3       ---   Revision
           POSITIONB3  ---   Revision
           LABELC3         ---  Version
           POSITIONC3    ---  Version           In Windchill version is refered  to as iteration
           RELSCHEME NAMED3
           RELLEVEL STATED3
           LOCATION  LOCATION
       */

     --globalid must have format 1:piid@ildmoainid or 2:pivid@ildomainid or 'wt.epm.EPMDocument:docid@domain' or  'wt.epm.EPMDocumentMaster:masterid@domain'
     --ownership must have format ildomainid for objects exported/imported from/to  intralink or rp.guid@rp.lastknowndoamin for objects imported from PDMlink
     -- need run as dynamic sql since variable like WCDBLinkName and MIGRATION_CANNOTDO etc.

     --insert pi export/import info into owningrepositorylocalobject if they do not exist
         INSERT INTO owningrepositorylocalobject(ida2a2, ida3a5, CLASSNAMEKEYROLEBOBJECTREF, ida3b5, MARKFORDELETEA2)
             select GetNewWCID, m.*
             from
             (
             select  pipiv.birthid,  pipiv.classname classnamekeya3, pipiv.mdid,  -1 MARKFORDELETEA2
             from cwp_registerpipiv pipiv
             minus
             select rp.ida2a2 birthid, rm.CLASSNAMEKEYROLEBOBJECTREF, rm.ida3b5 ,  -1 MARKFORDELETEA2
             from owningrepositorylocalobject rm, repository rp
             where rp.ida2a2=rm.ida3a5
             ) m;
          update owningrepositorylocalobject
             set CLASSNAMEKEYROLEAOBJECTREF='wt.ufid.Repository',
             CREATESTAMPA2=sysdate, MARKFORDELETEA2=0,
             MODIFYSTAMPA2=sysdate, UPDATECOUNTA2= 1,
             UPDATESTAMPA2=sysdate
             where MARKFORDELETEA2 =-1;
      --insert pi export/import info into remoteobjectinfo if they do not exist

        INSERT INTO remoteobjectid(ida2a2,remoteobjectid,MARKFORDELETEA2,classnamea2a2 )
             select GetNewWCID, m.*
             from
             (
             select n.* from
             (
             select
             pipiv.remoteobjectid, -1 MARKFORDELETEA2, 'wt.ufid.RemoteObjectId'  classnamea2a2
             from cwp_registerpipiv pipiv
             minus --could replace here with not exists clause
             select remoteobjectid, -1 MARKFORDELETEA2, 'wt.ufid.RemoteObjectId'  classnamea2a2
             from remoteobjectid
             )n
             where not exists (select 1 from remoteobjectid where n.remoteobjectid = remoteobjectid)
             )m;


         INSERT INTO remoteobjectinfo(ida2a2,birthid,lastknownid,classnamekeya3, ida3a3,remoteid,classnamea2a2, MARKFORDELETEA2 )
             select GetNewWCID, m.*
             from
             (
             select n.* from
             (
             select  pipiv.birthid,pipiv.birthid lastknownid, pipiv.classname classnamekeya3,pipiv.mdid,
             r.ida2a2 remoteid, 'wt.ufid.RemoteObjectInfo'  classnamea2a2 , -1 MARKFORDELETEA2
             from cwp_registerpipiv pipiv, remoteobjectid r
             where pipiv.remoteobjectid=r.remoteobjectid
             minus  --could replace here with not exists clause
             select rm.birthid, rm.birthid  lastknownid, rm.classnamekeya3, rm.ida3a3,r.ida2a2 remoteid, rm.classnamea2a2 ,
             -1 MARKFORDELETEA2
             from remoteobjectinfo rm,  remoteobjectid r
             where rm.remoteid=r.ida2a2
             )n
             where not exists (select 1 from  remoteobjectinfo where remoteid = n.remoteid)
             ) m;

       update pivtowcstatus
             set cwpufidstatus=MIGRATION_CWP_UFID_CREATE --defined in migobject.java MIGRATION_CWP_UFID_CREATE=14
             where exists
             (select 1 from cwp_registerpipiv pipiv,  remoteobjectid r
              where pipivid =pivid and  pipiv.classname ='wt.epm.EPMDocument' and pipiv.remoteobjectid=r.remoteobjectid and  r.MARKFORDELETEA2=-1)
              and domainid =ilDomainId;

-- Update pivtowcstatus for objects which are exported from migrating ProI to target Windchill
-- Check ownership info in cwpbirthinfo = ilDomainId
-- In X20 cwpbirthinfo changed to collaborationinfo

	/*v_cwpbirthupdatesql := 'update  pivtowcstatus piv
              set cwpufidstatus='|| MIGRATION_CWP_UFID_CREATE || ' --defined in migobject.java MIGRATION_CWP_UFID_CREATE=14
              where exists
              (select 1 from cwpbirthinfo cb, remoteobjectinfo r, cwp_registerpipiv pipiv, remoteobjectid rid
              where pipivid = piv.pivid
               and  r.classnamekeya3 =''wt.epm.EPMDocument''
               and rid.ida2a2 = r.remoteid
               and pipiv.remoteobjectid=rid.remoteobjectid
               and r.MARKFORDELETEA2!=-1
               and cb.ida3a3 = r.ida3a3
               and cb.ownersystemid = '''||ilDomainId||''')';*/

	v_cwpbirthupdatesql := 'update  pivtowcstatus piv
              set cwpufidstatus='|| MIGRATION_CWP_UFID_CREATE || ' --defined in migobject.java MIGRATION_CWP_UFID_CREATE=14
              where exists
              (select 1 from collaborationinfo ci, remoteobjectinfo r, cwp_registerpipiv pipiv, remoteobjectid rid
              where pipivid = piv.pivid
               and  r.classnamekeya3 =''wt.epm.EPMDocument''
               and rid.ida2a2 = r.remoteid
               and pipiv.remoteobjectid=rid.remoteobjectid
               and r.MARKFORDELETEA2!=-1
               and ci.ida3a4 = r.ida3a3
               and ci.repositoryid = '''||ilDomainId||''')';

        execute immediate v_cwpbirthupdatesql;

         update remoteobjectinfo
             set CREATESTAMPA2=sysdate, MARKFORDELETEA2=0,
             MODIFYSTAMPA2=sysdate, UPDATECOUNTA2= 1,
             UPDATESTAMPA2=sysdate
             where MARKFORDELETEA2 =-1;

	 update remoteobjectid
	     set CREATESTAMPA2=sysdate, MARKFORDELETEA2=0,
	     MODIFYSTAMPA2=sysdate, UPDATECOUNTA2= 1,
	     UPDATESTAMPA2=sysdate
	 where MARKFORDELETEA2 =-1;

--first delete birthinfo for case 2: which is the doc has been imported to PDMlink from the same intralink)
--In X20 cwpbirthinfo changed to collaborationinfo
       /*v_deletesql:=' delete from cwpbirthinfo  bi where ownersystemid = '''|| ilDomainId ||
       ''' and exists (  select 1  from pivtowcstatus where epmdocumentid = bi.ida3a3  and domainid ='''|| ilDomainId ||''' and status=1
        )';*/

       v_deletesql:=' delete from collaborationinfo ci where repositoryid = '''|| ilDomainId ||
       ''' and exists (  select 1  from pivtowcstatus where epmdocumentid = ci.ida3a4  and domainid ='''|| ilDomainId ||''' and status=1
        )';

       execute immediate v_deletesql;

    --insert pi export/import info into cwpbirthinfo if they do not exist for imported objects only
    --In X20 cwpbirthinfo changed to collaborationinfo
             /*v_insertsql:= 'INSERT INTO cwpbirthinfo(ida2a2,MARKFORDELETEA2, CLASSNAMEKEYA3, ida3a3, ownersystemid, LOCATION,
             LABELB3,POSITIONB3, LABELC3, POSITIONC3, NAMED3,STATED3 ,exportedtime )
             select  MigrationPK.GetNewWCID, -1 MARKFORDELETEA2, m.*
             from
             (
               select pipiv.classname classnamekeya3, pipiv.mdid,pipiv.ownership, pipiv.location,
                                     substr(revision,  instr(revision, '':'')+1) revlabel,
                                     substr(revision, 1, instr(revision, '':'')-1) revposi,
                                     substr(version,  instr(version, '':'')+1) verlabel,
                                     substr(version, 1, instr(version, '':'')-1) verposi,
                                     RELSCHEME, RELLEVEL,
                                     pipiv.importedtime
               from cwp_registerpipiv pipiv
               where classname=''wt.epm.EPMDocument''
               and pipiv.ownership!='''||ilDomainid||''' and revision is not null and instr(revision, '':'')>0'||
              ' and not exists (
               select 1 from cwpbirthinfo b where b.ida3a3=pipiv.mdid and b.ownersystemid=pipiv.ownership
               ) ) m';*/

             v_insertsql:= 'INSERT INTO COLLABORATIONINFO(IDA2A2,MARKFORDELETEA2, CLASSNAMEKEYA4, IDA3A4, REPOSITORYID,REMOTEID, LOCATION,
             REVISIONLABEL,REVISIONPOSITION, ITERATIONLABEL, ITERATIONPOSITION, LCNAME,LCSTATE ,EXPORTEDTIME,REPOSITORYTYPE,BRANCHIDA2TYPEDEFINITIONREFE,IDA2TYPEDEFINITIONREFERENCE )
             select  MigrationPK.GetNewWCID, -1 MARKFORDELETEA2, m.*
             from
             (
               select pipiv.classname classnamekeya3, pipiv.mdid,pipiv.ownership,pipiv.remoteobjectid, pipiv.location,
                                     substr(revision,  instr(revision, '':'')+1) revlabel,
                                     substr(revision, 1, instr(revision, '':'')-1) revposi,
                                     substr(version,  instr(version, '':'')+1) verlabel,
                                     substr(version, 1, instr(version, '':'')-1) verposi,
                                     RELSCHEME, RELLEVEL,
                                     pipiv.importedtime,pipiv.repotype,pipiv.branchida2,pipiv.ida2type
               from cwp_registerpipiv pipiv
               where classname=''wt.epm.EPMDocument''
               and pipiv.ownership!='''||ilDomainid||''' and revision is not null and instr(revision, '':'')>0'||
              ' and not exists (
               select 1 from collaborationinfo ci where ci.ida3a4=pipiv.mdid and ci.repositoryid=pipiv.ownership
               ) ) m';

                 execute immediate v_insertsql;

                 /*v_updatesql:= 'update cwpbirthinfo
                                set CLASSNAMEA2A2=''com.ptc.cwp.wncadapter.server.CWPBirthInfo'',
                            	CREATESTAMPA2=sysdate, MARKFORDELETEA2=0,
                                MODIFYSTAMPA2=sysdate, UPDATECOUNTA2= 1,
                                UPDATESTAMPA2=sysdate
                                where MARKFORDELETEA2 =-1';*/

                 v_updatesql:= 'update collaborationinfo
                                set CLASSNAMEA2A2=''wt.fedInfra.collaboration.CollaborationInfo'',
                                CREATESTAMPA2=sysdate, MARKFORDELETEA2=0,
                                MODIFYSTAMPA2=sysdate, UPDATECOUNTA2= 1,
                                UPDATESTAMPA2=sysdate
                                where MARKFORDELETEA2 =-1';

                execute immediate v_updatesql;

               --create a changeownership docid list into a temp table  for cwp_changownerdocids
                begin
                 select maxdbid into v_maxdocid from  RESUMEPROCESSSTATUS where PURPOSE=MAX_DOCID_FOR_CWP_RECIPE_FILE;
                exception when others then
                 v_maxdocid :=-1;
                end;
                v_insertsql :=
                ' insert into cwp_changownerdocids
                 select distinct epmdocumentid from pivtowcstatus st
                 where
                 cwpufidstatus='||MIGRATION_CWP_UFID_CREATE||' and
                 status='||MIGRATION_SUCCESS||' and
                 exists ( select 1 from owningrepositoryLocalObject  ow, repository  rp where to_char(rp.guid) = to_char(st.domainid) and
                    rp.LASTKNOWNDOMAIN =''UNKNOWN'' and ow.ida3a5= rp.ida2a2 and  st.epmdocumentid= ow.ida3b5) and
                    epmdocumentid > '||v_maxdocid;

                 execute immediate v_insertsql;

                 select max(epmdocmentid) into v_maxdocid2 from  cwp_changownerdocids;
                 if v_maxdocid=-1 and v_maxdocid2>0 then
                    insert into RESUMEPROCESSSTATUS (DOMAINID,PURPOSE,MAXDBID) values (-1, MAX_DOCID_FOR_CWP_RECIPE_FILE, v_maxdocid2);
                 elsif v_maxdocid2>0 and v_maxdocid2>v_maxdocid then
                    update RESUMEPROCESSSTATUS set MAXDBID = v_maxdocid2 where purpose = MAX_DOCID_FOR_CWP_RECIPE_FILE;
                 end if;

                begin
                  select maxdbid into v_maxpivid from  RESUMEPROCESSSTATUS where domainid=ilDomainId and PURPOSE=MAX_PIVID_FOR_CWP;
                exception when others then
                  v_maxpivid :=-1;
                end;
                  execute immediate 'select max(pivid)  from   pdm_productitemversion@'||WCDBLinkName into v_maxpivid2;
                if v_maxpivid=-1 and v_maxpivid2>0 then
                    insert into RESUMEPROCESSSTATUS (DOMAINID,PURPOSE,MAXDBID) values (ilDomainId, MAX_PIVID_FOR_CWP, v_maxpivid2);
                 elsif v_maxpivid2>0 and v_maxpivid2>v_maxpivid then
                    update RESUMEPROCESSSTATUS set MAXDBID = v_maxpivid2 where domainid=ilDomainId and  purpose = MAX_PIVID_FOR_CWP;
                 end if;

                 execute immediate 'truncate table cwp_registerpipiv';
               --  commit;
 --exception when others then
 --  dbms_output.put_line(sqlerrm(sqlcode));
 -- raise;
  end cwpRemoteInfo;

FUNCTION deleteForRecalculate( cur IN SYS_REFCURSOR, pdomainid IN VARCHAR2, pchunkSize IN NUMBER, delete_pi IN number ) return number
IS
	piCount number;
	id_array TABLE_OF_NUMBER;
BEGIN
	piCount := 0;
	LOOP
		FETCH cur BULK COLLECT INTO id_array LIMIT pchunkSize;
			piCount := piCount + id_array.COUNT;
			FORALL i IN 1..id_array.COUNT
				DELETE FROM pivtowcduplicate pivdup
				WHERE domainid = pdomainId
					AND piid = id_array(i);
			if delete_pi = 1 then
				FORALL i IN 1..id_array.COUNT
					DELETE FROM pitowcduplicate
					WHERE domainid = pdomainId
						AND piid = id_array(i);
			end if;
		EXIT WHEN cur%NOTFOUND;
	END LOOP;
	return piCount;
end;

FUNCTION deleteForRecalculate( pdomainid IN VARCHAR2, pchunkSize IN NUMBER ) return number
IS
	cur RefCur;
	stmt varchar2(200);
	piCount number;
BEGIN
	stmt := 'select piid from pitowcduplicate where domainid = :domain_id and ( status is null or bitand( status, :flag ) = 0  )';
	open cur for stmt using pdomainid, MARKED_FOR_MERGE_FLAG;
	piCount := deleteForRecalculate( cur, pdomainid, pchunkSize, 1);
	close cur;
	return piCount;
end;

FUNCTION deleteForRecalculate( pdomainid IN VARCHAR2, pchunkSize IN NUMBER, piids IN TABLE_OF_NUMBER) return number
IS
	cur RefCur;
	stmt varchar2(200);
	piCount number;
BEGIN
	stmt := 'SELECT column_value piid FROM TABLE(:piids) pids';
	open cur for stmt using piids;
	piCount := deleteForRecalculate( cur, pdomainid, pchunkSize, 1);
	close cur;
	return piCount;
end;

FUNCTION deleteForRecalculate( pdomainid IN VARCHAR2, pchunkSize IN NUMBER, pstatus IN NUMBER) return number
IS
	cur RefCur;
	stmt varchar2(200);
	piCount number;
BEGIN
	stmt := 'select piid from pitowcduplicate where domainid = :domain_id and bitand( status, :flag ) = :flag ';
	open cur for stmt using pdomainid, pstatus, pstatus;
	piCount := 0;
	if pstatus = MARKED_FOR_DELETE_FLAG then
		piCount := deleteForRecalculate( cur, pdomainid, pchunkSize, 1);
	else
		piCount := deleteForRecalculate( cur, pdomainid, pchunkSize, 0);
	end if;
	close cur;
	return piCount;
end;

END MigrationPK;
/

