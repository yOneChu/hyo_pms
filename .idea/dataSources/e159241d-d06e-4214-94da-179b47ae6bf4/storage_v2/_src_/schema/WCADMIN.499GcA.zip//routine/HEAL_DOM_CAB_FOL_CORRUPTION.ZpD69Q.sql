create procedure heal_dom_cab_fol_corruption (v_lasthealedtimestamp IN date, v_error OUT varchar2) is

   v_healable varchar2(100);
   v_max_run_cnt number;
   v_rows_updated number;
   v_sqlstmt varchar2(8000);
   type refcur is ref cursor;
   c_ALIGNMENT_EPMDOCUMENT refcur;


 TYPE fetch_array_document IS TABLE OF MIG$CABINETFOLDER%ROWTYPE;
 s_array_document fetch_array_document;

begin
  dbms_output.put_line('============================================================');
  dbms_output.put_line('Heal Alignment corruption....heal_domain_cabinet_folder_corruption_6.sql');
  dbms_output.put_line(to_char(sysdate,'MM/DD/YYYY HH24:MI:SS'));
  dbms_output.put_line('============================================================');

  dbms_output.put_line('Historical Iteration Cleanser will align all iterations of each version to be the same as latest for each version. (cabinet, parentfolder, domain and container)');

  dbms_output.put_line(to_char(sysdate,'MM/DD/YYYY HH24:MI:SS'));

  v_sqlstmt := 'select distinct non_latest.idA2A2, latest.idA3domainRef DREF, latest.idA3A2folderinginfo LCAB, latest.idA3B2folderinginfo LFOL, latest.classnamekeyb2folderinginfo LCLASSCAB
    		, non_latest.idA3domainRef NL_DREF, non_latest.idA3A2folderinginfo NONLCAB, non_latest.idA3B2folderinginfo NONLFOL, non_latest.classnamekeyb2folderinginfo NONLCLASSCAB, sysdate
  		, decode(pivst.status,null,''Object not Migrated'',decode(pivst.status,1,decode(non_latest.STATECHECKOUTINFO,''c/i'',''Healable'',''Object not checked in''),''Object was not migrated successfully'')) isHealable
  		, :max_run_cnt  runcount
  		from EPMDocument non_latest, EPMDocument latest, pivtowcstatus pivst
  		where
		    non_latest.branchIditerationInfo = latest.branchIditerationInfo
		    and non_latest.latestiterationInfo = 0
		    and latest.latestiterationInfo = 1
		    and (non_latest.idA3domainRef <> latest.idA3domainRef
			or non_latest.idA3A2folderingInfo <> latest.idA3A2folderingInfo
			or non_latest.classnamekeyB2folderingInfo <> latest.classnamekeyB2folderingInfo
			or non_latest.idA3B2folderingInfo <> latest.idA3B2folderingInfo)
		    and pivst.epmdocumentid(+) = non_latest.idA2A2
		    and pivst.documenttype = 0
		    and latest.classnamekeycontainerreferen in (''wt.inf.library.WTLibrary'',''wt.pdmlink.PDMLinkProduct'')
		    and non_latest.classnamekeycontainerreferen in (''wt.inf.library.WTLibrary'',''wt.pdmlink.PDMLinkProduct'')';

  select nvl(max(runcount),0) into  v_max_run_cnt from MIG$CABINETFOLDER where MIG$CABINETFOLDER.IDA3DOMAINREF is not null;
  v_max_run_cnt := v_max_run_cnt+1;
  v_error :='No Errors';

  if (v_lasthealedtimestamp is not null) then
     v_sqlstmt := v_sqlstmt||' and loadtime>'''||v_lasthealedtimestamp||'''';
  end if;

  dbms_output.put_line(to_char(sysdate,'MM/DD/YYYY HH24:MI:SS'));

  OPEN c_ALIGNMENT_EPMDOCUMENT for v_sqlstmt using v_max_run_cnt;
    LOOP
      FETCH c_ALIGNMENT_EPMDOCUMENT BULK COLLECT INTO s_array_document LIMIT 10000;
      FORALL i IN 1..s_array_document.COUNT
       insert into MIG$CABINETFOLDER values s_array_document(i);
      EXIT WHEN c_ALIGNMENT_EPMDOCUMENT%NOTFOUND;
    END LOOP;
  CLOSE c_ALIGNMENT_EPMDOCUMENT;

  dbms_output.put_line(to_char(sysdate,'MM/DD/YYYY HH24:MI:SS'));

  update EPMDocument
  set (idA3domainRef, ida3a2folderinginfo, ida3b2folderinginfo, classnamekeyb2folderinginfo) = (
    select idA3domainRef, ida3a2folderinginfo, ida3b2folderinginfo, classnamekeyb2folderinginfo from MIG$CABINETFOLDER
    where EPMDocument.idA2A2 = MIG$CABINETFOLDER.idA2A2 and runcount=v_max_run_cnt and healable = 'Healable' and MIG$CABINETFOLDER.IDA3DOMAINREF is not null)
  where EPMDocument.ida2a2 in ( select ida2a2 from MIG$CABINETFOLDER where runcount=v_max_run_cnt and healable = 'Healable'  and MIG$CABINETFOLDER.IDA3DOMAINREF is not null );

  v_rows_updated:=sql%rowcount;
  dbms_output.put_line('EPMDocument Rows Updated='||v_rows_updated);
  dbms_output.put_line(to_char(sysdate,'MM/DD/YYYY HH24:MI:SS'));

  commit;

  dbms_output.put_line(to_char(sysdate,'MM/DD/YYYY HH24:MI:SS'));

  exception when others then
     	Rollback;
     	v_error := DBMS_UTILITY.format_error_stack;
	dbms_output.put_line('FILENAME$NonHealable_domain_cabinet_folder_corruption_6.html$');

end;
/

