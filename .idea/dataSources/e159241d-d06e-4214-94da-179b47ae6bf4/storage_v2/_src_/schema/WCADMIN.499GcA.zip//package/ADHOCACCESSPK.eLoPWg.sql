create PACKAGE AdHocAccessPK IS
PROCEDURE CopyPermissions(p_source_AdHocControlled IN NUMBER, p_target_AdHocControlled IN NUMBER, p_target_className IN VARCHAR2, p_owner IN VARCHAR2, p_starts_with IN NUMBER);
PROCEDURE MCopyPermissions(p_source_AdHocControlled IN NUMBER, p_target_AdHocControlled_List IN OID_OBJECT_LIST, p_owner IN VARCHAR2, p_starts_with IN NUMBER);
PROCEDURE MCopyAllPermissions(p_source_AdHocControlled_List IN OID_OBJECT_LIST, p_target_AdHocControlled_List IN OID_OBJECT_LIST);
PROCEDURE ReassignPermissions(p_AdHocControlled IN NUMBER,p_old_principal_ref IN NUMBER, p_new_principal_ref IN NUMBER, p_owner IN VARCHAR2, p_starts_with IN NUMBER);
PROCEDURE RemovePermissions(p_AdHocControlled IN NUMBER, p_owner IN VARCHAR2, p_starts_with IN NUMBER);
PROCEDURE MRemovePermissions(p_AdHocControlled_List IN OID_OBJECT_LIST, p_owner IN VARCHAR2, p_starts_with IN NUMBER);
END AdHocAccessPK;
/

