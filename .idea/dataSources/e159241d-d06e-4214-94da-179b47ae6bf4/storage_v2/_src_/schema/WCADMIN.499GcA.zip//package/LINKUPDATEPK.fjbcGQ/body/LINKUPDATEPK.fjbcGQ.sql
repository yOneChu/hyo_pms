create PACKAGE BODY LinkUpdatePK IS
PROCEDURE UPDATE_CMCL IS
insert_ddl1 VARCHAR2(1000);
insert_ddl2 VARCHAR2(1000);
begin
insert_ddl1 :=
'insert into CMCLink(exclude, instanceValue, classnamekeyroleAObjectRef, idA3A5, classnamekeyroleBObjectRef, idA3B5, branchIdA3B5, ' ||
'createStampA2, markForDeleteA2, modifyStampA2, classnameA2A2, idA2A2, updateCountA2, updateStampA2) ' ||
'select A.exclude, A.instanceValue, A.classnamekeyroleAObjectRef, A.idA3A5, ''com.ptc.windchill.option.model.ChoiceMaster'', B.idA3B5, A.branchIdA3B5, ' ||
'A.createStampA2, A.markForDeleteA2, A.modifyStampA2, A.classnameA2A2, A.idA2A2, A.updateCountA2, A.updateStampA2 ' ||
'from ChoiceMappableChoiceLink A, ControlBranch B ' ||
'where A.branchidA3B5 = B.idA2A2';
insert_ddl2 :=
'insert into ChoiceMappableChoiceLink(exclude, instanceValue, classnamekeyroleAObjectRef, idA3A5, classnamekeyroleBObjectRef, idA3B5, branchIdA3B5, ' ||
'createStampA2, markForDeleteA2, modifyStampA2, classnameA2A2, idA2A2, updateCountA2, updateStampA2) ' ||
'select exclude, instanceValue, classnamekeyroleAObjectRef, idA3A5, classnamekeyroleBObjectRef, idA3B5, branchIdA3B5, ' ||
'createStampA2, markForDeleteA2, modifyStampA2, classnameA2A2, idA2A2, updateCountA2, updateStampA2 from CMCLink';
execute immediate insert_ddl1;
execute immediate 'delete from ChoiceMappableChoiceLink';
execute immediate insert_ddl2;
commit;
end UPDATE_CMCL;
PROCEDURE UPDATE_OSML IS
insert_ddl1 VARCHAR2(1000);
insert_ddl2 VARCHAR2(1000);
begin
insert_ddl1 :=
'insert into OSMLink(endDate, classnamekeyroleAObjectRef, idA3A5, classnamekeyroleBObjectRef, idA3B5, branchIdA3B5, startDate, ' ||
'createStampA2, markForDeleteA2, modifyStampA2, classnameA2A2, idA2A2, updateCountA2, updateStampA2) ' ||
'select A.endDate, A.classnamekeyroleAObjectRef, A.idA3A5, ''com.ptc.windchill.option.model.ChoiceMaster'', B.idA3B5, A.branchIdA3B5, A.startDate, ' ||
'A.createStampA2, A.markForDeleteA2, A.modifyStampA2, A.classnameA2A2, A.idA2A2, A.updateCountA2, A.updateStampA2 ' ||
'from OptionSetMemberLink A, ControlBranch B ' ||
'where A.branchidA3B5 = B.idA2A2';
insert_ddl2 :=
'insert into OptionSetMemberLink(endDate, classnamekeyroleAObjectRef, idA3A5, classnamekeyroleBObjectRef, idA3B5, branchIdA3B5, startDate, ' ||
'createStampA2, markForDeleteA2, modifyStampA2, classnameA2A2, idA2A2, updateCountA2, updateStampA2) ' ||
'select endDate, classnamekeyroleAObjectRef, idA3A5, classnamekeyroleBObjectRef, idA3B5, branchIdA3B5, startDate, ' ||
'createStampA2, markForDeleteA2, modifyStampA2, classnameA2A2, idA2A2, updateCountA2, updateStampA2 from OSMLink';
execute immediate insert_ddl1;
execute immediate 'delete from OptionSetMemberLink';
execute immediate insert_ddl2;
commit;
end UPDATE_OSML;
PROCEDURE DROP_TABLE (p_TableName IN VARCHAR2) IS
v_cursor        NUMBER;
v_dropString    VARCHAR2(100);
BEGIN
v_cursor := DBMS_SQL.OPEN_CURSOR;
v_DropString := 'DROP TABLE ' || p_TableName || ' cascade constraint';
BEGIN
DBMS_SQL.PARSE(v_Cursor, v_DropString, DBMS_SQL.NATIVE);
EXCEPTION
WHEN OTHERS THEN
IF SQLCODE != -942 THEN
RAISE;
END IF;
END;
DBMS_SQL.CLOSE_CURSOR(v_cursor);
EXCEPTION
WHEN OTHERS THEN
DBMS_SQL.CLOSE_CURSOR(v_cursor);
RAISE;
END DROP_TABLE;
end LinkUpdatePK;
/

