create package FTValidator_Helper_PK IS
PROCEDURE should_validate_class(
p_Error_Class     IN     VARCHAR2
, p_FT_Config_Data  IN OUT FTVAL_CONFIG_TABLE
, p_Answer             OUT  BOOLEAN);
--
PROCEDURE should_validate_chunk(
p_Error_Class     IN     VARCHAR2
, p_FT_Config_Data  IN OUT FTVAL_CONFIG_TABLE
, p_Answer             OUT  BOOLEAN);
--
PROCEDURE should_validate_error(
p_Error_Code      IN     NUMBER
, p_Error_Class     IN     VARCHAR2
, p_FT_Config_Data  IN OUT FTVAL_CONFIG_TABLE
, p_Answer             OUT BOOLEAN);
PROCEDURE record_errors(
p_Error_Code      IN     NUMBER
, p_Error_Class     IN     VARCHAR2
, p_FT_Config_Data  IN OUT FTVAL_CONFIG_TABLE
, p_FT_Status_Data  IN OUT FT_STATUS_TABLE
, p_FT_Report_Data  IN OUT FT_REPORT_DATA
, p_Continue           OUT BOOLEAN);
---
PROCEDURE should_return_collection(
p_FT_Config_Data  IN     FTVAL_CONFIG_TABLE
, p_Answer           OUT BOOLEAN);
--
PROCEDURE Truncate_EPMFTValPK_Errs;
--
PROCEDURE append_report_data(old_FT_Report_Data  IN OUT FT_REPORT_DATA
, new_FT_Report_Data  IN     FT_REPORT_DATA);
END;
/

