create PACKAGE BODY EpmPK IS
-- Executes a query over a set of classes (and their subclasses).
-- Input Parameters:
--     listsOfTables -- lists of database tables to execute the query over
--     queryTemplate -- query to execute
--     attributes    -- list of numeric attributes to query over (values for the bind parameter)
-- Returns:
--     object identifier for each object returned by the query
FUNCTION query(listsOfTables TABLE_OF_VARCHAR2_200, queryTemplate VARCHAR2, attributes TABLE_OF_NUMBER)
RETURN OID_OBJECT_LIST IS
query VARCHAR2(32767);
TYPE ObjectCursorType IS REF CURSOR;
objectCursor ObjectCursorType;
className   VARCHAR(200);
databaseId  NUMBER;
objectIds OID_OBJECT_LIST := OID_OBJECT_LIST();
BEGIN
FOR i IN listsOfTables.FIRST..listsOfTables.LAST
LOOP
query := REPLACE(queryTemplate, '@tables', listsOfTables(i));
FOR j IN attributes.FIRST..attributes.LAST
LOOP
OPEN objectCursor FOR query USING attributes(j);
LOOP
FETCH objectCursor INTO className, databaseId;
EXIT WHEN objectCursor%NOTFOUND;
objectIds.EXTEND();
objectIds(objectIds.LAST) := OID_OBJECT(className, databaseId);
END LOOP;
CLOSE objectCursor;
END LOOP;
END LOOP;
RETURN objectIds;
END query;
/* -------------------------------------------------------------------------- */
-- Executes a query over a set of classes (and its subclasses).
-- Input Parameters:
--     listsOfTables -- lists of database tables to execute the query over
--     queryTemplate -- query to execute
--     attributes    -- list of string attributes to query over (values for the bind parameter)
-- Returns:
--     object identifier for each object returned by the query
FUNCTION query(listsOfTables TABLE_OF_VARCHAR2_200, queryTemplate VARCHAR2, attributes TABLE_OF_VARCHAR2)
RETURN OID_OBJECT_LIST IS
query VARCHAR2(32767);
TYPE ObjectCursorType IS REF CURSOR;
objectCursor ObjectCursorType;
className   VARCHAR(200);
databaseId  NUMBER;
objectIds OID_OBJECT_LIST := OID_OBJECT_LIST();
BEGIN
FOR i IN listsOfTables.FIRST..listsOfTables.LAST
LOOP
query := REPLACE(queryTemplate, '@tables', listsOfTables(i));
FOR j IN attributes.FIRST..attributes.LAST
LOOP
OPEN objectCursor FOR query USING attributes(j);
LOOP
FETCH objectCursor INTO className, databaseId;
EXIT WHEN objectCursor%NOTFOUND;
objectIds.EXTEND();
objectIds(objectIds.LAST) := OID_OBJECT(className, databaseId);
END LOOP;
CLOSE objectCursor;
END LOOP;
END LOOP;
RETURN objectIds;
END query;
/* -------------------------------------------------------------------------- */
-- Deletes objects of a given class (and its subclasses).
-- Input Parameters:
--     tableNames     -- names of the database tables for the object class and its subclasses
--     deleteTemplate -- delete statement to execute
--     attributes     -- list of numeric attributes that specify which objects to delete (values for the bind parameter)
-- Returns:
--     number of objects of the given class that were deleted
FUNCTION deleteObjs(tableNames TABLE_OF_VARCHAR2_30, deleteTemplate VARCHAR2, attributes TABLE_OF_NUMBER)
RETURN NUMBER IS
deleteObjects VARCHAR2(32767);
rowsDeleted NUMBER := 0;
BEGIN
FOR i IN tableNames.FIRST..tableNames.LAST
LOOP
deleteObjects := REPLACE(deleteTemplate, '@table', tableNames(i));
FORALL j IN attributes.FIRST..attributes.LAST
EXECUTE IMMEDIATE deleteObjects USING attributes(j);
rowsDeleted := rowsDeleted + SQL%ROWCOUNT;
END LOOP;
RETURN rowsDeleted;
END deleteObjs;
/* -------------------------------------------------------------------------- */
END EpmPK;
/

