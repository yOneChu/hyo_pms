create type FVITEMS_INS_RET as object(stream_id NUMBER, unique_seq_number NUMBER)
/

