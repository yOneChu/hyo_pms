create PACKAGE IBAValuesPK IS
FUNCTION getMatchingStringValue(definitionID1 NUMBER, definitionID2 NUMBER, value VARCHAR2) RETURN VARCHAR2 DETERMINISTIC;
FUNCTION getMatchingNumberValue(definitionID1 NUMBER, definitionID2 NUMBER, value NUMBER) RETURN NUMBER DETERMINISTIC;
FUNCTION getMatchingDateValue(definitionID1 NUMBER, definitionID2 NUMBER, value DATE) RETURN DATE DETERMINISTIC;
FUNCTION CopyIBAValuesMultiple(i_id_oid_object_list IN ID_OID_OBJECT_LIST) RETURN NUMBER;
FUNCTION BulkCopyIBAValuesMultiple(i_id_oid_object_list IN ID_OID_OBJECT_LIST) RETURN NUMBER;
END IBAValuesPK;
/

