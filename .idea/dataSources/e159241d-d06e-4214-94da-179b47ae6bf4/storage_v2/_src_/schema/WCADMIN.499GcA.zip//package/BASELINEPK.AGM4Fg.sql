create PACKAGE BaselinePK IS
FUNCTION getBaselineVersions(baselineMemberTuple BASELINE_MEMBER_TUPLE) RETURN OID_OBJECT_LIST;
FUNCTION getBaselinesVersions(baselineMemberTupleList BASELINE_MEMBER_TUPLE_LIST) RETURN OID_OBJECT_LIST;
FUNCTION insertMemberLinks(baseline OID_OBJECT, baselineable_oid_list OID_OBJECT_LIST) RETURN NUMBER;
FUNCTION replaceBaselineMemberLinks (origlink_oid_list OID_OBJECT_LIST, replacement_oid_list IN OID_OBJECT_LIST)  RETURN NUMBER;
FUNCTION removeBaselineMemberLinks (baselineMemberOids IN TABLE_OF_NUMBER) RETURN NUMBER;
END BaselinePK;
/

