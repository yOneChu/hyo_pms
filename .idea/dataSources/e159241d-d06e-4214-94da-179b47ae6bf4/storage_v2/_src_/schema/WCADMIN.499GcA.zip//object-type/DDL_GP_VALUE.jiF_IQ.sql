create type DDL_GP_VALUE as object(part_id NUMBER, part_usage_id NUMBER, part_classname VARCHAR2(200),
part_location VARCHAR2(400), part_level NUMBER, part_name VARCHAR2(60), part_number VARCHAR2(62), part_type VARCHAR2(20))
/

