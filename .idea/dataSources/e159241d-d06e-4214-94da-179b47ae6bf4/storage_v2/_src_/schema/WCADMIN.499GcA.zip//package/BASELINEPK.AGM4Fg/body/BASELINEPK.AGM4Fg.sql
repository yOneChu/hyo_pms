create PACKAGE BODY BaselinePK IS
FUNCTION getBaselineVersions(baselineMemberTuple BASELINE_MEMBER_TUPLE)
RETURN OID_OBJECT_LIST IS
baselineList OID_OBJECT_LIST;
returnedBaselineList OID_OBJECT_LIST;
TYPE BaselineCursorRef IS REF CURSOR;
baselineCursor BaselineCursorRef;
successorBaselineClassName VARCHAR2(200);
successorBaselineId NUMBER;
successorBaselineLatest NUMBER(1);
BEGIN
OPEN baselineCursor FOR 'SELECT baseline.classNameA2A2, baseline.idA2A2, baseline.latestIterationInfo
FROM ' || baselineMemberTuple.baselineRow.tableName || ' baseline
WHERE baseline.idA3C2IterationInfo = ' || baselineMemberTuple.baselineRow.id || '';
LOOP
FETCH baselineCursor INTO successorBaselineClassName, successorBaselineId, successorBaselineLatest;
EXIT WHEN baselineCursor%NOTFOUND;
IF successorBaselineLatest = 1 THEN
IF baselineList IS NULL THEN
baselineList := OID_OBJECT_LIST();
END IF;
baselineList.EXTEND;
baselineList(baselineList.LAST) := OID_OBJECT(successorBaselineClassName, successorBaselineId);
END IF;
returnedBaselineList := getBaselineVersions(BASELINE_MEMBER_TUPLE(baselineMemberTuple.baselineMemberRow, ROW_OBJECT(baselineMemberTuple.baselineRow.tableName, successorBaselineId)));
IF returnedBaselineList IS NOT NULL THEN
IF baselineList IS NULL THEN
baselineList := returnedBaselineList;
ELSE
FOR i IN returnedBaselineList.FIRST..returnedBaselineList.LAST LOOP
baselineList.EXTEND;
baselineList(baselineList.LAST) := returnedBaselineList(i);
END LOOP;
END IF;
END IF;
END LOOP;
CLOSE baselineCursor;
RETURN baselineList;
END getBaselineVersions;
FUNCTION getBaselinesVersions(baselineMemberTupleList BASELINE_MEMBER_TUPLE_LIST)
RETURN OID_OBJECT_LIST IS
baselineList OID_OBJECT_LIST;
returnedBaselineList OID_OBJECT_LIST;
BEGIN
FOR i IN baselineMemberTupleList.FIRST..baselineMemberTupleList.LAST LOOP
returnedBaselineList := getBaselineVersions(baselineMemberTupleList(i));
IF returnedBaselineList IS NOT NULL THEN
IF baselineList IS NULL THEN
baselineList := returnedBaselineList;
ELSE
FOR j IN returnedBaselineList.FIRST..returnedBaselineList.LAST LOOP
baselineList.EXTEND;
baselineList(baselineList.LAST) := returnedBaselineList(j);
END LOOP;
END IF;
END IF;
END LOOP;
RETURN baselineList;
END getBaselinesVersions;
/* Given the lastUsed id, get the next id available.
* ids are allocated in groups of 100.  This function determine whether to get the value
* from the cache or to allocate a new batch.
* For the first id, input should be 0, 0
*/
FUNCTION getNextId(lastUsed IN OUT NUMBER, maxAvailable IN OUT NUMBER) RETURN NUMBER IS
nextId NUMBER := 0;
BEGIN
IF lastUsed = maxAvailable THEN
SELECT id_sequence.NEXTVAL into nextId from DUAL;
maxAvailable := nextId + 99;
ELSE
nextId := lastUsed + 1;
END IF;
lastUsed := nextId;
RETURN nextId;
END getNextId;
/* Insert BaselineMember links.  Takes baseline and list of Baselineables
*/
FUNCTION insertMemberLinks (baseline IN OID_OBJECT, baselineable_oid_list IN OID_OBJECT_LIST) RETURN NUMBER IS
insert_error EXCEPTION;
current_time DATE;
link_id NUMBER := 0;
max_available NUMBER := 0;
num_recs NUMBER;
link_classname_string CONSTANT VARCHAR(200) := 'wt.vc.baseline.BaselineMember';
total_rows NUMBER;
new_id  TABLE_OF_NUMBER;
oid_class TABLE_OF_VARCHAR2;
oid_value TABLE_OF_NUMBER;
BEGIN
--DBMS_OUTPUT.PUT_LINE( 'From stored procedure: insertMemberLinks\n');
SELECT sysdate INTO current_time FROM DUAL;
/* Insert new values with new sequence values.*/
num_recs := baselineable_oid_list.COUNT;
new_id := TABLE_OF_NUMBER();
oid_class := TABLE_OF_VARCHAR2();
oid_value := TABLE_OF_NUMBER();
new_id.EXTEND(num_recs);
oid_class.EXTEND(num_recs);
oid_value.EXTEND(num_recs);
FOR j in 1 .. num_recs
LOOP
--DBMS_OUTPUT.PUT_LINE(j);
-- Bulk bind does not handle nested records.  Reformat for performance
link_id := getNextId(link_id, max_available);
new_id(j) := link_id;
oid_class(j) := baselineable_oid_list(j).classname;
oid_value(j) := baselineable_oid_list(j).id;
--dbms_output.put_line('Link id: classname, oid: ' || new_id(j) || ' ' || oid_class(j) || ' ' || oid_value(j));
END LOOP;
FORALL i in 1 .. num_recs
INSERT INTO BaselineMember (classnamekeyroleAObjectRef, idA3A5, classnamekeyroleBObjectRef,
idA3B5, createStampA2, modifyStampA2, classnameA2A2,
idA2A2, updateCountA2,  updateStampA2, markForDeleteA2)
VALUES(baseline.className, baseline.id, oid_class(i),
oid_value(i),
current_time, current_time,
link_classname_string, new_id(i) , 1, current_time, 0);
total_rows := 0;
FOR i IN baselineable_oid_list.FIRST .. baselineable_oid_list.LAST
LOOP
total_rows := total_rows + SQL%BULK_ROWCOUNT(i);
END LOOP;
if total_rows != num_recs then
raise insert_error;
end if;
RETURN num_recs;
EXCEPTION  -- exception handlers begin
WHEN insert_error THEN  -- handles failed insert
RETURN -1;
WHEN OTHERS THEN        -- handles all other errors
RETURN -1;
END insertMemberLinks;
/* Replace iteration of Baselineable in Baseline with new iteration.
* Takes list of original BaselineMember links and corresponding list of replacement Baselineables
*/
FUNCTION replaceBaselineMemberLinks (origlink_oid_list IN OID_OBJECT_LIST, replacement_oid_list IN OID_OBJECT_LIST) RETURN NUMBER IS
insert_error EXCEPTION;
current_time DATE;
num_recs NUMBER;
total_rows NUMBER;
BEGIN
--DBMS_OUTPUT.PUT_LINE( 'From stored procedure: replaceMemberLinks\n');
SELECT sysdate INTO current_time FROM DUAL;
/* Replace Baselineable (Role B) of BaselineMemberlink with different iteration.*/
num_recs := origlink_oid_list.LAST;
total_rows := 0;
FOR i in 1 .. num_recs
LOOP
UPDATE BaselineMember
SET idA3B5 = replacement_oid_list(i).id,
classnamekeyroleBObjectRef = replacement_oid_list(i).classname,
modifyStampA2 = current_time,
updateCountA2 = NVL(UPDATECOUNTA2 + 1, 1),
updateStampA2 = current_time
WHERE idA2A2 = origlink_oid_list(i).id;
total_rows := total_rows + SQL%ROWCOUNT;
END LOOP;
if total_rows != num_recs then
raise insert_error;
end if;
RETURN num_recs;
EXCEPTION  -- exception handlers begin
WHEN insert_error THEN  -- handles failed insert
RETURN -1;
WHEN OTHERS THEN        -- handles all other errors
RETURN -1;
END replaceBaselineMemberLinks;
/* Removes Baselineables from Baseline
* Takes list of oids of BaselineMember links to remove
*/
FUNCTION removeBaselineMemberLinks (baselineMemberOids IN TABLE_OF_NUMBER) RETURN NUMBER IS
delete_error EXCEPTION;
num_recs NUMBER;
total_rows NUMBER;
BEGIN
--DBMS_OUTPUT.PUT_LINE( 'From stored procedure: removeBaselineMemberLinks\n');
num_recs := baselineMemberOids.LAST;
total_rows := 0;
FORALL i in 1 .. num_recs
DELETE FROM BaselineMember
WHERE idA2A2 = baselineMemberOids(i);
total_rows := 0;
FOR i IN baselineMemberOids.FIRST .. baselineMemberOids.LAST
LOOP
total_rows := total_rows + SQL%BULK_ROWCOUNT(i);
END LOOP;
if total_rows != num_recs then
raise delete_error;
end if;
RETURN num_recs;
EXCEPTION  -- exception handlers begin
WHEN delete_error THEN  -- handles failed insert
RETURN -1;
WHEN OTHERS THEN        -- handles all other errors
RETURN -1;
END removeBaselineMemberLinks;
END BaselinePK;
/

