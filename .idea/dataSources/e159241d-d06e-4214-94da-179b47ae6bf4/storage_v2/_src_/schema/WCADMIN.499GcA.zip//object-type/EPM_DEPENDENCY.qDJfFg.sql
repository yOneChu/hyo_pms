create TYPE EPM_DEPENDENCY AS OBJECT (
roleAclassName VARCHAR2(200),
roleAId        NUMBER,
roleBclassName VARCHAR2(200),
roleBId        NUMBER,
className      VARCHAR2(200),
id             NUMBER,
required NUMBER(1),
depType  NUMBER)
/

