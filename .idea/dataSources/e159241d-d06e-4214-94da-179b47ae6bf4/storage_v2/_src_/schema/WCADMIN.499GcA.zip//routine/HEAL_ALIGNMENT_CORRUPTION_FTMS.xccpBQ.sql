create procedure heal_alignment_corruption_ftms (v_lasthealedtimestamp IN date, v_error OUT varchar2) is

   v_healable varchar2(100);
   v_max_run_cnt number;
   v_rows_updated number;
   v_sqlstmt varchar2(8000);
   type refcur is ref cursor;
   c_ALIGNMENT_EPMFTMS refcur;

 TYPE fetch_array_master IS TABLE OF MIG$EPMFTMCONTAINERS%ROWTYPE;
 s_array_ftms fetch_array_master;

begin
  dbms_output.put_line('============================================================');
  dbms_output.put_line('Heal Alignment corruption....heal_alignment_corruption_ftms-10.sql');
  dbms_output.put_line(to_char(sysdate,'MM/DD/YYYY HH24:MI:SS'));
  dbms_output.put_line('============================================================');

  dbms_output.put_line('Align the container of the family table master with its first iteration if they belong to different containers.');

  dbms_output.put_line(to_char(sysdate,'MM/DD/YYYY HH24:MI:SS'));

  v_sqlstmt := 'select  distinct ftm.ida2a2 FTMID, ftm.classnamea2a2, ft.classnamekeycontainerreferen FTCCLASS, ft.ida3containerreference FTCREF
   		, ftm.classnamekeycontainerreferen FTMCCLASS, ftm.ida3containerreference FTMCREF, sysdate
   		, decode(lost.status,null,''Object not Migrated'',decode(lost.status,1,decode(ft.STATECHECKOUTINFO,''c/i'',''Healable'',''Object not checked in''),''Object was not migrated successfully'')) isHealable
              	, :max_run_cnt  runcount
		from epmsepfamilytablemaster ftm, epmsepfamilytable ft, lotowcstatus lost
		where
		      ftm.ida2A2 = ft.ida3masterreference
		      and ftm.ida3containerreference <> ft.ida3containerreference
		      and ft.ida3C2iterationinfo = 0
		      and lost.epmsepfamilytablemasterid(+) = ftm.ida2a2
		      and ft.classnamekeycontainerreferen in (''wt.pdmlink.PDMLinkProduct'',''wt.inf.library.WTLibrary'')';

  select nvl(max(runcount),0) into  v_max_run_cnt from MIG$EPMFTMCONTAINERS;
  v_max_run_cnt := v_max_run_cnt+1;
  v_error :='No Errors';

  if (v_lasthealedtimestamp is not null) then
    v_sqlstmt := v_sqlstmt||' and loadtime>'''||v_lasthealedtimestamp||'''';
  end if;

  dbms_output.put_line(to_char(sysdate,'MM/DD/YYYY HH24:MI:SS'));

  OPEN c_ALIGNMENT_EPMFTMS for v_sqlstmt using v_max_run_cnt;
  LOOP
    FETCH c_ALIGNMENT_EPMFTMS BULK COLLECT INTO s_array_ftms LIMIT 10000;
    FORALL i IN 1..s_array_ftms.COUNT
     insert into MIG$EPMFTMCONTAINERS values s_array_ftms(i);
    EXIT WHEN c_ALIGNMENT_EPMFTMS%NOTFOUND;
  END LOOP;
  CLOSE c_ALIGNMENT_EPMFTMS;

  dbms_output.put_line(to_char(sysdate,'MM/DD/YYYY HH24:MI:SS'));

  update epmsepfamilytablemaster toUpdate set ( classnamekeycontainerreferen, ida3containerreference ) = ( select classnamekeycontainerreferen, ida3containerreference
                from MIG$EPMFTMCONTAINERS  where MIG$EPMFTMCONTAINERS.ida2a2 = toUpdate.ida2A2 and runcount=v_max_run_cnt and healable = 'Healable' and MIG$EPMFTMCONTAINERS.classnamea2a2 = 'wt.epm.familytable.EPMSepFamilyTableMaster')
  where toUpdate.ida2a2 in ( select MIG$EPMFTMCONTAINERS.ida2a2  from MIG$EPMFTMCONTAINERS where runcount=v_max_run_cnt and healable = 'Healable'
    and MIG$EPMFTMCONTAINERS.classnamea2a2 = 'wt.epm.familytable.EPMSepFamilyTableMaster');

  v_rows_updated:=sql%rowcount;
  dbms_output.put_line('epmsepfamilytablemaster Rows Updated='||v_rows_updated);
  dbms_output.put_line(to_char(sysdate,'MM/DD/YYYY HH24:MI:SS'));

  commit;

  dbms_output.put_line(to_char(sysdate,'MM/DD/YYYY HH24:MI:SS'));

  exception when others then
	Rollback;
	v_error := DBMS_UTILITY.format_error_stack;
	dbms_output.put_line('FILENAME$NonHealable_alignment_corruption_ftms-10.html$');

end;
/

