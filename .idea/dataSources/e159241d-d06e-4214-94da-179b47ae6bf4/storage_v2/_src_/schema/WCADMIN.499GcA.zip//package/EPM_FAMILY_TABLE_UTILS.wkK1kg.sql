create package epm_family_table_utils as
procedure getFTMaster(p_docs          in out nocopy table_of_number,
p_ft_master_id     out table_of_number,
p_ft_master_name   out table_of_varchar2);
--  PRAGMA RESTRICT_REFERENCES(getFTMaster, WNPS);
procedure getFTMaster(p_docs          in out nocopy table_of_number,
p_ft_master_id     out table_of_number,
p_ft_master_name   out table_of_varchar2,
p_num_calls        out number);
--  PRAGMA RESTRICT_REFERENCES(getFTMaster, WNPS);
procedure getFTCompatible(p_docs             table_of_number,
p_proj_id          number,
p_proj_classes     table_of_varchar2,
p_masters      out table_of_number,
p_compatibles  out table_of_table_of_number,
p_content      out table_of_table_of_number,
p_completes    out table_of_table_of_number,
p_num_calls    out table_of_number);
--  PRAGMA RESTRICT_REFERENCES(getFTCompatible, WNPS);
end;
/

