create TYPE ID_UPDATE_COUNT_OBJECT AS OBJECT (
   id   NUMBER,
   updateCount   NUMBER)
/

