create procedure heal_misalign_containers (v_lasthealedtimestamp IN date, v_error OUT varchar2) is
   v_healable varchar2(100);
   v_max_run_cnt number;
   v_rows_updated number;
   v_sqlstmt varchar2(8000);
   type refcur is ref cursor;
   c_ALIGNMENT_EPMDOCUMENTMASTER refcur;
   c_ALIGNMENT_EPMDOCUMENT refcur;


  TYPE fetch_array IS TABLE OF MIG$MISALIGNCONTAINER%ROWTYPE;
  s_array fetch_array;

begin
  dbms_output.put_line('============================================================');
  dbms_output.put_line('Heal Alignment corruption....heal_misalign_containers_1_2.sql');
  dbms_output.put_line(to_char(sysdate,'MM/DD/YYYY HH24:MI:SS'));
  dbms_output.put_line('============================================================');

  dbms_output.put_line('------------Healing EPMDocumentMaster---------------');
  dbms_output.put_line('Update master to be in same container as latest-latest where mismatched');

  dbms_output.put_line(to_char(sysdate,'MM/DD/YYYY HH24:MI:SS'));


  v_sqlstmt := 'select  distinct m.ida2a2 ,  m.classnamea2a2, doc.classnamekeyContainerReferen DCName, doc.idA3containerReference DCref
   		, m.classnamekeyContainerReferen MCName, m.idA3containerReference MCref, sysdate
   		, decode(pivst.status,null,''Object not Migrated'',decode(pivst.status,1,decode(doc.STATECHECKOUTINFO,''c/i'',''Healable'',''Object not checked in''),''Object was not migrated successfully'')) isHealable
              	, :v_max_run_cnt  runcount
		from EPMDocument doc, EPMDocumentMaster m, pivtowcstatus pivst,
			( select * from (
			   select d.idA2A2, rank() over (
				   partition by d.idA3masterReference
				   order by decode(d.statecheckoutinfo, ''wrk'', 0, 1) desc,
				   d.versionSortIdA2versionInfo desc
				   ) rank
			   from EPMDocument d
			   where d.latestiterationInfo = 1
               and d.classnamekeycontainerreferen in (''wt.inf.library.WTLibrary'',''wt.pdmlink.PDMLinkProduct'')
			   ) where rank = 1
			 )sub
		where doc.idA3masterReference = m.idA2A2
			and doc.idA3containerReference <> m.idA3containerReference
			and doc.latestiterationInfo = 1
			and doc.idA2A2 = sub.idA2A2
			and pivst.epmdocumentid(+) = doc.ida2a2
			and pivst.documenttype = 0
			and doc.classnamekeycontainerreferen in (''wt.inf.library.WTLibrary'',''wt.pdmlink.PDMLinkProduct'')';

  select nvl(max(runcount),0) into  v_max_run_cnt from MIG$MISALIGNCONTAINER;
  v_max_run_cnt:=v_max_run_cnt+1;
  v_error :='No Errors';

  if (v_lasthealedtimestamp is not null) then
    v_sqlstmt := v_sqlstmt||' and loadtime>'''||v_lasthealedtimestamp||'''';
  end if;

  OPEN c_ALIGNMENT_EPMDOCUMENTMASTER for v_sqlstmt using v_max_run_cnt;

  LOOP
    FETCH c_ALIGNMENT_EPMDOCUMENTMASTER BULK COLLECT INTO s_array LIMIT 10000;
    FORALL i IN 1..s_array.COUNT
     insert into MIG$MISALIGNCONTAINER values s_array(i);
    EXIT WHEN c_ALIGNMENT_EPMDOCUMENTMASTER%NOTFOUND;
  END LOOP;
  CLOSE c_ALIGNMENT_EPMDOCUMENTMASTER;

  dbms_output.put_line(to_char(sysdate,'MM/DD/YYYY HH24:MI:SS'));

  --Check where clause is required for correlated update or not
  update EPMDocumentMaster dm set (classnamekeyContainerReferen, idA3containerReference) = (select classnamekeyContainerReferen, idA3containerReference from MIG$MISALIGNCONTAINER mc
      where dm.idA2A2 = mc.ida2a2 and mc.runcount=v_max_run_cnt  and mc.classnamea2a2 = 'wt.epm.EPMDocumentMaster' and mc.healable = 'Healable')
  where idA2A2 in (select ida2a2 from MIG$MISALIGNCONTAINER where runcount=v_max_run_cnt  and classnamea2a2 = 'wt.epm.EPMDocumentMaster' and healable = 'Healable' );

  v_rows_updated:=sql%rowcount;
  dbms_output.put_line('EPMDocumentMaster Rows Updated='||v_rows_updated);
  dbms_output.put_line(to_char(sysdate,'MM/DD/YYYY HH24:MI:SS'));

  dbms_output.put_line('------------Healing EPMDocument---------------');
  dbms_output.put_line('Align all iterations of a documents to have same container as that master if they do not already.');

  dbms_output.put_line(to_char(sysdate,'MM/DD/YYYY HH24:MI:SS'));

  v_sqlstmt := 'select distinct d.idA2A2 docid, d.classnamea2a2, m.classnamekeyContainerReferen MClassRef, m.idA3containerReference MCref
    		, d.classnamekeyContainerReferen DClassRef, d.idA3containerReference DCref, sysdate
  		, decode(pivst.status,null,''Object not Migrated'',
  			decode(pivst.status,1,
  				decode(d.STATECHECKOUTINFO,''c/i'',''Healable'',''Object not checked in''),''Object was not migrated successfully'')) isHealable
  		, :1  runcount
  		from EPMDocument d, EPMDocumentMaster m, pivtowcstatus pivst
		where
		    pivst.epmdocumentid(+) = d.ida2a2
		    and d.idA3masterReference = m.idA2A2
		    and d.idA3containerReference <> m.idA3containerReference
		    and pivst.DOCUMENTTYPE = 0
		    and d.classnamekeycontainerreferen in (''wt.inf.library.WTLibrary'',''wt.pdmlink.PDMLinkProduct'')';

  if (v_lasthealedtimestamp is not null) then
          v_sqlstmt := v_sqlstmt||' and loadtime>'''||v_lasthealedtimestamp||'''';
  end if;

  OPEN c_ALIGNMENT_EPMDOCUMENT for v_sqlstmt using v_max_run_cnt;
    LOOP
      FETCH c_ALIGNMENT_EPMDOCUMENT BULK COLLECT INTO s_array LIMIT 10000;
      FORALL i IN 1..s_array.COUNT
       insert into MIG$MISALIGNCONTAINER values s_array(i);
      EXIT WHEN c_ALIGNMENT_EPMDOCUMENT%NOTFOUND;
    END LOOP;
  CLOSE c_ALIGNMENT_EPMDOCUMENT;

  dbms_output.put_line(to_char(sysdate,'MM/DD/YYYY HH24:MI:SS'));

  --Check where clause is required for correlated update or not
  update EPMDocument set (classnamekeyContainerReferen, idA3containerReference) =
  	(select classnamekeyContainerReferen, idA3containerReference
  	from MIG$MISALIGNCONTAINER
        where EPMDocument.idA2A2 = MIG$MISALIGNCONTAINER.idA2A2 and runcount=v_max_run_cnt and MIG$MISALIGNCONTAINER.classnamea2a2 = 'wt.epm.EPMDocument' and healable = 'Healable')
  where idA2A2 in (select ida2a2 from MIG$MISALIGNCONTAINER where runcount=v_max_run_cnt and MIG$MISALIGNCONTAINER.classnamea2a2 = 'wt.epm.EPMDocument' and healable = 'Healable')
  and idA3masterreference in (select ida2a2 from MIG$MISALIGNCONTAINER where runcount=v_max_run_cnt and classnamea2a2 = 'wt.epm.EPMDocumentMaster' and healable = 'Healable');

  v_rows_updated:=sql%rowcount;
  dbms_output.put_line('EPMDocument Rows Updated='||v_rows_updated);
  dbms_output.put_line(to_char(sysdate,'MM/DD/YYYY HH24:MI:SS'));

  commit;

  dbms_output.put_line(to_char(sysdate,'MM/DD/YYYY HH24:MI:SS'));

  exception when others then
	Rollback;
	v_error := DBMS_UTILITY.format_error_stack;
	dbms_output.put_line('FILENAME$NonHealable_misalign_containers_1_2.html$');

end;
/

