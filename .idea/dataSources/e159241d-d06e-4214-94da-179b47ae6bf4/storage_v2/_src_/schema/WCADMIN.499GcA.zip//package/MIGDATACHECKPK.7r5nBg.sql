create PACKAGE migdatacheckpk
IS
   TYPE tofv is table of varchar2(4000);
   restartMethodServer number ;
   --
   procedure truncateMigVerifyDatalog;
   function  findNullAttrvalFamTabs return number;
   procedure findNullAttrvalInfo ;
   procedure replaceNonUnicode;
   procedure fixNullAttrvalFamTabs;
   procedure detectAndHealPTCCommonName( var_rows OUT NUMBER );
   procedure fixnewlineinattrvalfamtabs;
   procedure healMemberLinkIdentifier;
   procedure healUniqueLinkId;
   function  replaceControls(in_str varchar2) return varchar2;
   function  hasControls(in_str varchar2) return number;
   function  getString  return varchar2;
   function  getNewString  return varchar2;
   procedure processHasControls(excl_chars tofv default tofv());
   --
   function checkData return number;
END;
/

