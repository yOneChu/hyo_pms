create PACKAGE BODY WipPK IS
FUNCTION getNormalizedWipState(state VARCHAR2)
RETURN NUMBER IS
BEGIN
IF state = 'wrk'  OR
state = 'wrk-p' OR
state = 'to wrk' OR
state = 'to wrk-p' OR
state = 'to del-p' OR
state = 'to del'
THEN
RETURN 0;
ELSE
RETURN 1;
END IF;
END getNormalizedWipState;
END WipPK;
/

