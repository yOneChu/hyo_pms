create TYPE ID_OID_OBJECT AS OBJECT (
   id   NUMBER,
   oid   OID_OBJECT)
/

