create procedure clean_ownership_info (v_lasthealedtimestamp IN date, v_error OUT varchar2) is
   v_healable varchar2(100);
   v_max_run_cnt number;
   v_sqlstmt varchar2(8000);
   type refcur is ref cursor;
   c_OWNERSHIP refcur;

 TYPE fetch_array IS TABLE OF MIG$OWNERSHIP%ROWTYPE;
 s_array fetch_array;
begin
  dbms_output.put_line('============================================================');
  dbms_output.put_line('Clean ownership info....clean_ownership_info.sql');
  dbms_output.put_line(to_char(sysdate,'MM/DD/YYYY HH24:MI:SS'));
  dbms_output.put_line('============================================================');

  v_sqlstmt := 'select distinct m.ida2a2, m.classnamekeya2ownership, m.ida3a2ownership, pivst.DOCUMENTTYPE,sysdate,
                decode(pivst.status,null,''Object not Migrated'',decode(pivst.status,1,decode(m.STATECHECKOUTINFO,''c/i'',''Healable'',''Object not checked in''),''Object was not migrated successfully''))
		,:max_run_cnt  runcount
                from EPMDocument m, pivtowcstatus pivst
		where m.ida2a2 = pivst.EPMDOCUMENTID
  		  and pivst.STATUS = 1
  		  and pivst.DOCUMENTTYPE = 0
  		  and m.classnamekeycontainerreferen in (''wt.inf.library.WTLibrary'',''wt.pdmlink.PDMLinkProduct'')
  		  and (m.CLASSNAMEKEYA2OWNERSHIP is not null or m.IDA3A2OWNERSHIP <> 0)
  	   union all
         select distinct m.ida2a2, m.classnamekeya2ownership, m.ida3a2ownership, pivst.DOCUMENTTYPE,sysdate,
                decode(pivst.status,null,''Object not Migrated'',decode(pivst.status,1,decode(m.STATECHECKOUTINFO,''c/i'',''Healable'',''Object not checked in''),''Object was not migrated successfully''))
		,:max_run_cnt
                from WTDocument m, pivtowcstatus pivst
		where m.ida2a2 = pivst.EPMDOCUMENTID
  		  and pivst.STATUS = 1
  		  and pivst.DOCUMENTTYPE = 1
  		  and m.classnamekeycontainerreferen in (''wt.inf.library.WTLibrary'',''wt.pdmlink.PDMLinkProduct'')
  		  and (m.CLASSNAMEKEYA2OWNERSHIP is not null or m.IDA3A2OWNERSHIP <> 0)';

  select nvl(max(runcount),0) into  v_max_run_cnt from MIG$OWNERSHIP;
  v_max_run_cnt := v_max_run_cnt+1;
  v_error :='No Errors';

  if (v_lasthealedtimestamp is not null) then
    v_sqlstmt := v_sqlstmt||' and loadtime>'''||v_lasthealedtimestamp||'''';
  end if;

  dbms_output.put_line(to_char(sysdate,'MM/DD/YYYY HH24:MI:SS'));

  OPEN c_OWNERSHIP for v_sqlstmt using v_max_run_cnt,v_max_run_cnt;
  LOOP
    FETCH c_OWNERSHIP BULK COLLECT INTO s_array LIMIT 100000;
    FORALL i IN 1..s_array.COUNT
     insert /*+ APPEND */ into MIG$OWNERSHIP values s_array(i);
    EXIT WHEN c_OWNERSHIP%NOTFOUND;
  END LOOP;
  CLOSE c_OWNERSHIP;

  commit;
  dbms_stats.gather_table_stats(ownname=> user, tabname=> 'MIG$OWNERSHIP',  cascade=>true, method_opt=>'FOR ALL COLUMNS SIZE AUTO', degree=>DBMS_STATS.AUTO_DEGREE, no_invalidate=>false);

  dbms_output.put_line(to_char(sysdate,'MM/DD/YYYY HH24:MI:SS'));

  update EPMDocument m set m.CLASSNAMEKEYA2OWNERSHIP = null, m.IDA3A2OWNERSHIP = 0
	    where exists (select 1 from MIG$OWNERSHIP where m.ida2a2 = ida2a2 and DOCUMENTTYPE=0 and runcount=v_max_run_cnt and healable = 'Healable');

  dbms_output.put_line(to_char(sysdate,'MM/DD/YYYY HH24:MI:SS'));

  update WTDocument w set w.CLASSNAMEKEYA2OWNERSHIP = null, w.IDA3A2OWNERSHIP = 0
 	    where exists (select 1 from MIG$OWNERSHIP where w.ida2a2=ida2a2 and DOCUMENTTYPE=1 and  runcount=v_max_run_cnt and healable = 'Healable');

  dbms_output.put_line(to_char(sysdate,'MM/DD/YYYY HH24:MI:SS'));

  commit;

  dbms_output.put_line(to_char(sysdate,'MM/DD/YYYY HH24:MI:SS'));

  exception when others then
	Rollback;
	v_error := DBMS_UTILITY.format_error_stack;
	dbms_output.put_line('FILENAME$clean_ownership_non_healable.html$');

end;
/

