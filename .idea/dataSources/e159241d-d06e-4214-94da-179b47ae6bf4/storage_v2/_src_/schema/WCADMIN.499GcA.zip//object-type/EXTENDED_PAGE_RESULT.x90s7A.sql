create TYPE EXTENDED_PAGE_RESULT AS OBJECT (
   className1   VARCHAR2(600),
   className2   VARCHAR2(600),
   className3   VARCHAR2(600),
   className4   VARCHAR2(600),
   className5   VARCHAR2(600),
   oid1   NUMBER,
   oid2   NUMBER,
   oid3   NUMBER,
   oid4   NUMBER,
   oid5   NUMBER,
   rowExtension   NUMBER,
   rowOrder   NUMBER,
   sessionId   VARCHAR2(600))
/

