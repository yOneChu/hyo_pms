create TYPE INSTANCE_ROW AS OBJECT (
   iterationInfo   VARCHAR2(180),
   masterID   NUMBER,
   sessionOwner   NUMBER,
   versionInfo   VARCHAR2(180),
   versionOID   OID_OBJECT)
/

