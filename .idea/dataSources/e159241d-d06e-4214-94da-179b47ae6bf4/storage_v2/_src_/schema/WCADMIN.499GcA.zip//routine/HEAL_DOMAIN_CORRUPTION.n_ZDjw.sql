create procedure heal_domain_corruption (v_lasthealedtimestamp IN date, v_error OUT varchar2) is

   v_healable varchar2(100);
   v_max_run_cnt number;
   v_rows_updated number;
   v_sqlstmt varchar2(8000);
   type refcur is ref cursor;
   c_ALIGNMENT_EPMDOCUMENT refcur;

 TYPE fetch_array_document IS TABLE OF MIG$DOMAIN%ROWTYPE;
 s_array_document fetch_array_document;

begin
  dbms_output.put_line('============================================================');
  dbms_output.put_line('Heal Alignment corruption....heal_domain_corruption_5.sql');
  dbms_output.put_line(to_char(sysdate,'MM/DD/YYYY HH24:MI:SS'));
  dbms_output.put_line('============================================================');

  dbms_output.put_line('------------Healing EPMDocument---------------');
  dbms_output.put_line('update domain of object to be domain of parent folder where mismatched on latest and not in personal cabinet (consistent with inherited domain behavior)');

  v_sqlstmt := 'select distinct EPMDocument.idA2A2, SubFolder.idA3domainRef idA3domainRef, EPMDocument.idA3domainRef old_idA3domainRef, sysdate
    		, decode(pivst.status,null,''Object not Migrated'',decode(pivst.status,1,decode(EPMDocument.STATECHECKOUTINFO,''c/i'',''Healable'',''Object not checked in''),''Object was not migrated successfully'')) isHealable
  		, :max_run_cnt  runcount
  		from EPMDocument, Cabinet, SubFolder, pivtowcstatus pivst
  		where
		    EPMDocument.idA3A2folderingInfo = Cabinet.idA2A2
		    and Cabinet.personalCabinet = 0
		    and EPMDocument.idA3B2folderingInfo = SubFolder.idA2A2
		    and EPMDocument.idA3domainRef <> SubFolder.idA3domainRef
		    and EPMDocument.latestiterationInfo = 1
		    and EPMDocument.inheritedDomain = 1
		    and pivst.epmdocumentid(+) = EPMDocument.idA2A2
		    and pivst.documenttype = 0
		    and EPMDocument.classnamekeycontainerreferen in (''wt.inf.library.WTLibrary'',''wt.pdmlink.PDMLinkProduct'')';

  select nvl(max(runcount),0) into  v_max_run_cnt from MIG$DOMAIN;
  v_max_run_cnt := v_max_run_cnt+1;
  v_error :='No Errors';

  if (v_lasthealedtimestamp is not null) then
    v_sqlstmt := v_sqlstmt||' and loadtime>'''||v_lasthealedtimestamp||'''';
  end if;

  dbms_output.put_line(to_char(sysdate,'MM/DD/YYYY HH24:MI:SS'));

  OPEN c_ALIGNMENT_EPMDOCUMENT for v_sqlstmt using v_max_run_cnt;
    LOOP
      FETCH c_ALIGNMENT_EPMDOCUMENT BULK COLLECT INTO s_array_document LIMIT 10000;
      FORALL i IN 1..s_array_document.COUNT
       insert into MIG$DOMAIN values s_array_document(i);
      EXIT WHEN c_ALIGNMENT_EPMDOCUMENT%NOTFOUND;
    END LOOP;
  CLOSE c_ALIGNMENT_EPMDOCUMENT;

  dbms_output.put_line(to_char(sysdate,'MM/DD/YYYY HH24:MI:SS'));

  update EPMDocument set idA3domainRef = ( select idA3domainRef from MIG$DOMAIN where EPMDocument.idA2A2 = MIG$DOMAIN.idA2A2 and runcount=v_max_run_cnt and healable = 'Healable')
  where EPMDocument.ida2a2 in ( select ida2a2 from MIG$DOMAIN where runcount=v_max_run_cnt and healable = 'Healable');
  v_rows_updated:=sql%rowcount;
  dbms_output.put_line('EPMDocument Rows Updated='||v_rows_updated);
  dbms_output.put_line(to_char(sysdate,'MM/DD/YYYY HH24:MI:SS'));

  commit;

  dbms_output.put_line(to_char(sysdate,'MM/DD/YYYY HH24:MI:SS'));

  exception when others then
     	Rollback;
     	v_error := DBMS_UTILITY.format_error_stack;
	dbms_output.put_line('FILENAME$NonHealable_domain_corruption_5.html$');

end;
/

