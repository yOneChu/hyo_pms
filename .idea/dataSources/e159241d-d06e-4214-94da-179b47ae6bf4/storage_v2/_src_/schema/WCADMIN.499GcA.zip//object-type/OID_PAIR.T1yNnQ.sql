create TYPE OID_PAIR AS OBJECT (
className1 VARCHAR2(200),
id1        NUMBER,
className2 VARCHAR2(200),
id2        NUMBER)
/

