create PACKAGE BODY EPMWorkspacePK IS
FUNCTION getNextId(lastUsed IN OUT NUMBER, maxAvailable IN OUT NUMBER) RETURN NUMBER IS
nextId NUMBER := 0;
BEGIN
IF lastUsed = maxAvailable THEN
select id_sequence.NEXTVAL into nextId from dual;
maxAvailable := nextId + 99;
ELSE
nextId := lastUsed + 1;
END IF;
lastUsed := nextId;
RETURN nextId;
END getNextId;
FUNCTION CopyEPMAsStoredConfig ( original_object_list IN OID_OBJECT_LIST, copied_object_list IN OID_OBJECT_LIST, replace IN NUMBER )
RETURN OID_OBJECT_LIST IS
CURSOR AsStoredMemberCursor (asStoredConfigId NUMBER) IS
SELECT * FROM EPMASSTOREDMEMBER WHERE ida3a5 = asStoredConfigId;
v_ret_config_list OID_OBJECT_LIST;
v_copied_config_oid NUMBER := 0;
v_current_time DATE;
v_max_available_id NUMBER := 0;
v_oid  NUMBER :=0;
v_index NUMBER := 0;
v_config_row EPMASSTOREDCONFIG%ROWTYPE;
v_oid_string VARCHAR2(30000);
TYPE id_lookup IS TABLE OF NUMBER INDEX BY VARCHAR2(200);
v_copied_config_lookup id_lookup;
v_original_object_lookup id_lookup;
v_config_from_lookup NUMBER;
v_config_already_copied BOOLEAN := FALSE;
v_original_config_found BOOLEAN := FALSE;
BEGIN
-- dbms_session.set_sql_trace(TRUE);
SELECT sysdate INTO v_current_time FROM DUAL;
FOR a IN original_object_list.FIRST..original_object_list.LAST
LOOP
v_original_object_lookup ( to_char(original_object_list(a).id) ) := a;
END LOOP;
FOR a IN original_object_list.FIRST..original_object_list.LAST
LOOP
BEGIN
SELECT a.* INTO v_config_row
FROM EPMASSTOREDCONFIG a, EPMASSTOREDMEMBER b
WHERE b.ida3b5 = original_object_list(a).id AND b.owner = 1 AND a.ida2a2 = b.ida3a5;
v_original_config_found := TRUE;
EXCEPTION WHEN no_data_found THEN
-- no as stored config for this object.
v_original_config_found := FALSE;
END;
IF v_original_config_found = TRUE THEN
BEGIN
v_config_from_lookup := v_copied_config_lookup( to_char(v_config_row.ida2a2) );
v_config_already_copied := TRUE;
EXCEPTION WHEN no_data_found THEN
v_config_already_copied := FALSE;
END;
IF v_config_already_copied = FALSE THEN
v_copied_config_lookup( to_char(v_config_row.ida2a2) ) := v_config_row.ida2a2;
v_oid := getNextId(v_oid, v_max_available_id);
/* Insert the new row for this config. */
INSERT INTO EPMASSTOREDCONFIG ( CONFIGURATIONTYPE, DIRTY, DATELOCK,
CLASSNAMEKEYA2LOCK, IDA3A2LOCK, NOTELOCK,
CREATESTAMPA2, MARKFORDELETEA2, MODIFYSTAMPA2,
CLASSNAMEA2A2, IDA2A2, UPDATECOUNTA2, UPDATESTAMPA2 )
VALUES ( v_config_row.CONFIGURATIONTYPE, v_config_row.DIRTY, v_config_row.DATELOCK,
v_config_row.CLASSNAMEKEYA2LOCK, v_config_row.IDA3A2LOCK,v_config_row.NOTELOCK,
v_current_time, v_config_row.MARKFORDELETEA2, v_current_time,
v_config_row.CLASSNAMEA2A2, v_oid, 1, v_current_time );
IF v_ret_config_list IS NULL THEN
v_ret_config_list := OID_OBJECT_LIST();
END IF;
v_ret_config_list.EXTEND;
v_ret_config_list(v_ret_config_list.LAST) := OID_OBJECT(v_config_row.CLASSNAMEA2A2,v_oid);
v_copied_config_oid := v_oid;
/* Get all members of original config and copy as members for new config */
FOR v_member_row IN AsStoredMemberCursor(v_config_row.ida2a2)
LOOP
v_index := 0;
/* Check if the baselineable in row being copied is present in original_object_list */
BEGIN
v_index := v_original_object_lookup( to_char(v_member_row.ida3b5) );
EXCEPTION WHEN no_data_found THEN
v_index := 0;
END;
IF (v_index = 0 OR replace = 0) THEN
/* Insert this as member of copied config */
v_oid := getNextId(v_oid, v_max_available_id);
INSERT INTO EPMASSTOREDMEMBER ( OWNER, CLASSNAMEKEYROLEAOBJECTREF, IDA3A5,
CLASSNAMEKEYROLEBOBJECTREF, IDA3B5, SUBSTITUTE,
CREATESTAMPA2, MARKFORDELETEA2, MODIFYSTAMPA2,
CLASSNAMEA2A2, IDA2A2, UPDATECOUNTA2, UPDATESTAMPA2 )
VALUES (0, v_member_row.CLASSNAMEKEYROLEAOBJECTREF, v_copied_config_oid,
v_member_row.CLASSNAMEKEYROLEBOBJECTREF, v_member_row.IDA3B5, v_member_row.SUBSTITUTE,
v_current_time, v_member_row.MARKFORDELETEA2, v_current_time,
v_member_row.CLASSNAMEA2A2, v_oid, 1, v_current_time);
END IF;
IF  v_index != 0  THEN
/* Insert in copied config as owner / member depending upon whether the original is owner / member */
v_oid := getNextId(v_oid, v_max_available_id);
INSERT INTO EPMASSTOREDMEMBER ( OWNER, CLASSNAMEKEYROLEAOBJECTREF, IDA3A5,
CLASSNAMEKEYROLEBOBJECTREF, IDA3B5, SUBSTITUTE,
CREATESTAMPA2, MARKFORDELETEA2, MODIFYSTAMPA2,
CLASSNAMEA2A2, IDA2A2, UPDATECOUNTA2, UPDATESTAMPA2 )
VALUES (v_member_row.OWNER, v_member_row.CLASSNAMEKEYROLEAOBJECTREF, v_copied_config_oid,
copied_object_list(v_index).className, copied_object_list(v_index).id, 0,
v_current_time, 0, v_current_time,
v_member_row.CLASSNAMEA2A2, v_oid, 1, v_current_time);
IF v_member_row.OWNER = 1 THEN
UPDATE EPMDOCUMENT
SET classnamekeyC10 = v_member_row.CLASSNAMEKEYROLEAOBJECTREF, idA3C10 = v_copied_config_oid, UPDATECOUNTA2= UPDATECOUNTA2 + 1
WHERE idA2A2 = copied_object_list(v_index).id;
END IF;
END IF;
END LOOP;
END IF;
END IF;
END LOOP;
-- dbms_session.set_sql_trace(FALSE);
RETURN v_ret_config_list;
END CopyEPMAsStoredConfig;
FUNCTION insertAsStoredMembers (baseline IN OID_OBJECT, as_stored_oid_list IN EPM_AS_STORED_MEMBER_TABLE) RETURN NUMBER IS
insert_error EXCEPTION;
current_time DATE;
link_id NUMBER := 0;
max_available NUMBER := 0;
num_recs NUMBER;
link_classname_string CONSTANT VARCHAR(200) := 'wt.epm.workspaces.EPMAsStoredMember';
total_rows NUMBER;
BEGIN
--DBMS_OUTPUT.PUT_LINE( 'From stored procedure: InsertAsStoredMembers\n');
SELECT sysdate INTO current_time FROM DUAL;
-- Insert new values with new sequence values.
num_recs := as_stored_oid_list.COUNT;
FOR j in 1 .. num_recs
LOOP
--DBMS_OUTPUT.PUT_LINE(j);
link_id := getNextId(link_id, max_available);
INSERT INTO EPMAsStoredMember (classnamekeyroleAObjectRef, idA3A5, classnamekeyroleBObjectRef,
idA3B5, owner, createStampA2, modifyStampA2, classnameA2A2,
idA2A2, updateCountA2,  updateStampA2, markForDeleteA2)
VALUES(baseline.className, baseline.id, as_stored_oid_list(j).className,
as_stored_oid_list(j).id, as_stored_oid_list(j).owner,
current_time, current_time,
link_classname_string, link_id, 1, current_time, 0);
total_rows := total_rows + SQL%ROWCOUNT;
END LOOP;
if total_rows != num_recs then
raise insert_error;
end if;
RETURN num_recs;
EXCEPTION  -- exception handlers begin
WHEN insert_error THEN  -- handles failed insert
RETURN -1;
WHEN OTHERS THEN        -- handles all other errors
RETURN -1;
END insertAsStoredMembers;
FUNCTION replaceAsStoredMembers (origlink_oid_list IN OID_OBJECT_LIST, replacement_oid_list IN OID_OBJECT_LIST) RETURN NUMBER IS
insert_error EXCEPTION;
current_time DATE;
num_recs NUMBER;
total_rows NUMBER;
BEGIN
--DBMS_OUTPUT.PUT_LINE( 'From stored procedure: replaceAsStoredMembers\n');
SELECT sysdate INTO current_time FROM DUAL;
num_recs := origlink_oid_list.LAST;
total_rows := 0;
FOR i in 1 .. num_recs
LOOP
/* Replace Baselineable (Role B) of BaselineMemberlink with different iteration.*/
UPDATE EPMAsStoredMember
SET idA3B5 = replacement_oid_list(i).id,
classnamekeyroleBObjectRef = replacement_oid_list(i).classname,
owner = 0,
substitute = 1,
modifyStampA2 = current_time,
updateCountA2 = NVL(UPDATECOUNTA2 + 1, 1),
updateStampA2 = current_time
WHERE idA2A2 = origlink_oid_list(i).id;
total_rows := total_rows + SQL%ROWCOUNT;
END LOOP;
if total_rows != num_recs then
raise insert_error;
end if;
RETURN num_recs;
EXCEPTION  -- exception handlers begin
WHEN insert_error THEN  -- handles failed insert
RETURN -1;
WHEN OTHERS THEN        -- handles all other errors
RETURN -1;
END replaceAsStoredMembers;
FUNCTION removeAsStoredMembers (baselineMemberOids IN TABLE_OF_NUMBER) RETURN NUMBER IS
delete_error EXCEPTION;
current_time DATE;
num_recs NUMBER;
total_rows NUMBER;
BEGIN
--DBMS_OUTPUT.PUT_LINE( 'From stored procedure: removeAsStoredMembers\n');
num_recs := baselineMemberOids.LAST;
total_rows := 0;
FORALL i in 1 .. num_recs
DELETE FROM EPMAsStoredMember
WHERE idA2A2 = baselineMemberOids(i);
total_rows := 0;
FOR i IN baselineMemberOids.FIRST .. baselineMemberOids.LAST
LOOP
total_rows := total_rows + SQL%BULK_ROWCOUNT(i);
END LOOP;
if total_rows != num_recs then
raise delete_error;
end if;
RETURN num_recs;
EXCEPTION  -- exception handlers begin
WHEN delete_error THEN  -- handles failed insert
RETURN -1;
WHEN OTHERS THEN        -- handles all other errors
RETURN -1;
END removeAsStoredMembers;
-- Temporary function till delete Where with cascade (for EPMUpdateCounter) is working
FUNCTION deleteUpdateCounters (updateCounterOids IN TABLE_OF_NUMBER) RETURN NUMBER IS
BEGIN
--DBMS_OUTPUT.PUT_LINE( 'From stored procedure: deleteUpdateCounters \n');
FORALL i in 1 .. updateCounterOids.LAST
DELETE FROM EPMUpdateCounter
WHERE idA2A2 = updateCounterOids(i);
RETURN 1;
EXCEPTION
WHEN OTHERS THEN
RETURN -1;
END deleteUpdateCounters;
END EPMWorkspacePK;
/

