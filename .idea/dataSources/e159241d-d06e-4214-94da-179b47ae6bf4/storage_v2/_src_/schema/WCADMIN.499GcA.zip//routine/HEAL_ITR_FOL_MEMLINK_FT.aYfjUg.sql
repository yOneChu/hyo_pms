create procedure heal_itr_fol_memlink_ft (v_lasthealedtimestamp IN date, v_error OUT varchar2) is

   v_healable varchar2(100);
   v_max_run_cnt number;
   v_rows_updated number;
   v_sqlstmt varchar2(8000);
   type refcur is ref cursor;
   c_hifmlft refcur;

 TYPE fetch_array_master IS TABLE OF MIG$folmlft%ROWTYPE;
 s_array_fts fetch_array_master;

begin

  dbms_output.put_line('============================================================');
  dbms_output.put_line('Heal Alignment corruption....heal_iterated_folder_memberlink_ft-9.sql');
  dbms_output.put_line(to_char(sysdate,'MM/DD/YYYY HH24:MI:SS'));
  dbms_output.put_line('============================================================');

  dbms_output.put_line('Align iterated folder member link with parent folder (or cabinet) of the latest iteration of each version if they do not match.');

  dbms_output.put_line(to_char(sysdate,'MM/DD/YYYY HH24:MI:SS'));

  v_sqlstmt := 'select distinct fl.ida2a2 fl_ida2a2,fl.BRANCHIDA3B5 fl_branchida3b5, ft.IDA2A2 ft_ida2a2, ft.IDA3B2FOLDERINGINFO
		, decode (ft.ida3B2folderingInfo, 0, ft.classnamekeyA2folderinginfo, ft.classnamekeyB2folderinginfo) ft_classnamekeyroleAobjectref
        	,fl.CLASSNAMEKEYROLEAOBJECTREF , fl.CLASSNAMEA2A2
			, decode (ft.ida3B2folderingInfo, 0, ft.ida3A2folderingInfo, ft.ida3B2folderingInfo) ft_ida3A5
        	,fl.IDA3A5
			   , sysdate
			   ,decode(lovs.status,null,''Object not Migrated'',
				decode(lovs.status,1,
				    decode(ft.STATECHECKOUTINFO,''c/i'',''Healable'',''Object not checked in''),''Object was not migrated successfully'')) isHealable
		   , :max_run_cnt  runcount
		from    epmsepfamilytable ft, iterfoldermemberlink fl, lovtowcstatus lovs
		where   ft.branchiditerationinfo = fl.branchIda3B5
		  and   ft.latestiterationinfo = 1
		  and   ft.statecheckoutinfo <> ''wrk''  -- ignore working copies since only an instance may be checked out
		  and   (   ( ft.ida3B2folderingInfo <> 0 and ft.ida3B2folderingInfo <> fl.ida3A5 )
			or ( ft.ida3B2folderingInfo = 0  and ft.ida3A2folderingInfo <> fl.ida3A5 )
			)
		  and lovs.EPMSEPFAMILYTABLEID(+)=ft.IDA2A2
		  and ft.classnamekeycontainerreferen in (''wt.inf.library.WTLibrary'',''wt.pdmlink.PDMLinkProduct'')';


  select nvl(max(runcount),0) into  v_max_run_cnt from MIG$FOLMLFT;
  v_max_run_cnt := v_max_run_cnt+1;
  v_error :='No Errors';

  if (v_lasthealedtimestamp is not null) then
    v_sqlstmt := v_sqlstmt||' and loadtime>'''||v_lasthealedtimestamp||'''';
  end if;

  dbms_output.put_line(to_char(sysdate,'MM/DD/YYYY HH24:MI:SS'));

  OPEN c_hifmlft for v_sqlstmt using v_max_run_cnt;
  LOOP
    FETCH c_hifmlft BULK COLLECT INTO s_array_fts LIMIT 10000;
    FORALL i IN 1..s_array_fts.COUNT
     insert into MIG$folmlft values s_array_fts(i);
    EXIT WHEN c_hifmlft%NOTFOUND;
  END LOOP;
  CLOSE c_hifmlft;

  dbms_output.put_line(to_char(sysdate,'MM/DD/YYYY HH24:MI:SS'));

  update iterfoldermemberlink l
	set ( classnamekeyroleAobjectref, ida3A5 ) =
		    ( select decode (ft.ida3B2folderingInfo, 0, ft.classnamekeyA2folderinginfo, ft.classnamekeyB2folderinginfo)
			   , decode (ft.ida3B2folderingInfo, 0, ft.ida3A2folderingInfo, ft.ida3B2folderingInfo)
		      from epmsepfamilytable ft
		      where ft.branchiditerationinfo = l.branchIda3B5
			and ft.latestiterationinfo = 1
		    )
	where l.ida2a2 in (
		  select fl_ida2a2 from mig$folmlft where healable='Healable' and runcount=v_max_run_cnt
		  );
  v_rows_updated:=sql%rowcount;
  dbms_output.put_line('iterfoldermemberlink Rows Updated='||v_rows_updated);
  dbms_output.put_line(to_char(sysdate,'MM/DD/YYYY HH24:MI:SS'));

  commit;

  dbms_output.put_line(to_char(sysdate,'MM/DD/YYYY HH24:MI:SS'));

  exception when others then
     	Rollback;
     	v_error := DBMS_UTILITY.format_error_stack;
	dbms_output.put_line('FILENAME$NonHealable_iterated_folder_memberlink_ft-9.html$');

end;
/

