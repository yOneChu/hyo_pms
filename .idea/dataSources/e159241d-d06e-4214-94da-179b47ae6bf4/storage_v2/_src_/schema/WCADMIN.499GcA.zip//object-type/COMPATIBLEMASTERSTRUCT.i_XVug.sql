create TYPE CompatibleMasterStruct AS OBJECT (
   compatibleId   NUMBER,
   completeId   NUMBER,
   contentId   NUMBER,
   masterId   NUMBER)
/

