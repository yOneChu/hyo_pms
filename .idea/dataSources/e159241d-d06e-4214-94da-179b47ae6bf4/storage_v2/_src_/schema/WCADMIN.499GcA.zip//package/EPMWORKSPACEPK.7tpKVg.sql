create PACKAGE EPMWorkspacePK IS
--  This function copies forward EPMAsStoredConfig for each of the given originals to the corresponding copy.
--  If one or more originals share the same EPMAsStoredConfig then the corresponding copies also share same copied EPMAsStoredConfig.
--
--  Input parameters:
--    original_object_list : List of original EPMDocuments whose EPMAsStoredConfigs are to be copied
--    copied_object_list   : List of copied EPMDocuments to which EPMAsStoredConfig are to be copied.
--                           The original and its corresponding copy should be at the same index in the respective lists.
--    replace              : Whether or not to keep the originals  in the copied as-stored config.
--                           If 1 then if any of the original appears in the as-stored config being copied
--                           then it is replaced by the corresponding target / copy in the copied as-stored config. ( e.g. revise operation)
--                           If 0 then the original is copied as member and the target / copy (as owner or member
--                           depending upon how the original was linked) is added in the copied as-stored (e.g. copy operation)
FUNCTION CopyEPMAsStoredConfig ( original_object_list IN OID_OBJECT_LIST, copied_object_list IN OID_OBJECT_LIST, replace IN NUMBER ) RETURN OID_OBJECT_LIST;
-- insertAsStoredMembers adds EPMAsStoredMembers to the provided baseline (EPMAsStoredConfig)
-- Input parameters:
--   baseline               : classname and id of the EPMAsStoredConfig
--   as_stored_oid_list     : classname and id of Baselineables to be added along with owner flag
-- Return the number of links inserted
FUNCTION insertAsStoredMembers(baseline OID_OBJECT, as_stored_oid_list EPM_AS_STORED_MEMBER_TABLE) RETURN NUMBER;
-- replaceAsStoredMembers replaces an existing Baselineable on a link with a different Baselineable.
-- Owner flag is automatically set to 0 and substitute flag is set to 1.  IS THIS CORRECT?
-- Input parameters:
--   origlink_oid_list      : classname and id of links to modify
--   replacement_oid_list   : Baselineables to use as replacements
-- Returns total number of links modified
FUNCTION replaceAsStoredMembers (origlink_oid_list IN OID_OBJECT_LIST, replacement_oid_list IN OID_OBJECT_LIST)  RETURN NUMBER;
-- removeAsStoredMembers removes the given links from the as-stored config
-- Input parameters:
--   baselineMemberOids     : ids of links to remove
-- Returns total number of links removed
FUNCTION removeAsStoredMembers (baselineMemberOids IN TABLE_OF_NUMBER) RETURN NUMBER;
-- Temporary function - Remove when Delete-Where (for EPMUpdateCounter) is working
--
FUNCTION deleteUpdateCounters (updateCounterOids IN TABLE_OF_NUMBER) RETURN NUMBER;
END EPMWorkspacePK;
/

