create TYPE EPM_SUPPORTING_INFO AS OBJECT (
autoringApplication     VARCHAR2(200),
description         VARCHAR2(200),
holderClassName         VARCHAR2(200),
holderClassId           NUMBER,
markForDelete           NUMBER,
name                VARCHAR2(200),
ownerApplication        VARCHAR2(200),
toModifyId          NUMBER )
/

