create TYPE ROW_OBJECT AS OBJECT (
   id   NUMBER,
   tableName   VARCHAR2(90))
/

