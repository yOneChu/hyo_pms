create TYPE LINK_N_MASTER AS OBJECT (
roleAClassName  VARCHAR2(200),
roleAId         NUMBER,
roleBClassName  VARCHAR2(200),
roleBId         NUMBER,
className       VARCHAR2(200),
id              NUMBER,
masterClassName VARCHAR2(200),
masterId        NUMBER)
/

