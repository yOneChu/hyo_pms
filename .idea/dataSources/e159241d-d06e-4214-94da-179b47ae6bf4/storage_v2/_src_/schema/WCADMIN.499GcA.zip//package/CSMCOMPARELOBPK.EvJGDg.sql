create PACKAGE CSMCompareLobPK IS
FUNCTION getMatchingLobIds(p_id IN NUMBER, p_hid IN VARCHAR2) RETURN NUMBER;
END CSMCompareLobPK;
/

