create Package Body CSMCompareLobPK IS
FUNCTION getMatchingLobIds(p_id IN NUMBER, p_hid IN VARCHAR2) RETURN NUMBER IS
CURSOR C_Single(v_theAttributeOID NUMBER) IS
SELECT a.ida2a2, TheValueConstraint
FROM   CSMSingleDefConstraint a, ClassificationNode b
WHERE  a.ida3a5 = b.ida2a2
AND    a.ida3a4 = v_theAttributeOID
AND    b.hierarchyId LIKE p_hid || '%';
CURSOR C_Container IS
SELECT a.ida2a2, TheValueConstraint
FROM   CSMContainerConstraint a, ClassificationNode b
WHERE  b.ida2a2 = a.ida3a5
AND    b.hierarchyId LIKE p_hid || '%';
CSMContainerConstraint_blob BLOB;
CSMSingleDefConstraint_blob BLOB;
v_CSMContainerConstraint_blob BLOB;
v_CSMSingleDefConstraint_blob BLOB;
CSMSingleDefConstraint_id  NUMBER;
CSMContainerConstraint_id  NUMBER;
attributeDefFK NUMBER;
retval     INTEGER;
v_count    INTEGER := 0;
MaxLobSize INTEGER := 4294967295;
BEGIN
BEGIN
SELECT TheValueConstraint
INTO   v_CSMContainerConstraint_blob
FROM   CSMContainerConstraint
WHERE  ida2a2 = p_id;
BEGIN
OPEN C_Container;
LOOP
FETCH C_Container INTO CSMContainerConstraint_id, CSMContainerConstraint_blob;
EXIT WHEN C_Container%NOTFOUND;
retval := DBMS_LOB.COMPARE(CSMContainerConstraint_blob, v_CSMContainerConstraint_blob, MaxLobSize,1,1);
IF retval = 0 THEN
BEGIN
DELETE FROM CSMContainerConstraint where ida2a2 = CSMContainerConstraint_id;
END;
v_count := v_count + 1;
END IF;
END LOOP;
return(v_count);
END;
EXCEPTION
WHEN NO_DATA_FOUND THEN
BEGIN
SELECT TheValueConstraint, ida3a4
INTO   v_CSMSingleDefConstraint_blob, attributeDefFK
FROM   CSMSingleDefConstraint
WHERE  ida2a2 = p_id;
EXCEPTION
WHEN NO_DATA_FOUND THEN
NULL;
END;
BEGIN
OPEN C_Single(attributeDefFK);
LOOP
FETCH C_Single INTO CSMSingleDefConstraint_id, CSMSingleDefConstraint_blob;
EXIT WHEN C_Single%NOTFOUND;
retval := DBMS_LOB.COMPARE(CSMSingleDefConstraint_blob, v_CSMSingleDefConstraint_blob, MaxLobSize,1,1);
IF retval = 0 THEN
BEGIN
DELETE FROM CSMSingleDefConstraint where ida2a2 = CSMSingleDefConstraint_id;
END;
v_count := v_count + 1;
END IF;
END LOOP;
return(v_count);
END;
END;
END getMatchingLobIds;
END CSMCompareLobPK;
/

