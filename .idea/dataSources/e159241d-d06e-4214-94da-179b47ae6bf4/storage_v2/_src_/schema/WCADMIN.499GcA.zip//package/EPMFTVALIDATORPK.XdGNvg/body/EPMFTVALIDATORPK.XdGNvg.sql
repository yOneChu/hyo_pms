create PACKAGE BODY EPMFTValidatorPK IS
FTCELL_TABLES TABLE_OF_VARCHAR2_200 := TABLE_OF_VARCHAR2_200 ( 'EPMFamilyTableCell', 'EPMFamilyTableCellDep' );
FTCOLUMN_TABLES TABLE_OF_VARCHAR2_200 := TABLE_OF_VARCHAR2_200 ( 'EPMFamilyTableAttribute', 'EPMFamilyTableParameter', 'EPMFamilyTableFeature' , 'EPMFamilyTableMember', 'EPMFamilyTableReference' );
USE_COUNT_IN_CARDINALITY BOOLEAN := TRUE;
TYPE ID_LOOKUP IS TABLE OF NUMBER INDEX BY BINARY_INTEGER;
v_id_lookup ID_LOOKUP;
FUNCTION getWhereClause(i_table IN TABLE_OF_NUMBER, i_index IN NUMBER)
RETURN VARCHAR2 IS
v_clause VARCHAR2(200);
v_use_count NUMBER;
BEGIN
--       IF i_table.count = 1  THEN
--            v_clause := ' = ' || i_table(1);
--       ELSE
IF USE_COUNT_IN_CARDINALITY THEN
IF i_table.count < 10 THEN
v_use_count := i_table.count;
ELSIF i_table.count < 100 THEN
v_use_count := round ((i_table.count / 10)) * 10;
ELSIF i_table.count < 1000 THEN
v_use_count := round ((i_table.count / 100)) * 100;
ELSIF i_table.count < 10000 THEN
v_use_count := round ((i_table.count / 1000)) * 1000;
ELSE
v_use_count := round ((i_table.count / 10000)) * 10000;
END IF;
v_clause := ' IN ( SELECT /*+ cardinality ( Z ' || v_use_count || ' ) */ Z.column_value from table(cast(:'|| i_index || ' as table_of_number)) Z where (rownum > 0) )';
ELSE
v_clause := ' IN ( SELECT /*+ cardinality ( Z 1 ) */ Z.column_value from table(cast(:'|| i_index || ' as table_of_number)) Z )';
END IF;
--       END IF;
RETURN v_clause;
END getWhereClause;
FUNCTION getClassName(i_tabname IN VARCHAR2) RETURN VARCHAR2
IS
i_className VARCHAR2(100);
BEGIN
i_className := '-1';
IF UPPER(i_tabName) = 'EPMDOCUMENT' THEN
i_className := 'wt.epm.EPMDocument';
ELSIF  UPPER(i_tabName) = 'EPMDOCUMENTMASTER' THEN
i_className := 'wt.epm.EPMDocumentMaster';
ELSIF  UPPER(i_tabName) = 'EPMCONTAINEDIN' THEN
i_className := 'wt.epm.structure.EPMContainedIn';
ELSIF  UPPER(i_tabName) = 'EPMVARIANTLINK' THEN
i_className := 'wt.epm.structure.EPMVariantLink';
ELSIF  UPPER(i_tabName) = 'EPMSEPFAMILYTABLE' THEN
i_className := 'wt.epm.familytable.EPMSepFamilyTable';
ELSIF  UPPER(i_tabName) = 'EPMSEPFAMILYTABLEMASTER' THEN
i_className := 'wt.epm.familytable.EPMSepFamilyTableMaster';
ELSIF  UPPER(i_tabName) = 'EPMFEATUREVALUE' THEN
i_className := 'wt.epm.familytable.EPMFeatureValue';
ELSIF  UPPER(i_tabName) = 'EPMPARAMETERVALUE' THEN
i_className := 'wt.epm.familytable.EPMParameterValue';
ELSIF UPPER(i_tabName) = 'EPMFAMILYTABLECELL' THEN
i_className := 'wt.epm.familytable.EPMFamilyTableCell';
ELSIF UPPER(i_tabName) = 'EPMFAMILYTABLECELLDEP' THEN
i_className := 'wt.epm.familytable.EPMFamilyTableCellDependency';
ELSIF UPPER(i_tabName) = 'EPMFAMILYTABLEPARAMETER' THEN
i_className := 'wt.epm.familytable.EPMFamilyTableParameter';
ELSIF UPPER(i_tabName) = 'EPMFAMILYTABLEFEATURE' THEN
i_className := 'wt.epm.familytable.EPMFamilyTableFeature';
ELSIF UPPER(i_tabName) = 'EPMFAMILYTABLEMEMBER' THEN
i_className := 'wt.epm.familytable.EPMFamilyTableMember';
ELSIF UPPER(i_tabName) = 'EPMFAMILYTABLEATTRIBUTE' THEN
i_className := 'wt.epm.familytable.EPMFamilyTableAttribute';
ELSIF UPPER(i_tabName) = 'EPMFAMILYTABLEREFERENCE' THEN
i_className := 'wt.epm.familytable.EPMFamilyTableReference';
END IF;
return i_className;
END getClassName;
FUNCTION getTopGeneric(i_doc IN NUMBER)
RETURN NUMBER IS
v_sqltext       VARCHAR2(2000);
v_oid           TABLE_OF_NUMBER;
v_count         TABLE_OF_NUMBER;
v_ret_value     NUMBER;
BEGIN
--dbms_output.put_line('In generics ' || i_doc);
v_sqltext := 'SELECT B.IDA2A2, B.FAMILYTABLESTATUS FROM EPMVariantlink A, EPMDocument B, EPMContainedin C, EPMContainedin D WHERE A.IDA3A5 = :1 AND B.IDA3MASTERREFERENCE = A.IDA3B5 AND C.IDA3A5 = B.IDA2A2 and B.FAMILYTABLESTATUS <> 0 AND D.IDA3A5 = A.IDA3A5 AND D.IDA3B5 = C.IDA3B5';
EXECUTE IMMEDIATE v_sqltext BULK COLLECT INTO v_oid, v_count USING i_doc;
-- ensure that i_doc has familystatus as 1 or 3, else we will get into this situation
if v_oid IS NULL OR v_oid.count = 0 then
return 1;
else
FOR j IN 1 .. v_oid.count LOOP
IF v_count(j) <> 2 THEN
--dbms_output.put_line('Processing ' || v_oid(j));
v_ret_value := getTopGeneric(v_oid(j));
if v_ret_value = 1 then
--dbms_output.put_line('Jumping generics ' || i_doc);
return 1;
end if;
END IF;
END LOOP;
end if;
--dbms_output.put_line('Out generics ' || i_doc);
return 0;
END getTopGeneric;
FUNCTION checkProjectDocument(i_oid IN NUMBER, i_container_oid IN NUMBER)
RETURN NUMBER IS
v_temp              NUMBER;
BEGIN
-- get all the family tables where the given document participates
SELECT count(*) INTO v_temp FROM EPMContainedIn A
WHERE A.IDA3A5 = i_oid
AND   exists ( select 'x' from EPMDocument B, EPMContainedIn C
where C.IDA3B5 = A.IDA3B5
and   C.IDA3A5 = B.IDA2A2
and   B.CLASSNAMEKEYCONTAINERREFEREN = 'wt.projmgmt.admin.Project2'
and   B.IDA3CONTAINERREFERENCE <> i_container_oid );
IF v_temp <> 0 THEN
RETURN 1;
END IF;
RETURN 0;
END checkProjectDocument;
FUNCTION checkColumnExists( i_oid IN NUMBER)
RETURN NUMBER IS
v_count TABLE_OF_NUMBER;
v_found NUMBER;
v_sqltext   VARCHAR2(2000);
BEGIN
v_found := 0;
FOR i IN 1 .. FTCELL_TABLES.COUNT LOOP
IF v_found = 0 THEN
v_sqltext := 'SELECT COUNT(*) FROM EPMContainedIn A, ' || FTCELL_TABLES(i) || ' B WHERE A.IDA3A5 = :1 AND   A.IDA2A2 = B.IDA3A3 AND   B.DEFINEDHERE = 1';
EXECUTE IMMEDIATE v_sqltext BULK COLLECT INTO v_count USING i_oid;
FOR j IN 1 .. v_count.count LOOP
IF v_count(j) <> 0 THEN
v_found := 1;
END IF;
END LOOP;
END IF;
END LOOP;
IF v_found = 1 THEN
RETURN 0;
ELSE
RETURN 1;
END IF;
END checkColumnExists;
FUNCTION checkColumnExistsForFT( i_oid IN NUMBER)
RETURN NUMBER IS
v_count TABLE_OF_NUMBER;
v_found NUMBER;
v_sqltext   VARCHAR2(2000);
BEGIN
v_found := 0;
FOR i IN 1 .. FTCELL_TABLES.COUNT LOOP
IF v_found = 0 THEN
v_sqltext := 'SELECT COUNT(*) FROM EPMContainedIn A, ' || FTCELL_TABLES(i) || ' B WHERE A.IDA3B5 = :1 AND   A.IDA2A2 = B.IDA3A3 AND   B.DEFINEDHERE = 1';
EXECUTE IMMEDIATE v_sqltext BULK COLLECT INTO v_count USING i_oid;
FOR j IN 1 .. v_count.count LOOP
IF v_count(j) <> 0 THEN
v_found := 1;
END IF;
END LOOP;
END IF;
END LOOP;
IF v_found = 1 THEN
RETURN 0;
ELSE
RETURN 1;
END IF;
END checkColumnExistsForFT;
FUNCTION checkCell(i_cell IN NUMBER, i_containedInLink IN NUMBER, i_column IN NUMBER)
RETURN NUMBER IS
v_sqltext   VARCHAR2(2000);
v_oid     TABLE_OF_NUMBER;
v_found     NUMBER;
BEGIN
-- check if the containedin link has been deleted
v_sqltext := 'SELECT IDA2A2 FROM EPMContainedIn WHERE IDA2A2 = :1';
EXECUTE IMMEDIATE v_sqltext BULK COLLECT INTO v_oid USING i_containedInLink;
-- if deleted no need of going further, return 0 as there in no error condition
IF v_oid.count = 0 THEN
RETURN 0;
END IF;
-- check if the column has been deleted
v_found := 0;
FOR i IN 1 .. FTCOLUMN_TABLES.COUNT LOOP
IF v_found = 0 THEN
v_sqltext := 'SELECT IDA2A2 FROM ' || FTCOLUMN_TABLES(i) ||' WHERE IDA2A2 = :1';
EXECUTE IMMEDIATE v_sqltext BULK COLLECT INTO v_oid USING i_column;
IF v_oid.count <> 0 THEN
v_found := 1;
END IF;
END IF;
END LOOP;
-- if deleted no need of going further, return 0 as there in no error condition
IF v_found = 0 THEN
RETURN 0;
END IF;
-- if contained in link as well as column exists, check if its being used by other cell
v_found := 0;
FOR i IN 1 .. FTCELL_TABLES.COUNT LOOP
IF v_found = 0 THEN
v_sqltext := 'SELECT IDA2A2 FROM ' || FTCELL_TABLES(i) ||' WHERE IDA2A2 <> :1 AND IDA3A3 = :2 AND IDA3B3 = :3';
EXECUTE IMMEDIATE v_sqltext BULK COLLECT INTO v_oid USING i_cell, i_containedInLink, i_column;
IF v_oid.count <> 0 THEN
v_found := 1;
END IF;
END IF;
END LOOP;
-- if there is no cell which uses the two, then return error.
IF v_found = 0 THEN
RETURN 1;
END IF;
RETURN 0;
END checkCell;
FUNCTION checkFTDocument(i_ftMaster IN NUMBER, i_doc IN NUMBER)
RETURN NUMBER IS
v_sqltext   VARCHAR2(2000);
v_oid       TABLE_OF_NUMBER;
v_found     NUMBER;
BEGIN
-- check if the document has been deleted
v_sqltext := 'SELECT IDA2A2 FROM EPMDocument WHERE IDA2A2 = :1';
EXECUTE IMMEDIATE v_sqltext BULK COLLECT INTO v_oid USING i_doc;
-- if deleted no need of going further, return 0 as there in no error condition
IF v_oid.count = 0 THEN
RETURN 0;
END IF;
-- if document exist, ensure that it is FT with the same master
v_sqltext := 'SELECT IDA2A2 FROM EPMContainedin A, EPMSepFamilyTable B WHERE A.IDA3A5 = :1 AND A.IDA3B5 = B.IDA2A2 AND B.IDA3MASTERREFERENCE = :2';
EXECUTE IMMEDIATE v_sqltext BULK COLLECT INTO v_oid USING i_doc, i_ftMaster;
IF v_oid.count = 0 THEN
RETURN 1;
END IF;
RETURN 0;
END checkFTDocument;
FUNCTION checkFTMaster(i_ftMaster IN NUMBER)
RETURN NUMBER IS
v_sqltext   VARCHAR2(2000);
v_oid       TABLE_OF_NUMBER;
v_found     NUMBER;
BEGIN
-- check if the master has been deleted
v_sqltext := 'SELECT IDA2A2 FROM EPMSepFamilyTableMaster WHERE IDA2A2 = :1';
EXECUTE IMMEDIATE v_sqltext BULK COLLECT INTO v_oid USING i_ftMaster;
-- if deleted no need of going further, return 0 as there in no error condition
IF v_oid.count = 0 THEN
RETURN 0;
END IF;
-- if master exist, ensure that it is FT with the same master
v_sqltext := 'SELECT IDA2A2 FROM EPMSepFamilyTable A WHERE A.IDA3MASTERREFERENCE = :1';
EXECUTE IMMEDIATE v_sqltext BULK COLLECT INTO v_oid USING i_ftMaster;
IF v_oid.count = 0 THEN
RETURN 1;
END IF;
RETURN 0;
END checkFTMaster;
FUNCTION  ValidateEPMDocuments (i_docList IN TABLE_OF_NUMBER,ftConfigData IN OUT FTVAL_CONFIG_TABLE) RETURN FT_REPORT_DATA
IS
v_sqltext VARCHAR2(2000);
v_oid            TABLE_OF_NUMBER;
v_ft_oid         TABLE_OF_NUMBER;
v_count          TABLE_OF_NUMBER;
v_standalone_oid TABLE_OF_NUMBER;
v_checkedout_oid TABLE_OF_NUMBER;
v_topgeneric_oid TABLE_OF_NUMBER;
v_nonNXTopgeneric_oid TABLE_OF_NUMBER;
v_instances_oid  TABLE_OF_NUMBER;
v_container_oid  TABLE_OF_NUMBER;
o_errList	     FT_STATUS_TABLE;
v_error          NUMBER;
v_hasProjects    NUMBER;
i_continue	     BOOLEAN;
v_doc_ft_pair LIST_OF_OID_PAIRS;
v_pdm_fts TABLE_OF_NUMBER;
v_reportData   FT_REPORT_DATA;
BEGIN
v_reportData := new FT_REPORT_DATA();
i_continue := FALSE;
-- ensure stand alone documents do not participate in any containedin link
v_sqltext := 'SELECT A.IDA2A2 FROM EPMDocument A WHERE A.IDA2A2 ' || getWhereClause( i_docList,1 ) || ' AND (A.FAMILYTABLESTATUS = 0 OR A.FAMILYTABLESTATUS IS NULL)';
EXECUTE IMMEDIATE v_sqltext BULK COLLECT INTO v_standalone_oid USING i_docList;
IF v_standalone_oid.COUNT > 0 THEN
o_errList := new FT_STATUS_TABLE();
FTValidator_Helper_PK.should_validate_error(20010, 'wt.epm.EPMDocument', ftConfigData , i_continue);
IF i_continue = TRUE THEN
v_sqltext := 'SELECT DISTINCT A.IDA3A5 FROM EPMContainedIn A WHERE A.IDA3A5 ' || getWhereClause( v_standalone_oid, 1);
EXECUTE IMMEDIATE v_sqltext BULK COLLECT INTO v_oid USING v_standalone_oid;
FOR i IN 1 .. v_oid.count LOOP
o_errList.extend();
o_errList(o_errList.LAST) := new FT_STATUS('wt.epm.EPMDocument', v_oid(i), 20010);
END LOOP;
FTValidator_Helper_PK.record_errors(20010, 'wt.epm.EPMDocument', ftConfigData, o_errList, v_reportData, i_continue);
IF NOT i_continue THEN
RETURN v_reportData;
END IF;
END IF;
o_errList := new FT_STATUS_TABLE();
FTValidator_Helper_PK.should_validate_error(20020, 'wt.epm.EPMDocument', ftConfigData , i_continue);
IF i_continue = TRUE THEN
-- ensure stand alone documents do not participate in variant link
v_sqltext := 'SELECT DISTINCT A.IDA3A5 FROM EPMVariantLink A WHERE A.IDA3A5 ' || getWhereClause( v_standalone_oid, 1);
EXECUTE IMMEDIATE v_sqltext BULK COLLECT INTO v_oid USING v_standalone_oid;
FOR i IN 1 .. v_oid.count LOOP
-- dbms_output.put_line ( 'OID of stand alone document participating in Variant link = ' || v_oid(i));
o_errList.extend();
o_errList(o_errList.LAST) := new FT_STATUS('wt.epm.EPMDocument', v_oid(i), 20020);
END LOOP;
FTValidator_Helper_PK.record_errors(20020, 'wt.epm.EPMDocument', ftConfigData, o_errList, v_reportData, i_continue);
IF NOT i_continue THEN
RETURN v_reportData;
END IF;
END IF;
o_errList := new FT_STATUS_TABLE();
FTValidator_Helper_PK.should_validate_error(20030, 'wt.epm.EPMDocument', ftConfigData , i_continue);
IF i_continue = TRUE THEN
-- ensure stand alone documents do not have EPMParamaterValue associated to it
v_sqltext := 'SELECT DISTINCT A.IDA3A4 FROM EPMParameterValue A WHERE A.IDA3A4 ' || getWhereClause( v_standalone_oid, 1);
EXECUTE IMMEDIATE v_sqltext BULK COLLECT INTO v_oid USING v_standalone_oid;
FOR i IN 1 .. v_oid.count LOOP
-- dbms_output.put_line ( 'OID of stand alone document having EPMParamaterValue associated = ' || v_oid(i));
o_errList.extend();
o_errList(o_errList.LAST) := new FT_STATUS('wt.epm.EPMDocument', v_oid(i), 20030);
END LOOP;
FTValidator_Helper_PK.record_errors(20030, 'wt.epm.EPMDocument', ftConfigData, o_errList, v_reportData, i_continue);
IF NOT i_continue THEN
RETURN v_reportData;
END IF;
END IF;
o_errList := new FT_STATUS_TABLE();
FTValidator_Helper_PK.should_validate_error(20040, 'wt.epm.EPMDocument', ftConfigData , i_continue);
IF i_continue = TRUE THEN
-- ensure stand alone documents do not have EPMFeatureValue associated to it
v_sqltext := 'SELECT DISTINCT A.IDA3A4 FROM EPMFeatureValue A WHERE A.IDA3A4 ' || getWhereClause( v_standalone_oid, 1);
EXECUTE IMMEDIATE v_sqltext BULK COLLECT INTO v_oid USING v_standalone_oid;
FOR i IN 1 .. v_oid.count LOOP
-- dbms_output.put_line ( 'OID of stand alone document having EPMFeatureValue associated = ' || v_oid(i));
o_errList.extend();
o_errList(o_errList.LAST) := new FT_STATUS('wt.epm.EPMDocument', v_oid(i), 20040);
END LOOP;
FTValidator_Helper_PK.record_errors(20040, 'wt.epm.EPMDocument', ftConfigData, o_errList, v_reportData, i_continue);
IF NOT i_continue THEN
RETURN v_reportData;
END IF;
END IF;
END IF;
-- the following tests are for all the family table documents
-- get all ft docs
v_sqltext := 'SELECT DISTINCT Z1.COLUMN_VALUE FROM TABLE (cast(:1 as table_of_number)) Z1 MINUS SELECT DISTINCT Z2.COLUMN_VALUE FROM TABLE (cast(:2 as table_of_number)) Z2';
EXECUTE IMMEDIATE v_sqltext BULK COLLECT INTO v_ft_oid USING i_docList, v_standalone_oid;
IF v_ft_oid.COUNT > 0 THEN
o_errList := new FT_STATUS_TABLE();
FTValidator_Helper_PK.should_validate_error(20060, 'wt.epm.EPMDocument', ftConfigData , i_continue);
IF i_continue = TRUE THEN
-- ensure the documents participates in contained in link
SELECT Z1.COLUMN_VALUE FT_OID BULK COLLECT INTO v_oid FROM TABLE (cast(v_ft_oid as table_of_number)) Z1
WHERE NOT EXISTS ( SELECT 'x' FROM EPMContainedIn B WHERE B.IDA3A5 = Z1.COLUMN_VALUE );
FOR i IN 1 .. v_oid.count LOOP
o_errList.extend();
o_errList(o_errList.LAST) := new FT_STATUS('wt.epm.EPMDocument', v_oid(i), 20060);
END LOOP;
FTValidator_Helper_PK.record_errors(20060, 'wt.epm.EPMDocument', ftConfigData, o_errList, v_reportData, i_continue);
IF NOT i_continue THEN
RETURN v_reportData;
END IF;
END IF;
o_errList := new FT_STATUS_TABLE();
FTValidator_Helper_PK.should_validate_error(20520, 'wt.epm.EPMDocument', ftConfigData , i_continue);
IF i_continue = TRUE THEN
-- Report Family table members / EPMDocument (top generic, generic-instance, instance) having a reference to primary content for PROE authored FTMembers
v_oid := NULL;
v_sqltext := 'SELECT DISTINCT doc.IDA2A2 FROM EPMDocument doc , EPMDocumentMaster docm , HolderToContent htc , ApplicationData ad
WHERE doc.IDA2A2 ' || getWhereClause( v_ft_oid, 1) || ' AND doc.idA3masterReference=docm.idA2A2  AND docm.authoringApplication=''PROE'' AND doc.idA2A2=htc.idA3A5 and htc.idA3B5=ad.idA2A2 and ad.role=''PRIMARY''';
EXECUTE IMMEDIATE v_sqltext BULK COLLECT INTO v_oid USING v_ft_oid;
FOR i IN 1 .. v_oid.count LOOP
o_errList.extend();
o_errList(o_errList.LAST) := new FT_STATUS('wt.epm.EPMDocument', v_oid(i), 20520);
END LOOP;
FTValidator_Helper_PK.record_errors(20520, 'wt.epm.EPMDocument', ftConfigData, o_errList, v_reportData, i_continue);
IF NOT i_continue THEN
RETURN v_reportData;
END IF;
END IF;
END IF;
-- get checkedout or private working documents
--        v_sqltext := 'SELECT A.IDA2A2 FROM EPMDocument A
--                    WHERE A.IDA2A2 ' || getWhereClause( i_docList,1) || '
--                    AND A.FAMILYTABLESTATUS <> 0
--                    AND A.CHECKOUTINFOISNULL = 0
--                    AND ((A.STATECHECKOUTINFO = ''wrk'') OR (A.STATECHECKOUTINFO = ''wrk-p''))';
v_sqltext := 'SELECT A.IDA2A2 FROM EPMDocument A WHERE A.IDA2A2 ' || getWhereClause( i_docList, 1) || ' AND A.FAMILYTABLESTATUS <> 0 AND ((A.CHECKOUTINFOISNULL = 0 AND ((A.STATECHECKOUTINFO = ''wrk'') OR (A.STATECHECKOUTINFO = ''wrk-p''))) OR ( EXISTS (SELECT ''x'' from IterFolderMemberLink B, EPMWorkspace C WHERE A.BRANCHIDITERATIONINFO = B.BRANCHIDA3B5 AND A.IDA3C2ITERATIONINFO = 0 AND B.IDA3A5 = C.IDA3B5) ) )';
EXECUTE IMMEDIATE v_sqltext BULK COLLECT INTO v_checkedout_oid USING i_docList;
if v_checkedout_oid.count > 0 THEN
o_errList := new FT_STATUS_TABLE();
FTValidator_Helper_PK.should_validate_error(20120, 'wt.epm.EPMDocument', ftConfigData , i_continue);
IF i_continue = TRUE THEN
-- ensure the instances as well as the family table are checkedout to the same workspace
v_sqltext := 'SELECT B.IDA3A5 FROM EPMContainedin B, BaselineMember C, BaselineMember D, EPMSepFamilyTable E WHERE B.IDA3A5 ' || getWhereClause( v_checkedout_oid,1) || ' AND ((E.STATECHECKOUTINFO = ''wrk'') OR (E.STATECHECKOUTINFO = ''wrk-p'')) AND B.IDA3B5 = E.IDA2A2 AND B.IDA3A5 = C.IDA3B5 AND B.IDA3B5 = D.IDA3B5 AND C.IDA3A5 <> D.IDA3A5 AND C.CLASSNAMEKEYROLEAOBJECTREF = ''wt.epm.workspaces.EPMCheckpoint'' AND D.CLASSNAMEKEYROLEAOBJECTREF = ''wt.epm.workspaces.EPMCheckpoint''';
EXECUTE IMMEDIATE v_sqltext BULK COLLECT INTO v_oid USING v_checkedout_oid;
FOR i IN 1 .. v_oid.count LOOP
o_errList.extend();
o_errList(o_errList.LAST) := new FT_STATUS('wt.epm.EPMDocument', v_oid(i), 20120);
END LOOP;
FTValidator_Helper_PK.record_errors(20120, 'wt.epm.EPMDocument', ftConfigData, o_errList, v_reportData, i_continue);
IF NOT i_continue THEN
RETURN v_reportData;
END IF;
END IF;
o_errList := new FT_STATUS_TABLE();
FTValidator_Helper_PK.should_validate_error(20100, 'wt.epm.EPMDocument', ftConfigData , i_continue);
IF i_continue = TRUE THEN
-- get the checkedout documents which are associated to the checked in family table
v_sqltext := 'SELECT DISTINCT A.IDA3A5 FROM EPMContainedIn A, EPMSepFamilyTable B WHERE A.IDA3A5 ' || getWhereClause( v_checkedout_oid, 1) || ' AND B.STATECHECKOUTINFO <> ''wrk'' AND B.STATECHECKOUTINFO <> ''wrk-p'' AND B.IDA3C2ITERATIONINFO <> 0 AND A.IDA3B5 = B.IDA2A2';
-- changed A.IDA3A6 <> 0 oldFTModel to A.IDA3C2ITERATIONINFO <>0
EXECUTE IMMEDIATE v_sqltext BULK COLLECT INTO v_oid USING v_checkedout_oid;
FOR i IN 1 .. v_oid.count LOOP
o_errList.extend();
o_errList(o_errList.LAST) := new FT_STATUS('wt.epm.EPMDocument', v_oid(i), 20100);
END LOOP;
FTValidator_Helper_PK.record_errors(20100, 'wt.epm.EPMDocument', ftConfigData, o_errList, v_reportData, i_continue);
IF NOT i_continue THEN
RETURN v_reportData;
END IF;
END IF;
END IF;
if v_ft_oid.COUNT > 0 THEN
-- ensure all the members of the associated FT are in the same namespace, if the document is in PDMLink(or WPDM).
-- get all the documents which are in PDMLink(or WPDM)
BEGIN
SELECT 1 INTO v_hasProjects FROM Project2 WHERE rownum = 1;
EXCEPTION
WHEN NO_DATA_FOUND THEN
v_hasProjects := 0;
END;
IF v_hasProjects = 1 THEN
o_errList := new FT_STATUS_TABLE();
FTValidator_Helper_PK.should_validate_error(20130, 'wt.epm.EPMDocument', ftConfigData , i_continue);
IF i_continue = TRUE THEN
v_sqltext := 'SELECT OID_PAIR (null, A.IDA2A2, null, B.IDA3B5) FROM EPMDocument A, EPMContainedIn B
WHERE A.IDA2A2 ' || getWhereClause( v_ft_oid, 1) ||
' AND (A.CLASSNAMEKEYCONTAINERREFEREN = ''wt.inf.library.WTLibrary'' OR A.CLASSNAMEKEYCONTAINERREFEREN = ''wt.pdmlink.PDMLinkProduct'')
AND B.IDA3A5 = A.IDA2A2';
EXECUTE IMMEDIATE v_sqltext BULK COLLECT INTO v_doc_ft_pair USING v_ft_oid;
SELECT C.IDA3B5 BULK COLLECT INTO v_pdm_fts
FROM EPMContainedIn C, EPMDocument D
WHERE C.IDA3B5 IN (SELECT Z.id2 FROM table(cast(v_doc_ft_pair as LIST_OF_OID_PAIRS)) Z)
AND D.IDA2A2 = C.IDA3A5
GROUP BY C.IDA3B5
HAVING sum ( decode ( D.CLASSNAMEKEYCONTAINERREFEREN, 'wt.inf.library.WTLibrary', 0, 'wt.pdmlink.PDMLinkProduct', 0, 1 ) ) = 0;
SELECT distinct Z.id1 BULK COLLECT INTO v_oid
FROM table(cast(v_doc_ft_pair as LIST_OF_OID_PAIRS)) Z
MINUS
SELECT Z2.id1 FROM table(cast(v_pdm_fts as table_of_number)) X
, table(cast(v_doc_ft_pair as LIST_OF_OID_PAIRS)) Z2
WHERE X.column_value = Z2.id2;
FOR i IN 1 .. v_oid.count LOOP
o_errList.extend();
o_errList(o_errList.LAST) := new FT_STATUS('wt.epm.EPMDocument', v_oid(i), 20130);
END LOOP;
FTValidator_Helper_PK.record_errors(20130, 'wt.epm.EPMDocument', ftConfigData, o_errList, v_reportData, i_continue);
IF NOT i_continue THEN
RETURN v_reportData;
END IF;
END IF;
o_errList := new FT_STATUS_TABLE();
FTValidator_Helper_PK.should_validate_error(20140, 'wt.epm.EPMDocument', ftConfigData , i_continue);
IF i_continue = TRUE THEN
-- get all the documents which are in projects.
-- ensure the FT doesnt have documents from more than 1 projects
v_sqltext := 'SELECT DISTINCT A.IDA2A2 FROM EPMDocument A, EPMContainedIn CI1 WHERE A.IDA2A2 ' || getWhereClause( v_ft_oid, 1) || ' AND (A.CLASSNAMEKEYCONTAINERREFEREN = ''wt.projmgmt.admin.Project2'') AND CI1.IDA3A5 = A.IDA2A2 ' ||
' AND   exists ( select 1 from EPMDocument B, EPMContainedIn C ' ||
' where C.IDA3B5 = CI1.IDA3B5 ' ||
' and   C.IDA3A5 = B.IDA2A2 ' ||
' and   B.CLASSNAMEKEYCONTAINERREFEREN = ''wt.projmgmt.admin.Project2'' ' ||
' and   B.IDA3CONTAINERREFERENCE <> A.IDA3CONTAINERREFERENCE )';
EXECUTE IMMEDIATE v_sqltext BULK COLLECT INTO v_oid USING v_ft_oid;
FOR i IN 1 .. v_oid.count LOOP
o_errList.extend();
o_errList(o_errList.LAST) := new FT_STATUS('wt.epm.EPMDocument', v_oid(i), 20140);
END LOOP;
FTValidator_Helper_PK.record_errors(20140, 'wt.epm.EPMDocument', ftConfigData, o_errList, v_reportData, i_continue);
IF NOT i_continue THEN
RETURN v_reportData;
END IF;
END IF;
END IF;
END IF;
-- process generics
v_sqltext := 'SELECT DISTINCT A.IDA2A2 FROM EPMDocument A, EPMDocumentMaster B WHERE A.idA3masterReference=B.idA2A2 and B.authoringApplication<>''UG'' and A.IDA2A2 ' || getWhereClause( i_docList, 1) || ' AND A.FAMILYTABLESTATUS = 2';
EXECUTE IMMEDIATE v_sqltext BULK COLLECT INTO v_nonNXTopgeneric_oid USING i_docList;
v_sqltext := 'SELECT DISTINCT A.IDA2A2 FROM EPMDocument A WHERE A.IDA2A2 ' || getWhereClause( i_docList, 1) || ' AND A.FAMILYTABLESTATUS = 2';
EXECUTE IMMEDIATE v_sqltext BULK COLLECT INTO v_topgeneric_oid USING i_docList;
IF v_topgeneric_oid.COUNT > 0 THEN
o_errList := new FT_STATUS_TABLE();
FTValidator_Helper_PK.should_validate_error(20050, 'wt.epm.EPMDocument', ftConfigData , i_continue);
IF i_continue = TRUE THEN
-- ensure top generic does not participate in any variant link as variant
v_sqltext := 'SELECT DISTINCT A.IDA3A5 FROM EPMVariantLink A WHERE A.IDA3A5 ' || getWhereClause( v_topgeneric_oid, 1);
EXECUTE IMMEDIATE v_sqltext BULK COLLECT INTO v_oid USING v_topgeneric_oid;
FOR i IN 1 .. v_oid.count LOOP
o_errList.extend();
o_errList(o_errList.LAST) := new FT_STATUS('wt.epm.EPMDocument', v_oid(i), 20050);
END LOOP;
FTValidator_Helper_PK.record_errors(20050, 'wt.epm.EPMDocument', ftConfigData, o_errList, v_reportData, i_continue);
IF NOT i_continue THEN
RETURN v_reportData;
END IF;
END IF;
o_errList := new FT_STATUS_TABLE();
FTValidator_Helper_PK.should_validate_error(20080, 'wt.epm.EPMDocument', ftConfigData , i_continue);
IF i_continue = TRUE THEN
-- ensure that family has at least one column if no. of contained in link is 1
v_sqltext := 'SELECT A.IDA3A5 FROM EPMContainedIn A, EPMContainedIn C WHERE A.IDA3A5 ' || getWhereClause( v_nonNXTopgeneric_oid,1) || ' AND   C.IDA3B5 = A.IDA3B5 GROUP BY A.IDA3A5, C.IDA3B5 HAVING count(*) = 1';
EXECUTE IMMEDIATE v_sqltext BULK COLLECT INTO v_oid USING v_nonNXTopgeneric_oid;
FOR i IN 1 .. v_oid.count LOOP
v_error := checkColumnExists(v_oid(i));
IF v_error = 1 THEN
o_errList.extend();
o_errList(o_errList.LAST) := new FT_STATUS('wt.epm.EPMDocument', v_oid(i), 20080);
END IF;
END LOOP;
FTValidator_Helper_PK.record_errors(20080, 'wt.epm.EPMDocument', ftConfigData, o_errList, v_reportData, i_continue);
IF NOT i_continue THEN
RETURN v_reportData;
END IF;
END IF;
o_errList := new FT_STATUS_TABLE();
FTValidator_Helper_PK.should_validate_error(20110, 'wt.epm.EPMDocument', ftConfigData , i_continue);
IF i_continue = TRUE THEN
-- ensure top-generic document iterations have association with the family tables from the same master
v_sqltext := 'SELECT A.IDA3A5, COUNT (DISTINCT B.IDA3MASTERREFERENCE) FROM EPMContainedIn A, EPMSepFamilyTable B WHERE A.IDA3A5  ' || getWhereClause( v_topgeneric_oid, 1) || ' AND   A.IDA3B5 = B.IDA2A2 GROUP BY A.IDA3A5';
EXECUTE IMMEDIATE v_sqltext BULK COLLECT INTO v_oid, v_count USING v_topgeneric_oid;
FOR i IN 1 .. v_oid.count LOOP
IF v_count(i) <> 1 THEN
o_errList.extend();
o_errList(o_errList.LAST) := new FT_STATUS('wt.epm.EPMDocument', v_oid(i), 20110);
END IF;
END LOOP;
FTValidator_Helper_PK.record_errors(20110, 'wt.epm.EPMDocument', ftConfigData, o_errList, v_reportData, i_continue);
IF NOT i_continue THEN
RETURN v_reportData;
END IF;
END IF;
END IF;
-- process instances (not generic)
-- ensure the instance participates in variant link as variant
v_sqltext := 'SELECT A.IDA2A2 FROM EPMDocument A WHERE A.IDA2A2 ' || getWhereClause( i_docList, 1) || ' AND A.FAMILYTABLESTATUS IN (1, 3)';
EXECUTE IMMEDIATE v_sqltext BULK COLLECT INTO v_instances_oid USING i_docList;
IF v_instances_oid.COUNT > 0 THEN
o_errList := new FT_STATUS_TABLE();
FTValidator_Helper_PK.should_validate_error(20150, 'wt.epm.EPMDocument', ftConfigData , i_continue);
IF i_continue = TRUE THEN
SELECT Z.column_value INST_OID BULK COLLECT INTO v_oid from table(cast(v_instances_oid as table_of_number)) Z
WHERE NOT EXISTS (SELECT 'x' FROM EPMVariantLink B WHERE B.IDA3A5 = Z.column_value);
FOR i IN 1 .. v_oid.count LOOP
o_errList.extend();
o_errList(o_errList.LAST) := new FT_STATUS('wt.epm.EPMDocument', v_oid(i), 20150);
END LOOP;
FTValidator_Helper_PK.record_errors(20150, 'wt.epm.EPMDocument', ftConfigData, o_errList, v_reportData, i_continue);
IF NOT i_continue THEN
RETURN v_reportData;
END IF;
END IF;
o_errList := new FT_STATUS_TABLE();
FTValidator_Helper_PK.should_validate_error(20360, 'wt.epm.EPMDocument', ftConfigData , i_continue);
IF i_continue = TRUE THEN
-- ensure there exists a containedin link between the found EPMSepFamilyTable and the found generic for instances
v_sqltext := 'SELECT A.IDA3A5 FROM EPMVariantLink A, EPMContainedIn B WHERE A.IDA3A5 ' || getWhereClause( v_instances_oid,1) || ' AND   B.IDA3A5 = A.IDA3A5 AND NOT EXISTS ( SELECT ''x'' FROM  EPMContainedIn D, EPMDocument E WHERE D.IDA3B5 = B.IDA3B5 AND   E.IDA3MASTERREFERENCE = A.IDA3B5 AND   D.IDA3A5 = E.IDA2A2)';
EXECUTE IMMEDIATE v_sqltext BULK COLLECT INTO v_oid USING v_instances_oid;
FOR i IN 1 .. v_oid.count LOOP
o_errList.extend();
o_errList(o_errList.LAST) := new FT_STATUS('wt.epm.EPMDocument', v_oid(i), 20360);
END LOOP;
FTValidator_Helper_PK.record_errors(20360, 'wt.epm.EPMDocument', ftConfigData, o_errList, v_reportData, i_continue);
IF NOT i_continue THEN
RETURN v_reportData;
END IF;
END IF;
/* This check is not required. It is not really needed to check the navigation
to top level. It is sufficient to check it to immediate generic. And when
immediate generic is checked it will check for navigation to next above level.
If this is ok then the required check for immediate generic navigation is already
done in check for code 20150 + 20360. So why repeat it?
o_errList := new FT_STATUS_TABLE();
FTValidator_Helper_PK.should_validate_error(20380, 'wt.epm.EPMDocument', ftConfigData , i_continue);
IF i_continue = TRUE THEN
--  ensure navigation from variant to its generic and beyond using variant links ends up to top-level generic
FOR i IN 1 .. v_instances_oid.count LOOP
v_error := getTopGeneric(v_instances_oid(i));
if v_error = 1 then
o_errList.extend();
o_errList(o_errList.LAST) := new FT_STATUS('wt.epm.EPMDocument', v_instances_oid(i), 20380);
end if;
END LOOP;
FTValidator_Helper_PK.record_errors(20380, 'wt.epm.EPMDocument', ftConfigData, o_errList, v_reportData, i_continue);
IF NOT i_continue THEN
RETURN v_reportData;
END IF;
END IF;
*/
END IF;
-- process intermediate generic
o_errList := new FT_STATUS_TABLE();
FTValidator_Helper_PK.should_validate_error(20370, 'wt.epm.EPMDocument', ftConfigData , i_continue);
IF i_continue = TRUE THEN
-- intermediate generic may not have any variants but then it should have columns defined at its level
v_sqltext := 'SELECT A.IDA2A2 FROM EPMDocument A WHERE A.FAMILYTABLESTATUS = 3 AND A.IDA2A2 ' || getWhereClause( i_docList, 1) || ' AND NOT EXISTS (SELECT ''x'' FROM EPMVariantLink B WHERE B.IDA3B5 = A.IDA3MASTERREFERENCE)';
EXECUTE IMMEDIATE v_sqltext BULK COLLECT INTO v_oid USING i_docList;
FOR i IN 1 .. v_oid.count LOOP
v_error := checkColumnExists(v_oid(i));
IF v_error = 1 THEN
o_errList.extend();
o_errList(o_errList.LAST) := new FT_STATUS('wt.epm.EPMDocument', v_oid(i), 20370);
END IF;
END LOOP;
FTValidator_Helper_PK.record_errors(20370, 'wt.epm.EPMDocument', ftConfigData, o_errList, v_reportData, i_continue);
IF NOT i_continue THEN
RETURN v_reportData;
END IF;
END IF;
RETURN v_reportData;
END ValidateEPMDocuments;
FUNCTION  ValidateEPMDocumentMasters (i_docMasterList IN TABLE_OF_NUMBER, ftConfigData IN OUT FTVAL_CONFIG_TABLE ) RETURN FT_REPORT_DATA IS
v_sqltext VARCHAR2(2000);
v_masteroid TABLE_OF_NUMBER;
o_errList	     FT_STATUS_TABLE;
v_reportData   FT_REPORT_DATA;
i_continue	     BOOLEAN;
BEGIN
o_errList := new FT_STATUS_TABLE();
v_reportData := new FT_REPORT_DATA();
i_continue := FALSE;
FTValidator_Helper_PK.should_validate_error(20190, 'wt.epm.EPMDocumentMaster', ftConfigData , i_continue);
IF i_continue = TRUE THEN
-- find masters where CADName does not match name of the family table master
v_sqltext := 'SELECT A.IDA2A2 FROM EPMDocumentMaster A, EPMDocument B, EPMContainedin C, EPMSepFamilyTable D, EPMSepFamilyTableMaster E WHERE A.IDA2A2 ' || getWhereClause( i_docMasterList, 1) || ' AND A.IDA2A2 = B.IDA3MASTERREFERENCE AND B.FAMILYTABLESTATUS = 2 AND B.IDA2A2 = C.IDA3A5 AND C.IDA3B5 = D.IDA2A2 AND D.IDA3MASTERREFERENCE = E.IDA2A2 AND E.NAME <> A.CADNAME';
EXECUTE IMMEDIATE v_sqltext BULK COLLECT INTO v_masteroid USING i_docMasterList;
FOR i IN 1 .. v_masteroid.count LOOP
o_errList.extend();
o_errList(o_errList.LAST) := new FT_STATUS('wt.epm.EPMDocumentMaster', v_masteroid(i), 20190);
END LOOP;
FTValidator_Helper_PK.record_errors(20190, 'wt.epm.EPMDocumentMaster', ftConfigData, o_errList, v_reportData, i_continue);
IF NOT i_continue THEN
RETURN v_reportData;
END IF;
END IF;
RETURN v_reportData;
END ValidateEPMDocumentMasters;
FUNCTION  ValidateEPMContainedInLinks (i_linkList IN TABLE_OF_NUMBER, ftConfigData IN OUT FTVAL_CONFIG_TABLE ) RETURN FT_REPORT_DATA IS
v_sqltext   VARCHAR2(2000);
v_linkoid   TABLE_OF_NUMBER;
v_ftoid     TABLE_OF_NUMBER;
v_masters   TABLE_OF_NUMBER;
v_links     TABLE_OF_NUMBER;
v_count     TABLE_OF_NUMBER;
v_reportData   FT_REPORT_DATA;
i_continue	     BOOLEAN;
o_errList	FT_STATUS_TABLE;
BEGIN
o_errList := new FT_STATUS_TABLE();
v_reportData := new FT_REPORT_DATA();
i_continue := FALSE;
FTValidator_Helper_PK.should_validate_error(20200, 'wt.epm.structure.EPMContainedIn', ftConfigData , i_continue);
IF i_continue = TRUE THEN
-- ensure the document is not standalone
v_sqltext := 'SELECT A.IDA2A2 FROM EPMContainedin A, EPMDocument B WHERE A.IDA2A2 ' || getWhereClause( i_linkList,1) || ' AND A.IDA3A5 = B.IDA2A2 AND (B.FAMILYTABLESTATUS = 0 OR B.FAMILYTABLESTATUS IS NULL)';
EXECUTE IMMEDIATE v_sqltext BULK COLLECT INTO v_linkoid USING i_linkList;
-- dbms_output.put_line('Standalone Documents  ' || v_linkoid.count);
FOR i IN 1 .. v_linkoid.count LOOP
o_errList.extend();
-- dbms_output.put_line('Standalone Documents[' || i || '] : ' || v_linkoid(i));
o_errList(o_errList.LAST) := new FT_STATUS('wt.epm.structure.EPMContainedIn', v_linkoid(i), 20200);
END LOOP;
FTValidator_Helper_PK.record_errors(20200, 'wt.epm.structure.EPMContainedIn', ftConfigData, o_errList, v_reportData, i_continue);
IF NOT i_continue THEN
RETURN v_reportData;
END IF;
END IF;
o_errList := new FT_STATUS_TABLE();
FTValidator_Helper_PK.should_validate_error(20210, 'wt.epm.structure.EPMContainedIn', ftConfigData , i_continue);
IF i_continue = TRUE THEN
-- ensure there are no contained in links between the same two objects
v_sqltext := 'SELECT A.IDA2A2 FROM EPMContainedin A, EPMContainedin B WHERE A.IDA2A2 ' || getWhereClause( i_linkList,1) || ' AND A.IDA2A2 <> B.IDA2A2 AND A.IDA3A5 = B.IDA3A5 AND A.IDA3B5 = B.IDA3B5';
EXECUTE IMMEDIATE v_sqltext BULK COLLECT INTO v_linkoid USING i_linkList;
FOR i IN 1 .. v_linkoid.count LOOP
-- dbms_output.put_line('Link id : ' || v_linkoid(i));
o_errList.extend();
o_errList(o_errList.LAST) := new FT_STATUS('wt.epm.structure.EPMContainedIn', v_linkoid(i), 20210);
END LOOP;
FTValidator_Helper_PK.record_errors(20210, 'wt.epm.structure.EPMContainedIn', ftConfigData, o_errList, v_reportData, i_continue);
IF NOT i_continue THEN
RETURN v_reportData;
END IF;
END IF;
o_errList := new FT_STATUS_TABLE();
FTValidator_Helper_PK.should_validate_error(20220, 'wt.epm.structure.EPMContainedIn', ftConfigData , i_continue);
IF i_continue = TRUE THEN
-- ensure iterations from a document master does not participate in contained in link with the same family table
-- v_sqltext := 'SELECT A.IDA2A2 FROM EPMContainedIn A WHERE A.IDA2A2 ' || getWhereClause( i_linkList, 1) || ' AND   EXISTS ( SELECT ''x'' FROM EPMContainedIn B, EPMDocument C, EPMDocument D WHERE B.IDA3B5 = A.IDA3B5 AND   C.IDA2A2 = A.IDA3A5 AND   D.IDA3MASTERREFERENCE = C.IDA3MASTERREFERENCE AND   D.IDA2A2 <> C.IDA2A2 AND   D.IDA2A2 = B.IDA3A5 )';
v_sqltext := 'SELECT  DISTINCT A.IDA2A2 FROM EPMContainedIn A, EPMContainedIn B, EPMDocument C, EPMDocument D WHERE A.IDA2A2 ' || getWhereClause( i_linkList, 1) ||
' AND B.IDA3B5 = A.IDA3B5 AND   C.IDA2A2 = A.IDA3A5 AND   D.IDA3MASTERREFERENCE = C.IDA3MASTERREFERENCE AND   D.IDA2A2 <> C.IDA2A2 AND   D.IDA2A2 = B.IDA3A5';
EXECUTE IMMEDIATE v_sqltext BULK COLLECT INTO v_linkoid USING i_linkList;
FOR i IN 1 .. v_linkoid.count LOOP
-- dbms_output.put_line('Link myid : ' || v_linkoid(i));
o_errList.extend();
o_errList(o_errList.LAST) := new FT_STATUS('wt.epm.structure.EPMContainedIn', v_linkoid(i), 20220);
END LOOP;
FTValidator_Helper_PK.record_errors(20220, 'wt.epm.structure.EPMContainedIn', ftConfigData, o_errList, v_reportData, i_continue);
IF NOT i_continue THEN
RETURN v_reportData;
END IF;
END IF;
o_errList := new FT_STATUS_TABLE();
FTValidator_Helper_PK.should_validate_error(20350, 'wt.epm.structure.EPMContainedIn', ftConfigData , i_continue);
IF i_continue = TRUE THEN
-- SSS: Re-validate if it will give required result
-- ensure the instance iteration is not part of two different family tables (FT of different masters)
v_sqltext := 'SELECT A.IDA2A2 FROM EPMContainedin A, EPMContainedin B, EPMSepFamilyTable C WHERE A.IDA2A2 ' || getWhereClause(i_linkList, 1) || ' AND A.IDA3A5 = B.IDA3A5 AND B.IDA3B5 = C.IDA2A2 GROUP BY A.IDA2A2 HAVING COUNT(DISTINCT C.IDA3MASTERREFERENCE) <> 1';
EXECUTE IMMEDIATE v_sqltext BULK COLLECT INTO v_linkoid USING i_linkList;
FOR i IN 1 .. v_linkoid.count LOOP
o_errList.extend();
o_errList(o_errList.LAST) := new FT_STATUS('wt.epm.structure.EPMContainedIn', v_linkoid(i), 20350);
END LOOP;
FTValidator_Helper_PK.record_errors(20350, 'wt.epm.structure.EPMContainedIn', ftConfigData, o_errList, v_reportData, i_continue);
IF NOT i_continue THEN
RETURN v_reportData;
END IF;
END IF;
return v_reportData;
END ValidateEPMContainedInLinks;
FUNCTION  ValidateEPMVariantLinks (i_linkList IN TABLE_OF_NUMBER,ftConfigData IN OUT FTVAL_CONFIG_TABLE ) RETURN FT_REPORT_DATA
IS
v_sqltext   VARCHAR2(2000);
v_linkoid   TABLE_OF_NUMBER;
v_ftoid     TABLE_OF_NUMBER;
v_masters   TABLE_OF_NUMBER;
v_links     TABLE_OF_NUMBER;
i_continue  BOOLEAN;
o_errList	FT_STATUS_TABLE;
v_reportData   FT_REPORT_DATA;
BEGIN
v_reportData := new FT_REPORT_DATA();
i_continue := FALSE;
-- The FT_STATUS_TABLE should be initialized everytime for each error code
o_errList := new FT_STATUS_TABLE();
FTValidator_Helper_PK.should_validate_error(20230, 'wt.epm.structure.EPMVariantLink', ftConfigData , i_continue);
IF i_continue = TRUE THEN
-- ensure the document is not standalone
v_sqltext := 'SELECT A.IDA2A2 FROM EPMVariantLink A, EPMDocument B WHERE A.IDA2A2 ' || getWhereClause( i_linkList, 1) || ' AND A.IDA3A5 = B.IDA2A2 AND NVL(B.FAMILYTABLESTATUS,0) = 0';
EXECUTE IMMEDIATE v_sqltext BULK COLLECT INTO v_linkoid USING i_linkList;
FOR i IN 1 .. v_linkoid.count LOOP
o_errList.extend();
o_errList(o_errList.LAST) := new FT_STATUS('wt.epm.structure.EPMVariantLink', v_linkoid(i), 20230);
END LOOP;
FTValidator_Helper_PK.record_errors(20230, 'wt.epm.structure.EPMVariantLink', ftConfigData, o_errList, v_reportData, i_continue);
IF NOT i_continue THEN
RETURN v_reportData;
END IF;
END IF;
-- The FT_STATUS_TABLE should be initialized everytime for each error code
o_errList := new FT_STATUS_TABLE();
i_continue := FALSE;
FTValidator_Helper_PK.should_validate_error(20240, 'wt.epm.structure.EPMVariantLink', ftConfigData , i_continue);
IF i_continue = TRUE THEN
-- ensure there are no variant links between the same two objects
v_sqltext := 'SELECT A.IDA2A2 FROM EPMVariantLink A, EPMVariantLink B WHERE A.IDA2A2 ' || getWhereClause( i_linkList, 1) || ' AND A.IDA2A2 <> B.IDA2A2 AND A.IDA3A5 = B.IDA3A5 AND A.IDA3B5 = B.IDA3B5';
EXECUTE IMMEDIATE v_sqltext BULK COLLECT INTO v_linkoid USING i_linkList;
FOR i IN 1 .. v_linkoid.count LOOP
o_errList.extend();
o_errList(o_errList.LAST) := new FT_STATUS('wt.epm.structure.EPMVariantLink', v_linkoid(i), 20240);
END LOOP;
FTValidator_Helper_PK.record_errors(20240, 'wt.epm.structure.EPMVariantLink', ftConfigData, o_errList, v_reportData, i_continue);
IF NOT i_continue THEN
RETURN v_reportData;
END IF;
END IF;
RETURN v_reportData;
END ValidateEPMVariantLinks;
FUNCTION  ValidateEPMFamilyTable (i_ftList IN TABLE_OF_NUMBER, ftConfigData IN OUT FTVAL_CONFIG_TABLE ) RETURN FT_REPORT_DATA  IS
v_sqltext           VARCHAR2(2000);
v_ftoid             TABLE_OF_NUMBER;
v_error_oid         TABLE_OF_NUMBER;
v_oid               TABLE_OF_NUMBER;
v_orphan_ft         TABLE_OF_NUMBER;
v_topgeneric_count  TABLE_OF_NUMBER;
v_error             NUMBER;
o_errList	        FT_STATUS_TABLE;
v_reportData        FT_REPORT_DATA;
i_continue          BOOLEAN;
BEGIN
o_errList := new FT_STATUS_TABLE();
v_error_oid := new TABLE_OF_NUMBER();
v_reportData := FT_REPORT_DATA();
i_continue := FALSE;
FTValidator_Helper_PK.should_validate_error(20390, 'wt.epm.familytable.EPMSepFamilyTable', ftConfigData , i_continue);
IF i_continue = TRUE THEN
-- ensure family tables have only one top-generic
v_sqltext := 'SELECT A.IDA3B5, SUM(DECODE(B.FAMILYTABLESTATUS, 2, 1, 0)) FROM EPMContainedIn A, EPMDocument B WHERE A.IDA3B5 ' || getWhereClause( i_ftList, 1) || ' AND A.IDA3A5 = B.IDA2A2 GROUP BY A.IDA3B5';
EXECUTE IMMEDIATE v_sqltext BULK COLLECT INTO v_ftoid, v_topgeneric_count USING i_ftList;
FOR i IN 1 .. v_ftoid.count LOOP
IF v_topgeneric_count(i) <> 1 THEN
o_errList.extend();
o_errList(o_errList.LAST) := new FT_STATUS('wt.epm.familytable.EPMSepFamilyTable', v_ftoid(i), 20390);
END IF;
END LOOP;
FTValidator_Helper_PK.record_errors(20390, 'wt.epm.familytable.EPMSepFamilyTable', ftConfigData, o_errList, v_reportData, i_continue);
IF NOT i_continue THEN
RETURN v_reportData;
END IF;
END IF;
o_errList := new FT_STATUS_TABLE();
FTValidator_Helper_PK.should_validate_error(20420, 'wt.epm.familytable.EPMSepFamilyTable', ftConfigData , i_continue);
IF i_continue = TRUE THEN
-- ensure that family has at least one column if no. of contained in link is 1
v_sqltext := 'SELECT A.IDA3B5 FROM EPMContainedIn A WHERE A.IDA3B5 ' || getWhereClause( i_ftList, 1) || ' GROUP BY A.IDA3B5 HAVING count(*) = 1';
EXECUTE IMMEDIATE v_sqltext BULK COLLECT INTO v_oid USING i_ftList;
FOR i IN 1 .. v_oid.count LOOP
v_error := checkColumnExistsForFT(v_oid(i));
IF v_error = 1 THEN
v_error_oid.extend();
v_error_oid(v_error_oid.LAST) := v_oid(i);
END IF;
END LOOP;
IF v_error_oid.COUNT > 0 THEN
-- ignore the family tables that belong to PRO/I Gateway published EPMDocuments
v_sqltext := 'SELECT DISTINCT A.IDA3B5 FROM EPMContainedIn A, EPMDocument B, EPMDocumentMaster C WHERE A.IDA3B5 ' || getWhereClause( v_error_oid, 1) || ' AND A.IDA3A5 = B.IDA2A2 AND B.IDA3MASTERREFERENCE = C.IDA2A2 AND C.OWNERAPPLICATION != ''PROINTRALINKGATEWAY'' AND C.authoringApplication !=''UG''';
EXECUTE IMMEDIATE v_sqltext BULK COLLECT INTO v_oid USING v_error_oid;
FOR i IN 1 .. v_oid.count LOOP
o_errList.extend();
o_errList(o_errList.LAST) := new FT_STATUS('wt.epm.familytable.EPMSepFamilyTable', v_oid(i), 20420);
END LOOP;
FTValidator_Helper_PK.record_errors(20420, 'wt.epm.familytable.EPMSepFamilyTable', ftConfigData, o_errList, v_reportData, i_continue);
IF NOT i_continue THEN
RETURN v_reportData;
END IF;
END IF;
END IF;
o_errList := new FT_STATUS_TABLE();
FTValidator_Helper_PK.should_validate_error(20540, 'wt.epm.familytable.EPMSepFamilyTable', ftConfigData , i_continue);
IF i_continue = TRUE THEN
-- Ensure that Checkedout EPMSepFamilyTable has checkedout members
v_sqltext := 'SELECT distinct ft.idA2A2 FROM EPMSepFamilyTable ft where ft.idA2A2 ' || getWhereClause( i_ftList, 1) || ' and ((ft.statecheckoutInfo=''wrk'') or (ft.statecheckoutInfo=''wrk-p'')) '||
' and not exists (select 1 from EPMContainedIn ci, EPMDocument doc WHERE ft.idA2A2=ci.idA3B5 and ci.idA3A5=doc.idA2A2 and ((doc.statecheckoutInfo=''wrk'') or (doc.statecheckoutInfo=''wrk-p'')))';
EXECUTE IMMEDIATE v_sqltext BULK COLLECT INTO v_ftoid USING i_ftList;
FOR i IN 1 .. v_ftoid.count LOOP
o_errList.extend();
o_errList(o_errList.LAST) := new FT_STATUS('wt.epm.familytable.EPMSepFamilyTable',  v_ftoid(i), 20540);
END LOOP;
FTValidator_Helper_PK.record_errors(20540, 'wt.epm.familytable.EPMSepFamilyTable', ftConfigData, o_errList, v_reportData, i_continue);
IF NOT i_continue THEN
RETURN v_reportData;
END IF;
END IF;
o_errList := new FT_STATUS_TABLE();
FTValidator_Helper_PK.should_validate_error(20430, 'wt.epm.familytable.EPMSepFamilyTable', ftConfigData , i_continue);
IF i_continue = TRUE THEN
-- ensure family table has columns with unique names
v_sqltext := 'SELECT DISTINCT IDA3A3 FROM (
SELECT ida3a3, name from EPMFamilyTableParameter
UNION ALL
SELECT ida3a3, name from EPMFamilyTableFeature
UNION ALL
SELECT ida3a3, name from EPMFamilyTableMember
UNION ALL
SELECT ida3a3, name from EPMFamilyTableReference
UNION ALL
SELECT ida3a3, name from EPMFamilyTableAttribute )
WHERE IDA3A3 ' || getWhereClause( i_ftList, 1) || '
GROUP BY IDA3A3, NAME
HAVING count(*) > 1';
EXECUTE IMMEDIATE v_sqltext BULK COLLECT INTO v_ftoid USING i_ftList;
FOR i IN 1 .. v_ftoid.count LOOP
o_errList.extend();
o_errList(o_errList.LAST) := new FT_STATUS('wt.epm.familytable.EPMSepFamilyTable',  v_ftoid(i), 20430);
END LOOP;
FTValidator_Helper_PK.record_errors(20430, 'wt.epm.familytable.EPMSepFamilyTable', ftConfigData, o_errList, v_reportData, i_continue);
IF NOT i_continue THEN
RETURN v_reportData;
END IF;
END IF;
o_errList := new FT_STATUS_TABLE();
FTValidator_Helper_PK.should_validate_error(20400, 'wt.epm.familytable.EPMSepFamilyTable', ftConfigData , i_continue);
IF i_continue = TRUE THEN
-- ensure associated members of checked in family table are not checked out
v_sqltext := 'SELECT A.IDA2A2 FROM EPMSepFamilyTable A, EPMContainedIn B, EPMDocument C WHERE A.IDA2A2 ' || getWhereClause( i_ftList, 1) || ' AND A.STATECHECKOUTINFO <> ''wrk'' AND A.STATECHECKOUTINFO <> ''wrk-p'' AND A.IDA3C2ITERATIONINFO <> 0 AND A.IDA2A2 = B.IDA3B5 AND B.IDA3A5 = C.IDA2A2 AND C.FAMILYTABLESTATUS <> 0 AND C.CHECKOUTINFOISNULL = 0 AND ((C.STATECHECKOUTINFO = ''wrk'') OR (C.STATECHECKOUTINFO = ''wrk-p''))';
EXECUTE IMMEDIATE v_sqltext BULK COLLECT INTO v_ftoid USING i_ftList;
FOR i IN 1 .. v_ftoid.count LOOP
o_errList.extend();
o_errList(o_errList.LAST) := new FT_STATUS('wt.epm.familytable.EPMSepFamilyTable', v_ftoid(i), 20400);
END LOOP;
FTValidator_Helper_PK.record_errors(20400, 'wt.epm.familytable.EPMSepFamilyTable', ftConfigData, o_errList, v_reportData, i_continue);
IF NOT i_continue THEN
RETURN v_reportData;
END IF;
END IF;
o_errList := new FT_STATUS_TABLE();
FTValidator_Helper_PK.should_validate_error(20410, 'wt.epm.familytable.EPMSepFamilyTable', ftConfigData , i_continue);
IF i_continue = TRUE THEN
-- ensure associated members of checked out family table are checked out to the same workspace
v_sqltext := 'SELECT A.IDA2A2 FROM EPMSepFamilyTable A, EPMContainedIn B, EPMDocument C, BaselineMember D, BaselineMember E WHERE A.IDA2A2 ' || getWhereClause( i_ftList, 1) || ' AND ((A.STATECHECKOUTINFO = ''wrk'') OR (A.STATECHECKOUTINFO = ''wrk-p'')) AND C.FAMILYTABLESTATUS <> 0 AND C.CHECKOUTINFOISNULL = 0 AND ((C.STATECHECKOUTINFO = ''wrk'') OR (C.STATECHECKOUTINFO = ''wrk-p'')) AND B.IDA3A5 = C.IDA2A2 AND B.IDA3B5 = A.IDA2A2 AND B.IDA3A5 = D.IDA3B5 AND B.IDA3B5 = E.IDA3B5 AND D.IDA3A5 <> E.IDA3A5 AND E.CLASSNAMEKEYROLEAOBJECTREF = ''wt.epm.workspaces.EPMCheckpoint'' AND D.CLASSNAMEKEYROLEAOBJECTREF = ''wt.epm.workspaces.EPMCheckpoint''';
EXECUTE IMMEDIATE v_sqltext BULK COLLECT INTO v_ftoid USING i_ftList;
FOR i IN 1 .. v_ftoid.count LOOP
o_errList.extend();
o_errList(o_errList.LAST) := new FT_STATUS('wt.epm.familytable.EPMSepFamilyTable', v_ftoid(i), 20410);
END LOOP;
FTValidator_Helper_PK.record_errors(20410, 'wt.epm.familytable.EPMSepFamilyTable', ftConfigData, o_errList, v_reportData, i_continue);
IF NOT i_continue THEN
RETURN v_reportData;
END IF;
END IF;
o_errList := new FT_STATUS_TABLE();
FTValidator_Helper_PK.should_validate_error(20440, 'wt.epm.familytable.EPMSepFamilyTable', ftConfigData , i_continue);
IF i_continue = TRUE THEN
-- Result from 20440 is used in check for 20450 also
-- ensure that all the EPMSepFamilyTable objects are associated to one or more containedIn links
-- In some cases EPM creates orphaned family tables and these need not be reported
-- Such orphaned FTs are created as first iteration on branch and has successor.
v_sqltext := 'SELECT A.IDA2A2 FROM EPMSepFamilyTable A WHERE A.IDA2A2 ' || getWhereClause( i_ftList, 1) ||' AND   NOT EXISTS ( SELECT 1 FROM EPMContainedIn B WHERE B.IDA3B5 = A.IDA2A2 ) ';
EXECUTE IMMEDIATE v_sqltext BULK COLLECT INTO v_orphan_ft USING i_ftList;
IF v_orphan_ft IS NOT NULL AND v_orphan_ft.COUNT > 0 THEN
v_sqltext := 'SELECT A.IDA2A2 FROM EPMSepFamilyTable A WHERE A.IDA2A2 ' || getWhereClause( v_orphan_ft, 1) ||
'AND NOT EXISTS ( SELECT 1 FROM ControlBranch cb, EPMSepFamilyTable B WHERE cb.ida2a2 = a.branchIditerationInfo and cb.ida3c5 = a.ida3c2iterationinfo and b.ida3c2iterationinfo = a.ida2a2 and a.oneOffVersionIdA2oneOffVersi is not null)';
EXECUTE IMMEDIATE v_sqltext BULK COLLECT INTO v_ftoid USING v_orphan_ft;
FOR i IN 1 .. v_ftoid.count LOOP
o_errList.extend();
o_errList(o_errList.LAST) := new FT_STATUS('wt.epm.familytable.EPMSepFamilyTable', v_ftoid(i), 20440);
END LOOP;
FTValidator_Helper_PK.record_errors(20440, 'wt.epm.familytable.EPMSepFamilyTable', ftConfigData, o_errList, v_reportData, i_continue);
IF NOT i_continue THEN
RETURN v_reportData;
END IF;
END IF;
FTValidator_Helper_PK.should_validate_error(20450, 'wt.epm.familytable.EPMSepFamilyTable', ftConfigData , i_continue);
IF i_continue = TRUE THEN
-- ensure family table domain is same as domain of member in project
-- or if no member is in project then it is same as of top generic
-- Note 1 : if new ft is created from working copy of top generic ( which was standalone previously )
-- then domain of new ft does not match domain of top generic hence such case should be filtered
IF v_orphan_ft IS NOT NULL AND v_orphan_ft.COUNT > 0 THEN
SELECT Z1.COLUMN_VALUE BULK COLLECT INTO v_oid
FROM table(cast(i_ftList as TABLE_OF_NUMBER)) Z1
MINUS
SELECT Z2.COLUMN_VALUE
FROM table(cast(v_orphan_ft as TABLE_OF_NUMBER)) Z2;
ELSE
v_oid := i_ftList;
END IF;
IF v_oid.COUNT > 0 THEN
v_sqltext := 'SELECT ft.IDA2A2 FROM EPMSepFamilyTable ft WHERE ft.IDA2A2 ' || getWhereClause( v_oid, 1) ||
' and ft.STATECHECKOUTINFO != ''wrk'' and ft.STATECHECKOUTINFO != ''wrk-p'' and not exists ( select 1 from epmcontainedin cii, epmdocument dd ' ||
' where cii.ida3b5 = ft.ida2a2	and dd.ida2a2 = cii.ida3a5 group by cii.ida3b5 ' ||
' HAVING  ( sum ( decode ( dd.classnamekeycontainerreferen, ''wt.projmgmt.admin.Project2'', 1, 0 ) ) >= 1 AND sum ( CASE WHEN (dd.ida3domainref = ft.ida3domainref AND dd.classnamekeycontainerreferen = ''wt.projmgmt.admin.Project2'') THEN 1 ELSE 0 END ) > 0 ) ' ||
' OR ( sum ( decode ( dd.classnamekeycontainerreferen, ''wt.projmgmt.admin.Project2'', 1, 0 ) ) = 0 AND sum ( CASE WHEN (dd.ida3domainref = ft.ida3domainref AND dd.familytablestatus = 2)  THEN 1 ELSE 0 END ) > 0 ) ' ||
' OR ( sum ( CASE WHEN (ft.idA3C2iterationInfo = 0 AND dd.familytablestatus = 2 AND ((dd.STATECHECKOUTINFO = ''wrk'') OR (dd.STATECHECKOUTINFO = ''wrk-p'')))  THEN 1 ELSE 0 END ) > 0 ) )';
EXECUTE IMMEDIATE v_sqltext BULK COLLECT INTO v_ftoid USING v_oid;
FOR i IN 1 .. v_ftoid.count LOOP
o_errList.extend();
o_errList(o_errList.LAST) := new FT_STATUS('wt.epm.familytable.EPMSepFamilyTable', v_ftoid(i), 20450);
END LOOP;
FTValidator_Helper_PK.record_errors(20450, 'wt.epm.familytable.EPMSepFamilyTable', ftConfigData, o_errList, v_reportData, i_continue);
IF NOT i_continue THEN
RETURN v_reportData;
END IF;
END IF;
END IF;
END IF;
o_errList := new FT_STATUS_TABLE();
FTValidator_Helper_PK.should_validate_error(20530, 'wt.epm.familytable.EPMSepFamilyTable', ftConfigData , i_continue);
IF i_continue = TRUE THEN
-- Family Tables / EPMSepFamilyTable having no primary content.
-- Do not report orphaned FT's for this case
v_ftoid := NULL;
v_sqltext := 'SELECT ft.idA2A2 FROM EPMSepFamilyTable ft, EPMSepFamilyTableMaster ftm WHERE ft.idA2A2 ' || getWhereClause( i_ftList, 1) || ' and ft.idA3masterReference=ftm.idA2A2 and ftm.authoringApplication=''PROE'' and not exists ( select ''x'' from HolderToContent htc, ApplicationData ad where ft.idA2A2=htc.idA3A5 and htc.idA3B5=ad.idA2A2 and ad.role=''PRIMARY'')';
EXECUTE IMMEDIATE v_sqltext BULK COLLECT INTO v_ftoid USING i_ftList;
FOR i IN 1 .. v_ftoid.count LOOP
o_errList.extend();
o_errList(o_errList.LAST) := new FT_STATUS('wt.epm.familytable.EPMSepFamilyTable', v_ftoid(i), 20530);
END LOOP;
FTValidator_Helper_PK.record_errors(20530, 'wt.epm.familytable.EPMSepFamilyTable', ftConfigData, o_errList, v_reportData, i_continue);
IF NOT i_continue THEN
RETURN v_reportData;
END IF;
END IF;
RETURN v_reportData;
END ValidateEPMFamilyTable;
FUNCTION  ValidateEPMFamilyTableMasters (i_ftMasterList IN TABLE_OF_NUMBER,ftConfigData IN OUT FTVAL_CONFIG_TABLE ) RETURN FT_REPORT_DATA IS
v_sqltext   VARCHAR2(2000);
v_masteroid TABLE_OF_NUMBER;
i_continue  BOOLEAN;
o_errList	FT_STATUS_TABLE;
v_reportData   FT_REPORT_DATA;
BEGIN
o_errList := new FT_STATUS_TABLE();
v_reportData := new FT_REPORT_DATA();
i_continue := FALSE;
FTValidator_Helper_PK.should_validate_error(20190, 'wt.epm.familytable.EPMSepFamilyTableMaster', ftConfigData , i_continue);
if i_continue = TRUE THEN
-- Find family table master where the name does not match the generics docmasters master's CADName
v_sqltext := 'SELECT DISTINCT A.IDA2A2  FROM EPMSepFamilyTableMaster A, EPMSepFamilyTable B, EPMContainedin C, EPMDocument D, EPMDocumentMaster E  WHERE A.IDA2A2 ' || getWhereClause( i_ftMasterList, 1) || '  AND A.IDA2A2 = B.IDA3MASTERREFERENCE  AND B.IDA2A2 = C.IDA3B5  AND C.IDA3A5 = D.IDA2A2  AND D.FAMILYTABLESTATUS = 2  AND D.IDA3MASTERREFERENCE = E.IDA2A2  AND E.CADNAME <> A.NAME';
EXECUTE IMMEDIATE v_sqltext BULK COLLECT INTO v_masteroid USING i_ftMasterList;
FOR i IN 1 .. v_masteroid.count LOOP
o_errList.extend();
o_errList(o_errList.LAST) := new FT_STATUS('wt.epm.familytable.EPMSepFamilyTableMaster', v_masteroid(i), 20190);
END LOOP;
FTValidator_Helper_PK.record_errors(20190, 'wt.epm.familytable.EPMSepFamilyTableMaster', ftConfigData, o_errList, v_reportData, i_continue);
IF NOT i_continue THEN
RETURN v_reportData;
END IF;
END IF;
RETURN v_reportData;
END ValidateEPMFamilyTableMasters;
FUNCTION  ValidateEPMFeatureValues (i_valueList IN TABLE_OF_NUMBER,ftConfigData IN OUT FTVAL_CONFIG_TABLE ) RETURN FT_REPORT_DATA IS
v_sqltext VARCHAR2(2000);
v_oid     TABLE_OF_NUMBER;
v_count   TABLE_OF_NUMBER;
i_continue  BOOLEAN;
o_errList FT_STATUS_TABLE;
v_reportData   FT_REPORT_DATA;
BEGIN
o_errList := new FT_STATUS_TABLE();
v_reportData := new FT_REPORT_DATA();
i_continue := FALSE;
FTValidator_Helper_PK.should_validate_error(20260, 'wt.epm.familytable.EPMFeatureValue', ftConfigData , i_continue);
IF i_continue = TRUE THEN
-- ensure there is no other feature value of the same name in the associated document
v_sqltext := 'SELECT A.IDA2A2 FROM EPMFeatureValue A  WHERE A.IDA2A2 ' || getWhereClause( i_valueList, 1) || '  AND   EXISTS ( SELECT ''x'' FROM EPMFeatureValue B WHERE B.IDA2A2 <> A.IDA2A2 AND B.NAME = A.NAME AND B.IDA3A4 = A.IDA3A4 )';
EXECUTE IMMEDIATE v_sqltext BULK COLLECT INTO v_oid USING i_valueList;
FOR i IN 1 .. v_oid.count LOOP
o_errList.extend();
o_errList(o_errList.LAST) := new FT_STATUS('wt.epm.familytable.EPMFeatureValue', v_oid(i), 20260);
END LOOP;
FTValidator_Helper_PK.record_errors(20260, 'wt.epm.familytable.EPMFeatureValue', ftConfigData, o_errList, v_reportData, i_continue);
IF NOT i_continue THEN
RETURN v_reportData;
END IF;
END IF;
o_errList := new FT_STATUS_TABLE();
FTValidator_Helper_PK.should_validate_error(20250, 'wt.epm.familytable.EPMFeatureValue', ftConfigData , i_continue);
IF i_continue = TRUE THEN
-- ensure the family table master has epmfeature definition with the same name.
v_sqltext := 'SELECT A.IDA2A2 FROM EPMFeatureValue A  WHERE A.IDA2A2 ' || getWhereClause( i_valueList, 1) || '  AND NOT EXISTS ( SELECT ''x'' FROM EPMContainedIn B, EPMSepFamilyTable C, EPMFeatureDefinition D  WHERE B.IDA3A5 = A.IDA3A4  AND C.IDA2A2 = B.IDA3B5  AND C.IDA3MASTERREFERENCE = D.IDA3A3  AND D.NAME = A.NAME)';
EXECUTE IMMEDIATE v_sqltext BULK COLLECT INTO v_oid USING i_valueList;
FOR i IN 1 .. v_oid.count LOOP
o_errList.extend();
o_errList(o_errList.LAST) := new FT_STATUS('wt.epm.familytable.EPMFeatureValue', v_oid(i), 20250);
END LOOP;
FTValidator_Helper_PK.record_errors(20250, 'wt.epm.familytable.EPMFeatureValue', ftConfigData, o_errList, v_reportData, i_continue);
IF NOT i_continue THEN
RETURN v_reportData;
END IF;
END IF;
RETURN v_reportData;
END ValidateEPMFeatureValues;
FUNCTION  ValidateEPMParameterValues (i_valueList IN TABLE_OF_NUMBER,ftConfigData IN OUT FTVAL_CONFIG_TABLE ) RETURN FT_REPORT_DATA IS
v_sqltext VARCHAR2(2000);
v_oid       TABLE_OF_NUMBER;
v_count     TABLE_OF_NUMBER;
i_continue  BOOLEAN;
o_errList   FT_STATUS_TABLE;
v_reportData   FT_REPORT_DATA;
BEGIN
o_errList := new FT_STATUS_TABLE();
v_reportData := new FT_REPORT_DATA();
i_continue := FALSE;
FTValidator_Helper_PK.should_validate_error(20280, 'wt.epm.familytable.EPMParameterValue', ftConfigData , i_continue);
IF i_continue = TRUE THEN
-- ensure there is no other parameter value of the same name in the associated document
v_sqltext := 'SELECT A.IDA2A2 FROM EPMParameterValue A  WHERE A.IDA2A2 ' || getWhereClause( i_valueList, 1) || '  AND   EXISTS ( SELECT ''x'' FROM EPMParameterValue B WHERE B.IDA2A2 <> A.IDA2A2 AND B.NAME = A.NAME AND B.IDA3A4 = A.IDA3A4 )';
EXECUTE IMMEDIATE v_sqltext BULK COLLECT INTO v_oid USING i_valueList;
FOR i IN 1 .. v_oid.count LOOP
o_errList.extend();
o_errList(o_errList.LAST) := new FT_STATUS('wt.epm.familytable.EPMParameterValue', v_oid(i), 20280);
END LOOP;
FTValidator_Helper_PK.record_errors(20280, 'wt.epm.familytable.EPMParameterValue', ftConfigData, o_errList, v_reportData, i_continue);
IF NOT i_continue THEN
RETURN v_reportData;
END IF;
END IF;
o_errList := new FT_STATUS_TABLE();
FTValidator_Helper_PK.should_validate_error(20270, 'wt.epm.familytable.EPMParameterValue', ftConfigData , i_continue);
IF i_continue = TRUE THEN
-- ensure the family table master has epmParameter definition with the same name.
v_sqltext := 'SELECT A.IDA2A2 FROM EPMParameterValue A  WHERE A.IDA2A2 ' || getWhereClause( i_valueList, 1) || '  AND NOT EXISTS ( SELECT ''x'' FROM EPMContainedIn B, EPMSepFamilyTable C, EPMParameterDefinition D  WHERE B.IDA3A5 = A.IDA3A4  AND C.IDA2A2 = B.IDA3B5  AND C.IDA3MASTERREFERENCE = D.IDA3A3  AND D.NAME = A.NAME)';
EXECUTE IMMEDIATE v_sqltext BULK COLLECT INTO v_oid USING i_valueList;
FOR i IN 1 .. v_oid.count LOOP
o_errList.extend();
o_errList(o_errList.LAST) := new FT_STATUS('wt.epm.familytable.EPMParameterValue', v_oid(i), 20270);
END LOOP;
FTValidator_Helper_PK.record_errors(20270, 'wt.epm.familytable.EPMParameterValue', ftConfigData, o_errList, v_reportData, i_continue);
IF NOT i_continue THEN
RETURN v_reportData;
END IF;
END IF;
RETURN v_reportData;
END ValidateEPMParameterValues;
FUNCTION  ValidateEPMFTColumns (i_tableName IN VARCHAR2, i_columnList IN TABLE_OF_NUMBER,ftConfigData IN OUT FTVAL_CONFIG_TABLE ) RETURN FT_REPORT_DATA IS
v_sqltext      VARCHAR2(2000);
v_classname    TABLE_OF_VARCHAR2_200;
v_oid          TABLE_OF_NUMBER;
v_count        TABLE_OF_NUMBER;
v_column_count TABLE_OF_NUMBER;
i_continue     BOOLEAN;
i_className    VARCHAR2(200);
o_errList	   FT_STATUS_TABLE;
v_reportData   FT_REPORT_DATA;
BEGIN
v_reportData := new FT_REPORT_DATA();
i_continue := FALSE;
FOR j IN 1 .. FTCELL_TABLES.COUNT LOOP
v_oid := NULL;
o_errList := new FT_STATUS_TABLE();
IF i_tableName IS NOT NULL THEN
IF (UPPER(i_tableName) IN ('EPMFAMILYTABLEATTRIBUTE', 'EPMFAMILYTABLEPARAMETER', 'EPMFAMILYTABLEFEATURE' ) AND UPPER(FTCELL_TABLES(j)) = 'EPMFAMILYTABLECELL') OR
(UPPER(i_tableName) IN ('EPMFAMILYTABLEMEMBER', 'EPMFAMILYTABLEREFERENCE') AND UPPER(FTCELL_TABLES(j)) = 'EPMFAMILYTABLECELLDEP')  THEN
i_className := getClassName(i_tableName);
v_oid := NULL;
o_errList := new FT_STATUS_TABLE();
-- ensure there is only one cell with definedHere flag set to 1, for each column
FTValidator_Helper_PK.should_validate_error(20290, 'wt.epm.familytable.EPMFamilyTableColumn', ftConfigData , i_continue);
IF i_continue = TRUE THEN
v_sqltext := 'SELECT CT.CLASSNAMEA2A2, CT.IDA2A2 FROM ' || FTCELL_TABLES(j) || ' A, ' || i_tableName || ' CT WHERE A.IDA3B3 = CT.IDA2A2 GROUP BY CT.CLASSNAMEA2A2, CT.IDA2A2 HAVING SUM(A.DEFINEDHERE) = 0';
EXECUTE IMMEDIATE v_sqltext BULK COLLECT INTO v_classname, v_oid;
IF v_oid IS NOT NULL THEN
FOR i IN 1 .. v_oid.count LOOP
o_errList.extend();
o_errList(o_errList.LAST) := new FT_STATUS(v_classname(i), v_oid(i), 20290);
END LOOP;
END IF;
FTValidator_Helper_PK.record_errors(20290, 'wt.epm.familytable.EPMFamilyTableColumn', ftConfigData, o_errList, v_reportData, i_continue);
IF NOT i_continue THEN
RETURN v_reportData;
END IF;
END IF;
v_oid := NULL;
o_errList := new FT_STATUS_TABLE();
-- ensure the immediate instances have cells for the column
FTValidator_Helper_PK.should_validate_error(20310, 'wt.epm.familytable.EPMFamilyTableColumn', ftConfigData , i_continue);
IF i_continue = TRUE THEN
v_sqltext := 'SELECT X.COL_CLS, X.COL_ID, COUNT(*), SUM(NVL2(F.IDA2A2, 1, 0)) FROM ( SELECT CT.CLASSNAMEA2A2 "COL_CLS", CT.IDA2A2 "COL_ID", E.IDA2A2 FROM ' || FTCELL_TABLES(j) || ' A ,EPMContainedIn B, EPMDocument C, EPMVariantLink D, EPMContainedin E, ' || i_tableName || ' CT  WHERE A.IDA3B3 = CT.IDA2A2 AND A.DEFINEDHERE = 1 AND A.IDA3A3 = B.IDA2A2 AND B.IDA3A5 = C.IDA2A2 AND C.FAMILYTABLESTATUS > 1 AND C.IDA3MASTERREFERENCE = D.IDA3B5 AND D.IDA3A5 = E.IDA3A5 AND B.IDA3B5 = E.IDA3B5 ) X, ' || FTCELL_TABLES(j) || ' F WHERE X.COL_ID = F.IDA3B3 (+) AND X.IDA2A2 = F.IDA3A3(+) GROUP BY X.COL_CLS, X.COL_ID HAVING COUNT(*) <> SUM(NVL2(F.IDA2A2, 1, 0))';
EXECUTE IMMEDIATE v_sqltext BULK COLLECT INTO v_classname, v_oid, v_count, v_column_count;
IF v_oid IS NOT NULL THEN
FOR i IN 1 .. v_oid.count LOOP
o_errList.extend();
o_errList(o_errList.LAST) := new FT_STATUS(v_classname(i), v_oid(i), 20310);
END LOOP;
END IF;
FTValidator_Helper_PK.record_errors(20310, 'wt.epm.familytable.EPMFamilyTableColumn', ftConfigData, o_errList, v_reportData, i_continue);
IF NOT i_continue THEN
RETURN v_reportData;
END IF;
END IF;
v_oid := NULL;
o_errList := new FT_STATUS_TABLE();
-- ensure there is only one cell with definedHere flag set to 1, for each column
FTValidator_Helper_PK.should_validate_error(20460, 'wt.epm.familytable.EPMFamilyTableColumn', ftConfigData , i_continue);
IF i_continue = TRUE THEN
v_sqltext := 'SELECT col.classNameA2A2, col.idA2A2 FROM ' || FTCELL_TABLES(j) || ' cell, ' || i_tableName || ' col, EPMContainedIn ci where ci.idA2A2 = cell.idA3A3 and col.idA2A2 = cell.idA3B3 and ci.idA3B5 <> col.idA3A3';
EXECUTE IMMEDIATE v_sqltext BULK COLLECT INTO v_classname, v_oid;
IF v_oid IS NOT NULL THEN
FOR i IN 1 .. v_oid.count LOOP
o_errList.extend();
o_errList(o_errList.LAST) := new FT_STATUS(v_classname(i), v_oid(i), 20460);
END LOOP;
END IF;
FTValidator_Helper_PK.record_errors(20460, 'wt.epm.familytable.EPMFamilyTableColumn', ftConfigData, o_errList, v_reportData, i_continue);
IF NOT i_continue THEN
RETURN v_reportData;
END IF;
END IF;
END IF;
ELSE
v_oid := NULL;
o_errList := new FT_STATUS_TABLE();
-- ensure there is only one cell with definedHere flag set to 1, for each column
FTValidator_Helper_PK.should_validate_error(20290, 'wt.epm.familytable.EPMFamilyTableColumn', ftConfigData , i_continue);
IF i_continue = TRUE THEN
v_sqltext := 'SELECT A.CLASSNAMEKEYB3, A.IDA3B3 FROM ' || FTCELL_TABLES(j) || ' A  WHERE A.IDA3B3 ' || getWhereClause( i_columnList, 1) || '  GROUP BY A.CLASSNAMEKEYB3, A.IDA3B3 HAVING SUM(A.DEFINEDHERE) = 0';
EXECUTE IMMEDIATE v_sqltext BULK COLLECT INTO v_classname, v_oid USING i_columnList;
IF v_oid IS NOT NULL THEN
FOR i IN 1 .. v_oid.count LOOP
o_errList.extend();
o_errList(o_errList.LAST) := new FT_STATUS(v_classname(i), v_oid(i), 20290);
END LOOP;
END IF;
FTValidator_Helper_PK.record_errors(20290, 'wt.epm.familytable.EPMFamilyTableColumn', ftConfigData, o_errList, v_reportData, i_continue);
IF NOT i_continue THEN
RETURN v_reportData;
END IF;
END IF;
v_oid := NULL;
o_errList := new FT_STATUS_TABLE();
-- ensure the immediate instances have cells for the column
FTValidator_Helper_PK.should_validate_error(20310, 'wt.epm.familytable.EPMFamilyTableColumn', ftConfigData , i_continue);
IF i_continue = TRUE THEN
v_sqltext := 'SELECT X.CLASSNAMEKEYB3, X.IDA3B3, COUNT(*), SUM(NVL2(F.IDA2A2, 1, 0)) FROM ( SELECT A.CLASSNAMEKEYB3, A.IDA3B3, E.IDA2A2 FROM ' || FTCELL_TABLES(j) || ' A ,EPMContainedIn B, EPMDocument C, EPMVariantLink D, EPMContainedin E  WHERE A.IDA3B3 ' || getWhereClause( i_columnList, 1) || ' AND A.DEFINEDHERE = 1 AND A.IDA3A3 = B.IDA2A2 AND B.IDA3A5 = C.IDA2A2 AND C.FAMILYTABLESTATUS > 1 AND C.IDA3MASTERREFERENCE = D.IDA3B5 AND D.IDA3A5 = E.IDA3A5 AND B.IDA3B5 = E.IDA3B5 ) X, ' || FTCELL_TABLES(j) || ' F WHERE X.IDA3B3 = F.IDA3B3 (+) AND X.IDA2A2 = F.IDA3A3(+) GROUP BY X.CLASSNAMEKEYB3, X.IDA3B3 HAVING COUNT(*) <> SUM(NVL2(F.IDA2A2, 1, 0))' ;
EXECUTE IMMEDIATE v_sqltext BULK COLLECT INTO v_classname, v_oid, v_count, v_column_count USING i_columnList;
IF v_oid IS NOT NULL THEN
FOR i IN 1 .. v_oid.count LOOP
o_errList.extend();
o_errList(o_errList.LAST) := new FT_STATUS(v_classname(i), v_oid(i), 20310);
END LOOP;
END IF;
FTValidator_Helper_PK.record_errors(20310, 'wt.epm.familytable.EPMFamilyTableColumn', ftConfigData, o_errList, v_reportData, i_continue);
IF NOT i_continue THEN
RETURN v_reportData;
END IF;
END IF;
v_oid := NULL;
o_errList := new FT_STATUS_TABLE();
-- ensure the column and CI are poiting to same FT object (COL-CI FT MISMATCH)
FTValidator_Helper_PK.should_validate_error(20460, 'wt.epm.familytable.EPMFamilyTableColumn', ftConfigData , i_continue);
IF i_continue = TRUE THEN
IF UPPER(FTCELL_TABLES(j)) = 'EPMFAMILYTABLECELL' THEN
v_sqltext := 'SELECT cell.classNameKeyB3, col.idA2A2 FROM ' || FTCELL_TABLES(j) || ' cell, (select idA2A2, idA3A3 from EPMFamilyTableParameter Union All select idA2A2, idA3A3 from EPMFamilyTableFeature Union All select idA2A2, idA3A3 from EPMFamilyTableAttribute) col, EPMContainedIn ci where col.idA2A2 ' || getWhereClause( i_columnList, 1) || ' and ci.idA2A2 = cell.idA3A3 and col.idA2A2 = cell.idA3B3 and ci.idA3B5 <> col.idA3A3';
ELSE
v_sqltext := 'SELECT cell.classNameKeyB3, col.idA2A2 FROM ' || FTCELL_TABLES(j) || ' cell, (select idA2A2, idA3A3 from EPMFamilyTableMember Union All select idA2A2, idA3A3 from EPMFamilyTableReference) col, EPMContainedIn ci where col.idA2A2 ' || getWhereClause( i_columnList, 1) || ' and ci.idA2A2 = cell.idA3A3 and col.idA2A2 = cell.idA3B3 and ci.idA3B5 <> col.idA3A3';
END IF;
EXECUTE IMMEDIATE v_sqltext BULK COLLECT INTO v_classname, v_oid USING i_columnList;
IF v_oid IS NOT NULL THEN
FOR i IN 1 .. v_oid.count LOOP
o_errList.extend();
o_errList(o_errList.LAST) := new FT_STATUS(v_classname(i), v_oid(i), 20460);
END LOOP;
END IF;
FTValidator_Helper_PK.record_errors(20460, 'wt.epm.familytable.EPMFamilyTableColumn', ftConfigData, o_errList, v_reportData, i_continue);
IF NOT i_continue THEN
RETURN v_reportData;
END IF;
END IF;
END IF;
END LOOP;
RETURN v_reportData;
END ValidateEPMFTColumns;
FUNCTION  ValidateEPMFTColumns (i_columnList IN TABLE_OF_NUMBER,ftConfigData IN OUT FTVAL_CONFIG_TABLE ) RETURN FT_REPORT_DATA IS
BEGIN
RETURN ValidateEPMFTColumns (NULL, i_columnList, ftConfigData);
END ValidateEPMFTColumns;
FUNCTION  ValidateEPMFTCells (i_tableName IN VARCHAR2, i_cellList IN TABLE_OF_NUMBER, ftConfigData IN OUT FTVAL_CONFIG_TABLE ) RETURN FT_REPORT_DATA IS
v_sqltext      VARCHAR2(2000);
v_classname    TABLE_OF_VARCHAR2_200;
v_oid          TABLE_OF_NUMBER;
v_columns      TABLE_OF_NUMBER;
v_variants     TABLE_OF_NUMBER;
v_error        NUMBER;
i_continue     BOOLEAN;
i_className    VARCHAR2(200);
v_count        TABLE_OF_NUMBER;
v_column_count TABLE_OF_NUMBER;
o_errList	   FT_STATUS_TABLE;
v_reportData   FT_REPORT_DATA;
BEGIN
o_errList := new FT_STATUS_TABLE();
v_reportData := new FT_REPORT_DATA();
i_continue := FALSE;
IF i_tableName IS NOT NULL THEN
i_className := getClassName(i_tableName);
v_oid := NULL;
o_errList := new FT_STATUS_TABLE();
-- ensure cells with definedHere flag set to 1 are associated to generics
FTValidator_Helper_PK.should_validate_error(20320, 'wt.epm.familytable.EPMFamilyTableCell', ftConfigData , i_continue);
IF i_continue = TRUE THEN
v_sqltext := 'SELECT A.CLASSNAMEA2A2, A.IDA2A2  FROM ' || i_tableName ||' A  WHERE A.definedHere = 1  AND NOT EXISTS (SELECT ''x''  FROM EPMContainedin B, EPMDocument C  WHERE B.IDA2A2 = A.IDA3A3  AND C.IDA2A2 = B.IDA3A5  AND C.FAMILYTABLESTATUS >= 2)';
EXECUTE IMMEDIATE v_sqltext BULK COLLECT INTO v_classname, v_oid;
IF v_oid IS NOT NULL THEN
FOR i IN 1 .. v_oid.count LOOP
o_errList.extend();
o_errList(o_errList.LAST) := new FT_STATUS(v_classname(i), v_oid(i), 20320);
END LOOP;
END IF;
FTValidator_Helper_PK.record_errors(20320, 'wt.epm.familytable.EPMFamilyTableCell', ftConfigData, o_errList, v_reportData, i_continue);
IF NOT i_continue THEN
RETURN v_reportData;
END IF;
END IF;
v_oid := NULL;
o_errList := new FT_STATUS_TABLE();
-- ensure that there is no other cell between the same two objects (same containedin link and column
FTValidator_Helper_PK.should_validate_error(20340, 'wt.epm.familytable.EPMFamilyTableCell', ftConfigData , i_continue);
IF i_continue = TRUE THEN
v_sqltext := 'SELECT A.CLASSNAMEA2A2, A.IDA2A2  FROM ' || i_tableName || ' A, ' || i_tableName || ' B  WHERE A.IDA3A3 = B.IDA3A3  AND A.IDA3B3 = B.IDA3B3  AND A.IDA2A2 <> B.IDA2A2';
EXECUTE IMMEDIATE v_sqltext BULK COLLECT INTO v_classname, v_oid;
IF v_oid IS NOT NULL THEN
FOR i IN 1 .. v_oid.count LOOP
-- dbms_output.put_line('Cell id : ' || v_oid(i));
o_errList.extend();
o_errList(o_errList.LAST) := new FT_STATUS(v_classname(i), v_oid(i), 20340);
END LOOP;
END IF;
FTValidator_Helper_PK.record_errors(20340, 'wt.epm.familytable.EPMFamilyTableCell', ftConfigData, o_errList, v_reportData, i_continue);
IF NOT i_continue THEN
RETURN v_reportData;
END IF;
END IF;
v_oid := NULL;
o_errList := new FT_STATUS_TABLE();
-- ensure cells with definedHere flag set to 0 have column defined at top level generic
FTValidator_Helper_PK.should_validate_error(20330, i_className, ftConfigData , i_continue);
IF i_continue = TRUE THEN
v_sqltext := 'SELECT A.IDA2A2, A.CLASSNAMEA2A2
FROM ' || i_tableName ||' A, EPMContainedin B, EPMVariantLink F
WHERE A.DEFINEDHERE = 0
AND A.IDA3A3 = B.IDA2A2
AND F.IDA3A5 = B.IDA3A5
AND NOT EXISTS ( SELECT C.IDA2A2
FROM  ' || i_tableName ||'  C, EPMContainedin D, EPMDocument E
WHERE  A.IDA3B3 = C.IDA3B3
AND C.DEFINEDHERE = 1
AND D.IDA2A2 = C.IDA3A3
AND E.IDA2A2 = D.IDA3A5
AND E.FAMILYTABLESTATUS >= 2
AND F.IDA3B5 = E.IDA3MASTERREFERENCE
)';
EXECUTE IMMEDIATE v_sqltext BULK COLLECT INTO v_oid, v_classname;
IF v_oid IS NOT NULL THEN
FOR i IN 1 .. v_oid.count LOOP
o_errList.extend();
o_errList(o_errList.LAST) := new FT_STATUS(v_classname(i), v_oid(i), 20330);
END LOOP;
END IF;
FTValidator_Helper_PK.record_errors(20330, i_className, ftConfigData, o_errList, v_reportData, i_continue);
IF NOT i_continue THEN
RETURN v_reportData;
END IF;
END IF;
IF UPPER(i_tableName) = 'EPMFAMILYTABLECELLDEP' THEN
v_oid := NULL;
o_errList := new FT_STATUS_TABLE();
-- ensure cells are having Memberlink for the associated EPMFamilyTableMember column
FTValidator_Helper_PK.should_validate_error(20470, 'wt.epm.familytable.EPMFamilyTableCellDependency', ftConfigData , i_continue);
IF i_continue = TRUE THEN
v_sqltext := 'select cell.idA2A2 from ' || i_tableName || ' cell, EPMContainedIn ci ' ||
'where cell.idA3A3 = ci.idA2A2 and cell.classnamekeyB3=''wt.epm.familytable.EPMFamilyTableMember'' and not exists (select ''x'' from EPMMemberLink ml where ml.idA3A5=ci.idA3A5 and ml.uniqueNDId = cell.uniqueId)';
EXECUTE IMMEDIATE v_sqltext BULK COLLECT INTO v_oid;
IF v_oid IS NOT NULL THEN
FOR i IN 1 .. v_oid.count LOOP
o_errList.extend();
-- Todo - Problem
o_errList(o_errList.LAST) := new FT_STATUS('wt.epm.familytable.EPMFamilyTableCellDependency', v_oid(i), 20470);
END LOOP;
END IF;
FTValidator_Helper_PK.record_errors(20470, 'wt.epm.familytable.EPMFamilyTableCellDependency', ftConfigData, o_errList, v_reportData, i_continue);
IF NOT i_continue THEN
RETURN v_reportData;
END IF;
END IF;
v_oid := NULL;
o_errList := new FT_STATUS_TABLE();
-- ensure cells are having Referencelink for the associated EPMFamilyTableReference column
FTValidator_Helper_PK.should_validate_error(20480, 'wt.epm.familytable.EPMFamilyTableCellDependency', ftConfigData , i_continue);
IF i_continue = TRUE THEN
v_sqltext := 'select cell.idA2A2 from ' || i_tableName || ' cell, EPMContainedIn ci, EPMDocument ed ' ||
'where cell.idA3A3 = ci.idA2A2 and ed.idA2A2=ci.idA3A5 and cell.classnamekeyB3=''wt.epm.familytable.EPMFamilyTableReference'' and not exists (select ''x'' from EPMReferenceLink ml where ml.idA3A5=ed.idA2A2 and ml.uniqueNDId = cell.uniqueId)';
EXECUTE IMMEDIATE v_sqltext BULK COLLECT INTO v_oid;
IF v_oid IS NOT NULL THEN
FOR i IN 1 .. v_oid.count LOOP
o_errList.extend();
-- Todo - Problem
o_errList(o_errList.LAST) := new FT_STATUS('wt.epm.familytable.EPMFamilyTableCellDependency', v_oid(i), 20480);
END LOOP;
END IF;
FTValidator_Helper_PK.record_errors(20480, 'wt.epm.familytable.EPMFamilyTableCellDependency', ftConfigData, o_errList, v_reportData, i_continue);
IF NOT i_continue THEN
RETURN v_reportData;
END IF;
END IF;
ELSE          --  i_tableName = 'EPMFAMILYTABLECELL'
v_oid := NULL;
o_errList := new FT_STATUS_TABLE();
-- ensure cells are having Parameter value for the associated EPMFamilyTableParameter column
FTValidator_Helper_PK.should_validate_error(20490, 'wt.epm.familytable.EPMFamilyTableCell', ftConfigData , i_continue);
IF i_continue = TRUE THEN
v_sqltext := 'select cell.idA2A2 from ' || i_tableName || ' cell, EPMContainedIn ci, EPMFamilyTableParameter col ' ||
'where cell.idA3B3=col.idA2A2 and cell.idA3A3=ci.idA2A2 ' ||
'and NOT EXISTS ( select ''x'' from EPMParameterValue pv where pv.idA3A4=ci.idA3A5 and pv.name=col.name)';
EXECUTE IMMEDIATE v_sqltext BULK COLLECT INTO v_oid;
IF v_oid IS NOT NULL THEN
FOR i IN 1 .. v_oid.count LOOP
o_errList.extend();
-- Todo - Problem
o_errList(o_errList.LAST) := new FT_STATUS('wt.epm.familytable.EPMFamilyTableCell', v_oid(i), 20490);
END LOOP;
END IF;
FTValidator_Helper_PK.record_errors(20490, 'wt.epm.familytable.EPMFamilyTableCell', ftConfigData, o_errList, v_reportData, i_continue);
IF NOT i_continue THEN
RETURN v_reportData;
END IF;
END IF;
v_oid := NULL;
o_errList := new FT_STATUS_TABLE();
-- ensure cells are having Feature value for the associated EPMFamilyTableFeature column
FTValidator_Helper_PK.should_validate_error(20500, 'wt.epm.familytable.EPMFamilyTableCell', ftConfigData , i_continue);
IF i_continue = TRUE THEN
v_sqltext := 'select cell.idA2A2 from ' || i_tableName || ' cell, EPMContainedIn ci, EPMFamilyTableFeature col ' ||
'where cell.idA3B3=col.idA2A2 and cell.idA3A3=ci.idA2A2 ' ||
'and NOT EXISTS ( select ''x'' from EPMFeatureValue fv where fv.idA3A4=ci.idA3A5 and fv.name=col.name)';
EXECUTE IMMEDIATE v_sqltext BULK COLLECT INTO v_oid;
IF v_oid IS NOT NULL THEN
FOR i IN 1 .. v_oid.count LOOP
o_errList.extend();
-- Todo - Problem
o_errList(o_errList.LAST) := new FT_STATUS('wt.epm.familytable.EPMFamilyTableCell', v_oid(i), 20500);
END LOOP;
END IF;
FTValidator_Helper_PK.record_errors(20500, 'wt.epm.familytable.EPMFamilyTableCell', ftConfigData, o_errList, v_reportData, i_continue);
IF NOT i_continue THEN
RETURN v_reportData;
END IF;
END IF;
v_oid := NULL;
o_errList := new FT_STATUS_TABLE();
-- ensure cells are having Attribute value for the associated EPMFamilyTableAttribute column
FTValidator_Helper_PK.should_validate_error(20510, 'wt.epm.familytable.EPMFamilyTableCell', ftConfigData , i_continue);
IF i_continue = TRUE THEN
v_sqltext := 'select ftcol.idA2A2 '||
'from ( select cell.ida2a2, col.name, ci.ida3a5 '||
'   from EPMContainedIn ci, EPMFamilyTableAttribute col, ' || i_tableName || ' cell '||
'  	where col.idA3A3 = ci.idA3B5 and   cell.idA3B3 = col.idA2A2 and   cell.idA3A3 = ci.idA2A2 ) ftcol '||
'  left join ( select pmap.ida3a4, pmap.parameterName, ibadef.name '||
'  		from EPMParameterMap pmap, ' ||
'			( select ida2a2, name from StringDefinition  union all '||
'                         select ida2a2, name from IntegerDefinition union all '||
'                         select ida2a2, name from FloatDefinition   union all '||
'                         select ida2a2, name from BooleanDefinition union all '||
'                         select ida2a2, name from UnitDefinition union all '||
'                         select ida2a2, name from TimeStampDefinition '||
'			) ibadef '||
'   		where pmap.ida3b4 = ibadef.ida2a2 '||
'	     ) map on ftcol.name = map.parameterName and ftcol.ida3a5 = map.idA3A4 '||
' where not exists(select 1 from '||
'       		(select sv.idA3A4, sv.idA3A6, sd.name from StringValue sv, StringDefinition sd where sv.idA3A6=sd.idA2A2 Union all  '||
'               	 select intv.idA3A4, intv.idA3A6, intd.name from IntegerValue intv, IntegerDefinition intd where intv.idA3A6=intd.idA2A2 Union all  '||
'                 	 select fv.idA3A4, fv.idA3A6, fd.name from FloatValue fv, FloatDefinition fd where fv.idA3A6=fd.idA2A2 Union all  '||
'                 	 select bv.idA3A4, bv.idA3A6, bd.name from BooleanValue bv, BooleanDefinition bd where bv.idA3A6=bd.idA2A2 Union all  '||
'                 	 select uv.idA3A4, uv.idA3A6, ud.name from UnitValue uv, UnitDefinition ud where uv.idA3A6=ud.idA2A2 Union all  '||
'                 	 select tsv.idA3A4, tsv.idA3A6, tsd.name from TimeStampValue tsv, TimeStampDefinition tsd where tsv.idA3A6=tsd.idA2A2) attrvalue '||
'    	     	   where attrvalue.ida3a4 = ftcol.ida3a5 '||
'    	     	    and attrvalue.name = nvl(map.name, ftcol.name) '||
'    	   	)';
EXECUTE IMMEDIATE v_sqltext BULK COLLECT INTO v_oid;
IF v_oid IS NOT NULL THEN
FOR i IN 1 .. v_oid.count LOOP
o_errList.extend();
-- Todo - Problem
o_errList(o_errList.LAST) := new FT_STATUS('wt.epm.familytable.EPMFamilyTableCell', v_oid(i), 20510);
END LOOP;
END IF;
FTValidator_Helper_PK.record_errors(20510, 'wt.epm.familytable.EPMFamilyTableCell', ftConfigData, o_errList, v_reportData, i_continue);
IF NOT i_continue THEN
RETURN v_reportData;
END IF;
END IF;
END IF;
ELSE
FOR j IN 1 .. FTCELL_TABLES.COUNT LOOP
v_oid := NULL;
o_errList := new FT_STATUS_TABLE();
i_className := getClassname(FTCELL_TABLES(j));
-- ensure cells with definedHere flag set to 1 are associated to generics
FTValidator_Helper_PK.should_validate_error(20320, 'wt.epm.familytable.EPMFamilyTableCell', ftConfigData , i_continue);
IF i_continue = TRUE THEN
v_sqltext := 'SELECT A.CLASSNAMEA2A2, A.IDA2A2  FROM ' || FTCELL_TABLES(j) ||' A  WHERE A.IDA2A2 ' || getWhereClause( i_cellList, 1) || '  AND A.definedHere = 1  AND NOT EXISTS (SELECT ''x''  FROM EPMContainedin B, EPMDocument C  WHERE B.IDA2A2 = A.IDA3A3  AND C.IDA2A2 = B.IDA3A5  AND C.FAMILYTABLESTATUS >= 2)';
EXECUTE IMMEDIATE v_sqltext BULK COLLECT INTO v_classname, v_oid USING i_cellList;
IF v_oid IS NOT NULL THEN
FOR i IN 1 .. v_oid.count LOOP
o_errList.extend();
o_errList(o_errList.LAST) := new FT_STATUS(v_classname(i), v_oid(i), 20320);
END LOOP;
END IF;
FTValidator_Helper_PK.record_errors(20320, 'wt.epm.familytable.EPMFamilyTableCell', ftConfigData, o_errList, v_reportData, i_continue);
IF NOT i_continue THEN
RETURN v_reportData;
END IF;
END IF;
v_oid := NULL;
o_errList := new FT_STATUS_TABLE();
-- ensure that there is no other cell between the same two objects (same containedin link and column
FTValidator_Helper_PK.should_validate_error(20340, 'wt.epm.familytable.EPMFamilyTableCell', ftConfigData , i_continue);
IF i_continue = TRUE THEN
v_sqltext := 'SELECT A.CLASSNAMEA2A2, A.IDA2A2  FROM ' || FTCELL_TABLES(j) || ' A, ' || FTCELL_TABLES(j) || ' B  WHERE A.IDA2A2 ' || getWhereClause( i_cellList, 1 ) || '  AND A.IDA3A3 = B.IDA3A3  AND A.IDA3B3 = B.IDA3B3  AND A.IDA2A2 <> B.IDA2A2';
EXECUTE IMMEDIATE v_sqltext BULK COLLECT INTO v_classname, v_oid USING i_cellList;
IF v_oid IS NOT NULL THEN
FOR i IN 1 .. v_oid.count LOOP
-- dbms_output.put_line('Cell id : ' || v_oid(i));
o_errList.extend();
o_errList(o_errList.LAST) := new FT_STATUS(v_classname(i), v_oid(i), 20340);
END LOOP;
END IF;
FTValidator_Helper_PK.record_errors(20340, 'wt.epm.familytable.EPMFamilyTableCell', ftConfigData, o_errList, v_reportData, i_continue);
IF NOT i_continue THEN
RETURN v_reportData;
END IF;
END IF;
v_oid := NULL;
o_errList := new FT_STATUS_TABLE();
-- ensure cells with definedHere flag set to 0 have column defined at top level generic
FTValidator_Helper_PK.should_validate_error(20330, i_className, ftConfigData , i_continue);
IF i_continue = TRUE THEN
v_sqltext := 'SELECT A.IDA2A2, A.CLASSNAMEA2A2
FROM ' || FTCELL_TABLES(j) ||' A, EPMContainedin B, EPMVariantLink F
WHERE  A.IDA2A2 ' || getWhereClause( i_cellList, 1) || '
AND A.DEFINEDHERE = 0
AND A.IDA3A3 = B.IDA2A2
AND F.IDA3A5 = B.IDA3A5
AND NOT EXISTS ( SELECT C.IDA2A2
FROM  ' || FTCELL_TABLES(j) ||'  C, EPMContainedin D, EPMDocument E
WHERE  A.IDA3B3 = C.IDA3B3
AND C.DEFINEDHERE = 1
AND D.IDA2A2 = C.IDA3A3
AND E.IDA2A2 = D.IDA3A5
AND E.FAMILYTABLESTATUS >= 2
AND F.IDA3B5 = E.IDA3MASTERREFERENCE
)';
EXECUTE IMMEDIATE v_sqltext BULK COLLECT INTO v_oid, v_classname  USING i_cellList;
IF v_oid IS NOT NULL THEN
FOR i IN 1 .. v_oid.count LOOP
o_errList.extend();
o_errList(o_errList.LAST) := new FT_STATUS(v_classname(i), v_oid(i), 20330);
END LOOP;
END IF;
FTValidator_Helper_PK.record_errors(20330, i_className, ftConfigData, o_errList, v_reportData, i_continue);
IF NOT i_continue THEN
RETURN v_reportData;
END IF;
END IF;
IF UPPER(FTCELL_TABLES(j)) = 'EPMFAMILYTABLECELLDEP' THEN
v_oid := NULL;
o_errList := new FT_STATUS_TABLE();
-- ensure cells are having Memberlink for the associated EPMFamilyTableMember column
FTValidator_Helper_PK.should_validate_error(20470, 'wt.epm.familytable.EPMFamilyTableCellDependency', ftConfigData , i_continue);
IF i_continue = TRUE THEN
v_sqltext := 'select cell.idA2A2 from ' || FTCELL_TABLES(j) || ' cell, EPMContainedIn ci ' ||
'where cell.idA2A2 ' || getWhereClause( i_cellList, 1) || ' and cell.idA3A3 = ci.idA2A2 and cell.classnamekeyB3=''wt.epm.familytable.EPMFamilyTableMember'' and not exists (select ''x'' from EPMMemberLink ml where ml.idA3A5=ci.idA3A5 and ml.uniqueNDId = cell.uniqueId)';
EXECUTE IMMEDIATE v_sqltext BULK COLLECT INTO v_oid USING i_cellList;
IF v_oid IS NOT NULL THEN
FOR i IN 1 .. v_oid.count LOOP
o_errList.extend();
o_errList(o_errList.LAST) := new FT_STATUS(FTCELL_TABLES(j), v_oid(i), 20470);
END LOOP;
END IF;
FTValidator_Helper_PK.record_errors(20470, 'wt.epm.familytable.EPMFamilyTableCellDependency', ftConfigData, o_errList, v_reportData, i_continue);
IF NOT i_continue THEN
RETURN v_reportData;
END IF;
END IF;
v_oid := NULL;
o_errList := new FT_STATUS_TABLE();
-- ensure cells are having Referencelink for the associated EPMFamilyTableReference column
FTValidator_Helper_PK.should_validate_error(20480, 'wt.epm.familytable.EPMFamilyTableCellDependency', ftConfigData , i_continue);
IF i_continue = TRUE THEN
v_sqltext := 'select cell.idA2A2 from ' || FTCELL_TABLES(j) || ' cell, EPMContainedIn ci ' ||
'where cell.idA2A2 ' || getWhereClause( i_cellList, 1) || ' and cell.idA3A3 = ci.idA2A2 and cell.classnamekeyB3=''wt.epm.familytable.EPMFamilyTableReference'' and not exists (select ''x'' from EPMReferenceLink ml where ml.idA3A5=ci.idA3A5 and ml.uniqueNDId = cell.uniqueId)';
EXECUTE IMMEDIATE v_sqltext BULK COLLECT INTO v_oid USING i_cellList;
IF v_oid IS NOT NULL THEN
FOR i IN 1 .. v_oid.count LOOP
o_errList.extend();
o_errList(o_errList.LAST) := new FT_STATUS(FTCELL_TABLES(j), v_oid(i), 20480);
END LOOP;
END IF;
FTValidator_Helper_PK.record_errors(20480, 'wt.epm.familytable.EPMFamilyTableCellDependency', ftConfigData, o_errList, v_reportData, i_continue);
IF NOT i_continue THEN
RETURN v_reportData;
END IF;
END IF;
ELSE
v_oid := NULL;
o_errList := new FT_STATUS_TABLE();
-- ensure cells are having Parameter value for the associated EPMFamilyTableParameter column
FTValidator_Helper_PK.should_validate_error(20490, 'wt.epm.familytable.EPMFamilyTableCell', ftConfigData , i_continue);
IF i_continue = TRUE THEN
v_sqltext := 'select cell.idA2A2 from ' || FTCELL_TABLES(j) || ' cell, EPMContainedIn ci, EPMFamilyTableParameter col ' ||
'where cell.idA2A2 ' || getWhereClause( i_cellList, 1) || ' and cell.idA3B3=col.idA2A2 and cell.idA3A3=ci.idA2A2 ' ||
'and NOT EXISTS ( select ''x'' from EPMParameterValue pv where pv.idA3A4=ci.idA3A5 and pv.name=col.name)';
EXECUTE IMMEDIATE v_sqltext BULK COLLECT INTO v_oid USING i_cellList;
IF v_oid IS NOT NULL THEN
FOR i IN 1 .. v_oid.count LOOP
o_errList.extend();
o_errList(o_errList.LAST) := new FT_STATUS(FTCELL_TABLES(j), v_oid(i), 20490);
END LOOP;
END IF;
FTValidator_Helper_PK.record_errors(20490, 'wt.epm.familytable.EPMFamilyTableCell', ftConfigData, o_errList, v_reportData, i_continue);
IF NOT i_continue THEN
RETURN v_reportData;
END IF;
END IF;
v_oid := NULL;
o_errList := new FT_STATUS_TABLE();
-- ensure cells are having Feature value for the associated EPMFamilyTableFeature column
FTValidator_Helper_PK.should_validate_error(20500, 'wt.epm.familytable.EPMFamilyTableCell', ftConfigData , i_continue);
IF i_continue = TRUE THEN
v_sqltext := 'select cell.idA2A2 from ' || FTCELL_TABLES(j) || ' cell, EPMContainedIn ci, EPMFamilyTableFeature col ' ||
'where cell.idA2A2 ' || getWhereClause( i_cellList, 1) || ' and cell.idA3B3=col.idA2A2 and cell.idA3A3=ci.idA2A2 ' ||
'and NOT EXISTS ( select ''x'' from EPMFeatureValue fv where fv.idA3A4=ci.idA3A5 and fv.name=col.name)';
EXECUTE IMMEDIATE v_sqltext BULK COLLECT INTO v_oid USING i_cellList;
IF v_oid IS NOT NULL THEN
FOR i IN 1 .. v_oid.count LOOP
o_errList.extend();
o_errList(o_errList.LAST) := new FT_STATUS(FTCELL_TABLES(j), v_oid(i), 20500);
END LOOP;
END IF;
FTValidator_Helper_PK.record_errors(20500, 'wt.epm.familytable.EPMFamilyTableCell', ftConfigData, o_errList, v_reportData, i_continue);
IF NOT i_continue THEN
RETURN v_reportData;
END IF;
END IF;
v_oid := NULL;
o_errList := new FT_STATUS_TABLE();
-- ensure cells are having Attribute value for the associated EPMFamilyTableAttribute column
FTValidator_Helper_PK.should_validate_error(20510, 'wt.epm.familytable.EPMFamilyTableCell', ftConfigData , i_continue);
IF i_continue = TRUE THEN
v_oid := NULL;
v_sqltext := 'select ftcol.idA2A2 '||
'from ( select cell.idA2A2, col.name, ci.idA3A5 '||
'  	from EPMContainedIn ci, EPMFamilyTableAttribute col, ' || FTCELL_TABLES(j) || ' cell '||
'  	where cell.idA2A2 ' || getWhereClause( i_cellList, 1) || ' and col.idA3A3 = ci.idA3B5 and   cell.idA3B3 = col.idA2A2 and   cell.idA3A3 = ci.idA2A2 ) ftcol '||
'  left join ( select pmap.ida3a4, pmap.parameterName, ibadef.name '||
'  		from EPMParameterMap pmap, ' ||
'			( select ida2a2, name from StringDefinition  union all '||
'                         select ida2a2, name from IntegerDefinition union all '||
'                         select ida2a2, name from FloatDefinition   union all '||
'                         select ida2a2, name from BooleanDefinition union all '||
'                         select ida2a2, name from TimeStampDefinition '||
'			) ibadef '||
'   		where pmap.ida3b4 = ibadef.ida2a2 '||
'	     ) map on ftcol.name = map.parameterName and ftcol.ida3a5 = map.idA3A4 '||
' where ftcol.idA2A2 ' || getWhereClause( i_cellList, 1) ||
'  and not exists(select 1 from '||
'       		(select sv.idA3A4, sv.idA3A6, sd.name from StringValue sv, StringDefinition sd where sv.idA3A6=sd.idA2A2 Union all  '||
'               	 select intv.idA3A4, intv.idA3A6, intd.name from IntegerValue intv, IntegerDefinition intd where intv.idA3A6=intd.idA2A2 Union all  '||
'                 	 select fv.idA3A4, fv.idA3A6, fd.name from FloatValue fv, FloatDefinition fd where fv.idA3A6=fd.idA2A2 Union all  '||
'                 	 select bv.idA3A4, bv.idA3A6, bd.name from BooleanValue bv, BooleanDefinition bd where bv.idA3A6=bd.idA2A2 Union all  '||
'                 	 select tsv.idA3A4, tsv.idA3A6, tsd.name from TimeStampValue tsv, TimeStampDefinition tsd where tsv.idA3A6=tsd.idA2A2) attrvalue '||
'    	     	   where attrvalue.ida3a4 = ftcol.ida3a5 '||
'    	     	    and attrvalue.name = nvl(map.name, ftcol.name) '||
'    	   	)';
EXECUTE IMMEDIATE v_sqltext BULK COLLECT INTO v_oid USING i_cellList, i_cellList;
IF v_oid IS NOT NULL THEN
FOR i IN 1 .. v_oid.count LOOP
o_errList.extend();
o_errList(o_errList.LAST) := new FT_STATUS(FTCELL_TABLES(j), v_oid(i), 20510);
END LOOP;
END IF;
FTValidator_Helper_PK.record_errors(20510, 'wt.epm.familytable.EPMFamilyTableCell', ftConfigData, o_errList, v_reportData, i_continue);
IF NOT i_continue THEN
RETURN v_reportData;
END IF;
END IF;
END IF;
END LOOP;
END IF;
RETURN v_reportData;
END ValidateEPMFTCells;
FUNCTION  ValidateEPMFTCells (i_cellList IN TABLE_OF_NUMBER,ftConfigData IN OUT FTVAL_CONFIG_TABLE ) RETURN FT_REPORT_DATA IS
BEGIN
RETURN ValidateEPMFTCells (NULL, i_cellList, ftConfigData);
END ValidateEPMFTCells;
FUNCTION  ValidateDeletedEPMDocuments (i_docList IN TABLE_OF_NUMBER, i_checked_in_fts IN TABLE_OF_NUMBER,ftConfigData IN OUT FTVAL_CONFIG_TABLE) RETURN FT_REPORT_DATA IS
v_sqltext       VARCHAR2(2000);
v_oid           TABLE_OF_NUMBER;
o_errList	FT_STATUS_TABLE;
v_reportData    FT_REPORT_DATA;
i_continue	BOOLEAN;
BEGIN
o_errList := new FT_STATUS_TABLE();
v_reportData := new FT_REPORT_DATA();
i_continue := FALSE;
FTValidator_Helper_PK.should_validate_error(30010, 'wt.epm.structure.EPMContainedin', ftConfigData , i_continue);
IF i_continue = TRUE THEN
-- ensure no contained in link references deleted document
v_sqltext := 'SELECT A.IDA2A2 FROM EPMContainedIn A WHERE A.IDA3A5 ' || getWhereClause( i_docList, 1);
EXECUTE IMMEDIATE v_sqltext BULK COLLECT INTO v_oid USING i_docList;
FOR i IN 1 .. v_oid.count LOOP
-- dbms_output.put_line ( 'OID of containedin link associated to deleted document = ' || v_oid(i));
o_errList.extend();
o_errList(o_errList.LAST) := new FT_STATUS('wt.epm.structure.EPMContainedin', v_oid(i), 30010);
END LOOP;
FTValidator_Helper_PK.record_errors(30010, 'wt.epm.structure.EPMContainedin', ftConfigData, o_errList, v_reportData, i_continue);
IF NOT i_continue THEN
RETURN v_reportData;
END IF;
END IF;
o_errList := new FT_STATUS_TABLE();
FTValidator_Helper_PK.should_validate_error(30020, 'wt.epm.structure.EPMVariantLink', ftConfigData , i_continue);
IF i_continue = TRUE THEN
-- ensure no variant link references deleted document
v_sqltext := 'SELECT A.IDA2A2 FROM EPMVariantLink A WHERE A.IDA3A5 ' || getWhereClause( i_docList, 1);
EXECUTE IMMEDIATE v_sqltext BULK COLLECT INTO v_oid USING i_docList;
FOR i IN 1 .. v_oid.count LOOP
-- dbms_output.put_line ( 'OID of variant link associated to deleted document = ' || v_oid(i));
o_errList.extend();
o_errList(o_errList.LAST) := new FT_STATUS('wt.epm.structure.EPMVariantLink', v_oid(i), 30020);
END LOOP;
FTValidator_Helper_PK.record_errors(30020, 'wt.epm.structure.EPMVariantLink', ftConfigData, o_errList, v_reportData, i_continue);
IF NOT i_continue THEN
RETURN v_reportData;
END IF;
END IF;
o_errList := new FT_STATUS_TABLE();
FTValidator_Helper_PK.should_validate_error(30030, 'wt.epm.familytable.EPMParameterValue', ftConfigData , i_continue);
IF i_continue = TRUE THEN
-- ensure deleted documents do not have EPMParameterValue associated to it
v_sqltext := 'SELECT DISTINCT A.IDA2A2 FROM EPMParameterValue A WHERE A.IDA3A4 ' || getWhereClause( i_docList, 1);
EXECUTE IMMEDIATE v_sqltext BULK COLLECT INTO v_oid USING i_docList;
FOR i IN 1 .. v_oid.count LOOP
-- dbms_output.put_line ( 'OID of parameter value associated to deleted document = ' || v_oid(i));
o_errList.extend();
o_errList(o_errList.LAST) := new FT_STATUS('wt.epm.familytable.EPMParameterValue', v_oid(i), 30030);
END LOOP;
FTValidator_Helper_PK.record_errors(30030, 'wt.epm.familytable.EPMParameterValue', ftConfigData, o_errList, v_reportData, i_continue);
IF NOT i_continue THEN
RETURN v_reportData;
END IF;
END IF;
o_errList := new FT_STATUS_TABLE();
FTValidator_Helper_PK.should_validate_error(30040, 'wt.epm.familytable.EPMFeatureValue', ftConfigData , i_continue);
IF i_continue = TRUE THEN
-- ensure deleted documents do not have EPMFeatureValue associated to it
v_sqltext := 'SELECT DISTINCT A.IDA2A2 FROM EPMFeatureValue A WHERE A.IDA3A4 ' || getWhereClause( i_docList, 1);
EXECUTE IMMEDIATE v_sqltext BULK COLLECT INTO v_oid USING i_docList;
FOR i IN 1 .. v_oid.count LOOP
-- dbms_output.put_line ( 'OID of parameter value associated to deleted document = ' || v_oid(i));
o_errList.extend();
o_errList(o_errList.LAST) := new FT_STATUS('wt.epm.familytable.EPMFeatureValue', v_oid(i), 30040);
END LOOP;
FTValidator_Helper_PK.record_errors(30040, 'wt.epm.familytable.EPMFeatureValue', ftConfigData, o_errList, v_reportData, i_continue);
IF NOT i_continue THEN
RETURN v_reportData;
END IF;
END IF;
o_errList := new FT_STATUS_TABLE();
FTValidator_Helper_PK.should_validate_error(300401, 'wt.epm.familytable.EPMSepFamilyTable', ftConfigData , i_continue);
IF i_continue = TRUE THEN
-- ensure family tables in checked in state, where the document participates are deleted
v_sqltext := 'SELECT IDA2A2 FROM EPMSepFamilyTable WHERE IDA2A2 ' || getWhereClause( i_checked_in_fts, 1);
EXECUTE IMMEDIATE v_sqltext BULK COLLECT INTO v_oid USING i_checked_in_fts;
FOR i IN 1 .. v_oid.count LOOP
-- dbms_output.put_line ( 'OID of parameter value associated to deleted document = ' || v_oid(i));
o_errList.extend();
o_errList(o_errList.LAST) := new FT_STATUS('wt.epm.familytable.EPMSepFamilyTable', v_oid(i), 300401);
END LOOP;
FTValidator_Helper_PK.record_errors(300401, 'wt.epm.familytable.EPMSepFamilyTable', ftConfigData, o_errList, v_reportData, i_continue);
IF NOT i_continue THEN
RETURN v_reportData;
END IF;
END IF;
RETURN v_reportData;
END ValidateDeletedEPMDocuments;
FUNCTION  ValidateDeletedEPMDocMasters (i_docMasterList IN TABLE_OF_NUMBER,ftConfigData IN OUT FTVAL_CONFIG_TABLE ) RETURN FT_REPORT_DATA IS
v_sqltext   VARCHAR2(2000);
v_oid       TABLE_OF_NUMBER;
o_errList	FT_STATUS_TABLE;
i_continue     BOOLEAN;
v_reportData   FT_REPORT_DATA;
BEGIN
o_errList := new FT_STATUS_TABLE();
v_reportData := new FT_REPORT_DATA();
i_continue := FALSE;
-- ensure no variant link references deleted document master
FTValidator_Helper_PK.should_validate_error(30040, 'wt.epm.structure.EPMVariantLink', ftConfigData , i_continue);
IF i_continue = TRUE THEN
v_sqltext := 'SELECT A.IDA2A2 FROM EPMVariantLink A WHERE A.IDA3B5 ' || getWhereClause( i_docMasterList, 1 );
EXECUTE IMMEDIATE v_sqltext BULK COLLECT INTO v_oid USING i_docMasterList;
FOR i IN 1 .. v_oid.count LOOP
-- dbms_output.put_line ( 'OID of variant link associated to deleted document master = ' || v_oid(i));
o_errList.extend();
o_errList(o_errList.LAST) := new FT_STATUS('wt.epm.structure.EPMVariantLink', v_oid(i), 30040);
END LOOP;
FTValidator_Helper_PK.record_errors(30040, 'wt.epm.structure.EPMVariantLink', ftConfigData, o_errList, v_reportData, i_continue);
IF NOT i_continue THEN
RETURN v_reportData;
END IF;
END IF;
RETURN v_reportData;
END ValidateDeletedEPMDocMasters;
FUNCTION  ValidateDeletedEPMCILinks (i_linkList IN TABLE_OF_NUMBER, i_docList IN TABLE_OF_NUMBER,i_ftList IN TABLE_OF_NUMBER,ftConfigData IN OUT FTVAL_CONFIG_TABLE )
RETURN FT_REPORT_DATA IS
v_sqltext           VARCHAR2(2000);
v_existing_docs     TABLE_OF_NUMBER;
v_oid               TABLE_OF_NUMBER;
v_classname         TABLE_OF_VARCHAR2_200;
v_ftobjects_oid     TABLE_OF_NUMBER;
o_errList	        FT_STATUS_TABLE;
i_continue	        BOOLEAN;
v_reportData        FT_REPORT_DATA;
i_className         VARCHAR2(200);
BEGIN
v_reportData := new FT_REPORT_DATA();
i_continue := FALSE;
o_errList := new FT_STATUS_TABLE();
-- ensure no cell is associated to the deleted containedin link
FOR i IN 1 .. FTCELL_TABLES.COUNT LOOP
i_className := getClassName(FTCELL_TABLES(i));
FTValidator_Helper_PK.should_validate_error(30060, i_className, ftConfigData , i_continue);
IF i_continue = TRUE THEN
v_sqltext := 'SELECT A.IDA2A2, A.CLASSNAMEA2A2 FROM ' || FTCELL_TABLES(i) ||' A WHERE A.IDA3A3 ' || getWhereClause( i_linkList, 1);
EXECUTE IMMEDIATE v_sqltext BULK COLLECT INTO v_oid, v_classname USING i_linkList;
FOR j IN 1 .. v_oid.count LOOP
-- dbms_output.put_line ( 'OID of family table cell = ' || v_oid(j));
o_errList.extend();
o_errList(o_errList.LAST) := new FT_STATUS(v_classname(j), v_oid(j), 30060);
END LOOP;
FTValidator_Helper_PK.record_errors(30060, i_className, ftConfigData, o_errList, v_reportData, i_continue);
IF NOT i_continue THEN
RETURN v_reportData;
END IF;
END IF;
END LOOP;
o_errList := new FT_STATUS_TABLE();
-- ensure the following
-- 1. Document is deleted, OR
-- 2. Document is standalone, OR
-- 3. Document is associated to another contained in link.
-- get the documents which are still in the database
FTValidator_Helper_PK.should_validate_error(30110, 'wt.epm.EPMDocument', ftConfigData , i_continue);
IF i_continue = TRUE THEN
v_sqltext := 'SELECT A.IDA2A2 FROM EPMDocument A WHERE A.IDA2A2 ' || getWhereClause( i_docList, 1);
EXECUTE IMMEDIATE v_sqltext BULK COLLECT INTO v_existing_docs USING i_docList;
if v_existing_docs.count > 0 THEN
-- get all the family table objects
v_sqltext := 'SELECT A.IDA2A2 FROM EPMDocument A WHERE A.IDA2A2 ' || getWhereClause( v_existing_docs, 1) || ' AND A.FAMILYTABLESTATUS <> 0';
EXECUTE IMMEDIATE v_sqltext BULK COLLECT INTO v_ftobjects_oid USING v_existing_docs;
if v_ftobjects_oid.count > 0 THEN
-- ensure that they participate in other containedin link.
v_sqltext := 'SELECT A.IDA2A2 FROM EPMDocument A  WHERE A.IDA2A2 ' || getWhereClause( v_ftobjects_oid, 1 ) || '  AND   NOT EXISTS ( SELECT ''x'' FROM EPMContainedIn B WHERE B.IDA3A5 = A.IDA2A2 )';
EXECUTE IMMEDIATE v_sqltext BULK COLLECT INTO v_oid USING v_ftobjects_oid;
FOR i IN 1 .. v_oid.count LOOP
o_errList.extend();
o_errList(o_errList.LAST) := new FT_STATUS('wt.epm.EPMDocument', v_oid(i), 30110);
END LOOP;
END IF;
END IF;
FTValidator_Helper_PK.record_errors(30110, 'wt.epm.EPMDocument', ftConfigData, o_errList, v_reportData, i_continue);
IF NOT i_continue THEN
RETURN v_reportData;
END IF;
END IF;
o_errList := new FT_STATUS_TABLE();
-- ensure that all the EPMSepFamilyTable objects associated with the deleted containedIn links are either deleted or associated to other containedIn link/links.
FTValidator_Helper_PK.should_validate_error(30190, 'wt.epm.familytable.EPMSepFamilyTable', ftConfigData , i_continue);
IF i_continue = TRUE THEN
v_sqltext := 'SELECT A.IDA2A2 FROM EPMSepFamilyTable A  WHERE A.IDA2A2 ' || getWhereClause( i_ftList, 1) ||'  AND   NOT EXISTS ( SELECT ''x'' FROM EPMContainedIn B  WHERE B.IDA3B5 = A.IDA2A2 )';
EXECUTE IMMEDIATE v_sqltext BULK COLLECT INTO v_oid USING i_ftList;
FOR i IN 1 .. v_oid.count LOOP
o_errList.extend();
o_errList(o_errList.LAST) := new FT_STATUS('wt.epm.familytable.EPMSepFamilyTable', v_oid(i), 30190);
END LOOP;
FTValidator_Helper_PK.record_errors(30190, 'wt.epm.familytable.EPMSepFamilyTable', ftConfigData, o_errList, v_reportData, i_continue);
IF NOT i_continue THEN
RETURN v_reportData;
END IF;
END IF;
RETURN v_reportData;
END ValidateDeletedEPMCILinks;
FUNCTION  ValidateDeletedEPMFamilyTable (i_ftList IN TABLE_OF_NUMBER, i_ft_info IN TABLE_OF_FT_INFO,ftConfigData IN OUT FTVAL_CONFIG_TABLE )
RETURN FT_REPORT_DATA IS
v_sqltext   VARCHAR2(2000);
v_oid       TABLE_OF_NUMBER;
v_num_recs  NUMBER;
v_classname TABLE_OF_VARCHAR2_200;
o_errList	FT_STATUS_TABLE;
v_error     NUMBER;
i_continue	BOOLEAN;
v_reportData   FT_REPORT_DATA;
i_className  VARCHAR2(200);
BEGIN
o_errList := new FT_STATUS_TABLE();
v_reportData := new FT_REPORT_DATA();
i_continue := FALSE;
FOR i IN 1 .. FTCOLUMN_TABLES.COUNT LOOP
i_className := getClassName(FTCOLUMN_TABLES(i));
-- ensure family table column or its sub classes do not refer to the deleted family table
FTValidator_Helper_PK.should_validate_error(30150, i_className, ftConfigData , i_continue);
IF i_continue = TRUE THEN
v_sqltext := 'SELECT IDA2A2, CLASSNAMEA2A2  FROM ' || FTCOLUMN_TABLES(i) ||'  WHERE IDA3A3 ' || getWhereClause( i_ftList, 1 );
EXECUTE IMMEDIATE v_sqltext BULK COLLECT INTO v_oid, v_classname USING i_ftList;
FOR i IN 1 .. v_oid.count LOOP
o_errList.extend();
o_errList(o_errList.LAST) := new FT_STATUS(v_classname(i), v_oid(i), 30150);
END LOOP;
FTValidator_Helper_PK.record_errors(30150, i_className, ftConfigData, o_errList, v_reportData, i_continue);
IF NOT i_continue THEN
RETURN v_reportData;
END IF;
END IF;
END LOOP;
o_errList := new FT_STATUS_TABLE();
-- ensure no contained in link exists where the deleted family table participates as container
FTValidator_Helper_PK.should_validate_error(30160, 'wt.epm.structure.EPMContainedin', ftConfigData , i_continue);
IF i_continue = TRUE THEN
v_sqltext := 'SELECT A.IDA2A2 FROM EPMContainedIn A WHERE A.IDA3B5 ' || getWhereClause( i_ftList, 1);
EXECUTE IMMEDIATE v_sqltext BULK COLLECT INTO v_oid USING i_ftList;
FOR i IN 1 .. v_oid.count LOOP
o_errList.extend();
o_errList(o_errList.LAST) := new FT_STATUS('wt.epm.structure.EPMContainedin', v_oid(i), 30160);
END LOOP;
FTValidator_Helper_PK.record_errors(30160, 'wt.epm.structure.EPMContainedin', ftConfigData, o_errList, v_reportData, i_continue);
IF NOT i_continue THEN
RETURN v_reportData;
END IF;
END IF;
o_errList := new FT_STATUS_TABLE();
-- ensure if document master of the deleted FT exists, it has at least one FT.
-- the ft_info table has masters, but they could be repititive
FTValidator_Helper_PK.should_validate_error(30180, 'wt.epm.EPMDocumentMaster', ftConfigData , i_continue);
IF i_continue = TRUE THEN
v_num_recs := i_ft_info.LAST;
v_sqltext := 'SELECT DISTINCT A.master_id FROM ft_info A WHERE A.master_id IN ( SELECT /*+ cardinality ( Z ' || v_num_recs || ' ) */ Z.master_id from table(cast(:1 as table_of_ft_info)) Z )';
EXECUTE IMMEDIATE v_sqltext BULK COLLECT INTO v_oid USING i_ft_info;
FOR i IN 1 .. v_oid.count LOOP
v_error := checkFTMaster(v_oid(i));
if v_error = 1 THEN
-- dbms_output.put_line ( 'OID of FT master = ' || i_ft_info(i).master_id);
o_errList.extend();
o_errList(o_errList.LAST) := new FT_STATUS('wt.epm.EPMDocumentMaster', v_oid(i), 30180);
END IF;
END LOOP;
FTValidator_Helper_PK.record_errors(30180, 'wt.epm.EPMDocumentMaster', ftConfigData, o_errList, v_reportData, i_continue);
IF NOT i_continue THEN
RETURN v_reportData;
END IF;
END IF;
o_errList := new FT_STATUS_TABLE();
-- ensure documents participating in deleted FT are either deleted or participate in another FT of the same master
FTValidator_Helper_PK.should_validate_error(30170, 'wt.epm.EPMDocument', ftConfigData , i_continue);
IF i_continue = TRUE THEN
v_num_recs := i_ft_info.LAST;
FOR i IN 1 .. v_num_recs LOOP
v_error := checkFTDocument(i_ft_info(i).master_id, i_ft_info(i).doc_id);
if v_error = 1 THEN
-- dbms_output.put_line ( 'OID of FT master = ' || i_ft_info(i).master_id);
-- dbms_output.put_line ( 'OID of document = ' || i_ft_info(i).doc_id);
o_errList.extend();
o_errList(o_errList.LAST) := new FT_STATUS('wt.epm.EPMDocument', i_ft_info(i).doc_id, 30170);
END IF;
END LOOP;
FTValidator_Helper_PK.record_errors(30170, 'wt.epm.EPMDocument', ftConfigData, o_errList, v_reportData, i_continue);
IF NOT i_continue THEN
RETURN v_reportData;
END IF;
END IF;
RETURN v_reportData;
END ValidateDeletedEPMFamilyTable;
FUNCTION  ValidateDeletedEPMFTMasters (i_ftMasterList IN TABLE_OF_NUMBER,ftConfigData IN OUT FTVAL_CONFIG_TABLE )
RETURN FT_REPORT_DATA IS
v_sqltext   VARCHAR2(2000);
v_oid       TABLE_OF_NUMBER;
o_errList	FT_STATUS_TABLE;
v_reportData   FT_REPORT_DATA;
i_continue	     BOOLEAN;
BEGIN
o_errList := new FT_STATUS_TABLE();
v_reportData := new FT_REPORT_DATA();
i_continue := FALSE;
FTValidator_Helper_PK.should_validate_error(30070, 'wt.epm.familytable.EPMSepFamilyTable', ftConfigData , i_continue);
IF i_continue = TRUE THEN
-- ensure there is no family table instance referencing the deleted master
v_sqltext := 'SELECT A.IDA2A2 FROM EPMSepFamilyTable A WHERE A.IDA3MASTERREFERENCE ' || getWhereClause( i_ftMasterList, 1);
EXECUTE IMMEDIATE v_sqltext BULK COLLECT INTO v_oid USING i_ftMasterList;
FOR i IN 1 .. v_oid.count LOOP
-- dbms_output.put_line ( 'OID of family table = ' || v_oid(i));
o_errList.extend();
o_errList(o_errList.LAST) := new FT_STATUS('wt.epm.familytable.EPMSepFamilyTable', v_oid(i), 30070);
END LOOP;
FTValidator_Helper_PK.record_errors(30070, 'wt.epm.familytable.EPMSepFamilyTable', ftConfigData, o_errList, v_reportData, i_continue);
IF NOT i_continue THEN
RETURN v_reportData;
END IF;
END IF;
o_errList := new FT_STATUS_TABLE();
FTValidator_Helper_PK.should_validate_error(30080, 'wt.epm.familytable.EPMParameterDefinition', ftConfigData , i_continue);
IF i_continue = TRUE THEN
-- ensure no parameter definition is associated to the deleted family table master
v_sqltext := 'SELECT A.IDA2A2 FROM EPMParameterDefinition A WHERE A.IDA3A3 ' || getWhereClause( i_ftMasterList, 1 );
EXECUTE IMMEDIATE v_sqltext BULK COLLECT INTO v_oid USING i_ftMasterList;
FOR i IN 1 .. v_oid.count LOOP
-- dbms_output.put_line ( 'OID of parameter definition = ' || v_oid(i));
o_errList.extend();
o_errList(o_errList.LAST) := new FT_STATUS('wt.epm.familytable.EPMParameterDefinition', v_oid(i), 30080);
END LOOP;
FTValidator_Helper_PK.record_errors(30080, 'wt.epm.familytable.EPMParameterDefinition', ftConfigData, o_errList, v_reportData, i_continue);
IF NOT i_continue THEN
RETURN v_reportData;
END IF;
END IF;
o_errList := new FT_STATUS_TABLE();
FTValidator_Helper_PK.should_validate_error(30090, 'wt.epm.familytable.EPMFeatureDefinition', ftConfigData , i_continue);
IF i_continue = TRUE THEN
-- ensure no feature definition is associated to the deleted family table master
v_sqltext := 'SELECT A.IDA2A2 FROM EPMFeatureDefinition A WHERE A.IDA3A3 ' || getWhereClause( i_ftMasterList, 1 );
EXECUTE IMMEDIATE v_sqltext BULK COLLECT INTO v_oid USING i_ftMasterList;
FOR i IN 1 .. v_oid.count LOOP
-- dbms_output.put_line ( 'OID of feature definition = ' || v_oid(i));
o_errList.extend();
o_errList(o_errList.LAST) := new FT_STATUS('wt.epm.familytable.EPMFeatureDefinition', v_oid(i), 30090);
END LOOP;
FTValidator_Helper_PK.record_errors(30090, 'wt.epm.familytable.EPMFeatureDefinition', ftConfigData, o_errList, v_reportData, i_continue);
IF NOT i_continue THEN
RETURN v_reportData;
END IF;
END IF;
RETURN v_reportData;
END ValidateDeletedEPMFTMasters;
FUNCTION  ValidateDeletedEPMFTColumns (i_columnList IN TABLE_OF_NUMBER,ftConfigData IN OUT FTVAL_CONFIG_TABLE )
RETURN FT_REPORT_DATA IS
v_sqltext      VARCHAR2(2000);
v_oid          TABLE_OF_NUMBER;
v_classname    TABLE_OF_VARCHAR2_200;
o_errList	   FT_STATUS_TABLE;
v_reportData   FT_REPORT_DATA;
i_continue	     BOOLEAN;
i_className VARCHAR2(200);
BEGIN
o_errList := new FT_STATUS_TABLE();
v_reportData := new FT_REPORT_DATA();
i_continue := FALSE;
-- ensure no cell is associated to the deleted column.
FOR i IN 1 .. FTCELL_TABLES.COUNT LOOP
i_className := getClassName(FTCELL_TABLES(i));
FTValidator_Helper_PK.should_validate_error(30100, i_className, ftConfigData , i_continue);
IF i_continue = TRUE THEN
v_sqltext := 'SELECT A.IDA2A2, A.CLASSNAMEA2A2 FROM ' || FTCELL_TABLES(i) ||' A WHERE A.IDA3B3 ' || getWhereClause( i_columnList, 1);
EXECUTE IMMEDIATE v_sqltext BULK COLLECT INTO v_oid, v_classname USING i_columnList;
FOR j IN 1 .. v_oid.count LOOP
-- dbms_output.put_line ( 'OID of family table cell = ' || v_oid(j));
o_errList.extend();
o_errList(o_errList.LAST) := new FT_STATUS(v_classname(j), v_oid(j), 30100);
END LOOP;
FTValidator_Helper_PK.record_errors(30100, i_className, ftConfigData, o_errList, v_reportData, i_continue);
IF NOT i_continue THEN
RETURN v_reportData;
END IF;
END IF;
END LOOP;
RETURN v_reportData;
END ValidateDeletedEPMFTColumns;
FUNCTION  ValidateDeletedEPMFTCells (i_cellInfo IN TABLE_OF_CELL_INFO,ftConfigData IN OUT FTVAL_CONFIG_TABLE )
RETURN FT_REPORT_DATA IS
v_sqltext      VARCHAR2(2000);
v_oid          TABLE_OF_NUMBER;
v_error        NUMBER;
o_errList	   FT_STATUS_TABLE;
v_num_recs     NUMBER;
v_reportData   FT_REPORT_DATA;
i_continue	     BOOLEAN;
BEGIN
o_errList := new FT_STATUS_TABLE();
v_reportData := new FT_REPORT_DATA();
i_continue := FALSE;
FTValidator_Helper_PK.should_validate_error(30140, 'wt.epm.familytable.EPMFamilyTableCell', ftConfigData , i_continue);
IF i_continue = TRUE THEN
v_num_recs := i_cellInfo.LAST;
FOR i IN 1 .. v_num_recs LOOP
v_error := checkCell(i_cellInfo(i).cell_id, i_cellInfo(i).link_id, i_cellInfo(i).column_id);
if v_error = 1 THEN
-- dbms_output.put_line ( 'classname of family table cell = ' || i_cellInfo(i).classname);
-- dbms_output.put_line ( 'OID of family table cell = ' || i_cellInfo(i).cell_id);
-- dbms_output.put_line ( 'OID of contained in link = ' || i_cellInfo(i).link_id);
-- dbms_output.put_line ( 'OID of column = ' || i_cellInfo(i).column_id);
o_errList.extend();
o_errList(o_errList.LAST) := new FT_STATUS(i_cellInfo(i).classname, i_cellInfo(i).cell_id, 30140);
END IF;
FTValidator_Helper_PK.record_errors(30140, 'wt.epm.familytable.EPMFamilyTableCell', ftConfigData, o_errList, v_reportData, i_continue);
IF NOT i_continue THEN
RETURN v_reportData;
END IF;
END LOOP;
END IF;
RETURN v_reportData;
END ValidateDeletedEPMFTCells;
FUNCTION  ValidateDeletedEPMParamValue (i_cellList IN TABLE_OF_NUMBER,ftConfigData IN OUT FTVAL_CONFIG_TABLE )
RETURN FT_REPORT_DATA IS
v_sqltext      VARCHAR2(2000);
v_oid          TABLE_OF_NUMBER;
v_classname    TABLE_OF_VARCHAR2_200;
o_errList	   FT_STATUS_TABLE;
i_continue     BOOLEAN;
i_className    VARCHAR2(200);
v_reportData   FT_REPORT_DATA;
BEGIN
o_errList := new FT_STATUS_TABLE();
v_reportData := new FT_REPORT_DATA();
i_continue := FALSE;
-- ensure that no cell exists, as these are cells corresponding to the deleted parameter value
FOR i IN 1 .. FTCELL_TABLES.COUNT LOOP
i_className := getClassName(FTCELL_TABLES(i));
FTValidator_Helper_PK.should_validate_error(30120, i_className, ftConfigData , i_continue);
IF i_continue = TRUE THEN
v_sqltext := 'SELECT A.IDA2A2, A.CLASSNAMEA2A2 FROM ' || FTCELL_TABLES(i) ||' A WHERE A.IDA2A2 ' || getWhereClause( i_cellList, 1);
EXECUTE IMMEDIATE v_sqltext BULK COLLECT INTO v_oid, v_classname USING i_cellList;
FOR j IN 1 .. v_oid.count LOOP
-- dbms_output.put_line ( 'OID of family table cell = ' || v_oid(j));
o_errList.extend();
o_errList(o_errList.LAST) := new FT_STATUS(v_classname(j), v_oid(j), 30120);
END LOOP;
FTValidator_Helper_PK.record_errors(30120, i_className, ftConfigData, o_errList, v_reportData, i_continue);
IF NOT i_continue THEN
RETURN v_reportData;
END IF;
END IF;
END LOOP;
RETURN v_reportData;
END ValidateDeletedEPMParamValue;
FUNCTION  ValidateDeletedEPMFeatureValue (i_cellList IN TABLE_OF_NUMBER,ftConfigData IN OUT FTVAL_CONFIG_TABLE )
RETURN FT_REPORT_DATA IS
v_sqltext      VARCHAR2(2000);
v_oid          TABLE_OF_NUMBER;
v_classname    TABLE_OF_VARCHAR2_200;
o_errList	   FT_STATUS_TABLE;
i_continue     BOOLEAN;
i_className    VARCHAR2(200);
v_reportData   FT_REPORT_DATA;
BEGIN
o_errList := new FT_STATUS_TABLE();
v_reportData := new FT_REPORT_DATA();
i_continue := FALSE;
-- ensure that no cell exists, as these are cells corresponding to the deleted Feature value
FOR i IN 1 .. FTCELL_TABLES.COUNT LOOP
i_className := getClassName(FTCELL_TABLES(i));
FTValidator_Helper_PK.should_validate_error(30130, i_className, ftConfigData , i_continue);
IF i_continue = TRUE THEN
v_sqltext := 'SELECT A.IDA2A2, A.CLASSNAMEA2A2 FROM ' || FTCELL_TABLES(i) ||' A WHERE A.IDA2A2 ' || getWhereClause( i_cellList, 1);
EXECUTE IMMEDIATE v_sqltext BULK COLLECT INTO v_oid, v_classname USING i_cellList;
FOR j IN 1 .. v_oid.count LOOP
-- dbms_output.put_line ( 'OID of family table cell = ' || v_oid(j));
o_errList.extend();
o_errList(o_errList.LAST) := new FT_STATUS(v_classname(j), v_oid(j), 30130);
END LOOP;
FTValidator_Helper_PK.record_errors(30130, i_className, ftConfigData, o_errList, v_reportData, i_continue);
IF NOT i_continue THEN
RETURN v_reportData;
END IF;
END IF;
END LOOP;
RETURN v_reportData;
END ValidateDeletedEPMFeatureValue;
FUNCTION  ValidateDeletedEPMParamDef (i_valueList IN TABLE_OF_NUMBER,ftConfigData IN OUT FTVAL_CONFIG_TABLE )
RETURN FT_REPORT_DATA IS
v_sqltext      VARCHAR2(2000);
v_oid          TABLE_OF_NUMBER;
o_errList	   FT_STATUS_TABLE;
i_continue     BOOLEAN;
v_reportData   FT_REPORT_DATA;
BEGIN
o_errList := new FT_STATUS_TABLE();
v_reportData := new FT_REPORT_DATA();
i_continue := FALSE;
FTValidator_Helper_PK.should_validate_error(30130, 'wt.epm.family.EPMParameterValue', ftConfigData , i_continue);
IF i_continue = TRUE THEN
-- ensure that no parameter value exists, as these are cells corresponding to the deleted parameter definition
v_sqltext := 'SELECT A.IDA2A2 FROM EPMParameterValue A WHERE A.IDA2A2 ' || getWhereClause( i_valueList, 1 );
EXECUTE IMMEDIATE v_sqltext BULK COLLECT INTO v_oid USING i_valueList;
FOR j IN 1 .. v_oid.count LOOP
-- dbms_output.put_line ( 'OID of parameter value = ' || v_oid(j));
o_errList.extend();
o_errList(o_errList.LAST) := new FT_STATUS('wt.epm.family.EPMParameterValue', v_oid(j), 30130);
END LOOP;
FTValidator_Helper_PK.record_errors(30130, 'wt.epm.family.EPMParameterValue', ftConfigData, o_errList, v_reportData, i_continue);
IF NOT i_continue THEN
RETURN v_reportData;
END IF;
END IF;
RETURN v_reportData;
END ValidateDeletedEPMParamDef;
FUNCTION  ValidateDeletedEPMFeatureDef (i_valueList IN TABLE_OF_NUMBER,ftConfigData IN OUT FTVAL_CONFIG_TABLE )
RETURN FT_REPORT_DATA IS
v_sqltext      VARCHAR2(2000);
v_oid          TABLE_OF_NUMBER;
o_errList	   FT_STATUS_TABLE;
i_continue     BOOLEAN;
v_reportData   FT_REPORT_DATA;
BEGIN
o_errList := new FT_STATUS_TABLE();
v_reportData := new FT_REPORT_DATA();
i_continue := FALSE;
FTValidator_Helper_PK.should_validate_error(30130, 'wt.epm.family.EPMFeatureValue', ftConfigData , i_continue);
IF i_continue = TRUE THEN
-- ensure that no feature value exists, as these are cells corresponding to the deleted feature definition
v_sqltext := 'SELECT A.IDA2A2 FROM EPMFeatureValue A WHERE A.IDA2A2 ' || getWhereClause( i_valueList, 1);
EXECUTE IMMEDIATE v_sqltext BULK COLLECT INTO v_oid USING i_valueList;
FOR j IN 1 .. v_oid.count LOOP
-- dbms_output.put_line ( 'OID of feature value = ' || v_oid(j));
o_errList.extend();
o_errList(o_errList.LAST) := new FT_STATUS('wt.epm.family.EPMFeatureValue', v_oid(j), 30130);
END LOOP;
FTValidator_Helper_PK.record_errors(30130, 'wt.epm.family.EPMFeatureValue', ftConfigData, o_errList, v_reportData, i_continue);
IF NOT i_continue THEN
RETURN v_reportData;
END IF;
END IF;
RETURN v_reportData;
END ValidateDeletedEPMFeatureDef;
FUNCTION  ValidateEPMTableChunk (i_tabName IN VARCHAR2, i_className IN VARCHAR2, i_chunksize IN NUMBER, ftConfigData IN OUT FTVAL_CONFIG_TABLE, v_reportData IN OUT FT_REPORT_DATA) RETURN FT_REPORT_DATA
AS
c_all       SYS_REFCURSOR;
v_doclist	TABLE_OF_NUMBER;
o_errList	FT_STATUS_TABLE;
v_errList	FT_STATUS_TABLE;
v_stmt		VARCHAR2(1000);
v_found		BOOLEAN;
v_err     VARCHAR2(150);
v_err_num NUMBER;
temp_reportData   FT_REPORT_DATA;
i_continue    BOOLEAN;
BEGIN
o_errList := new FT_STATUS_TABLE();
v_errList := new FT_STATUS_TABLE();
temp_reportData := new FT_REPORT_DATA();
i_continue := FALSE;
v_found := FALSE;
v_stmt := 'select IDA2A2 from ' || i_tabName;
OPEN c_all FOR v_stmt;
LOOP
FETCH c_all BULK COLLECT INTO v_docList LIMIT i_chunksize;
FTValidator_Helper_PK.should_validate_chunk(i_className, ftConfigData , i_continue);
IF i_continue = FALSE OR v_docList.count <= 0 THEN
CLOSE c_all;
RETURN v_reportData;
END IF;
IF  UPPER(i_tabName) = 'EPMDOCUMENT' THEN
temp_reportData := ValidateEPMDocuments(v_docList,ftConfigData);
ELSIF  UPPER(i_tabName) = 'EPMDOCUMENTMASTER' THEN
temp_reportData := ValidateEPMDocumentMasters(v_docList,ftConfigData);
ELSIF  UPPER(i_tabName) = 'EPMCONTAINEDIN' THEN
temp_reportData := ValidateEPMContainedInLinks(v_docList,ftConfigData);
ELSIF  UPPER(i_tabName) = 'EPMVARIANTLINK' THEN
temp_reportData := ValidateEPMVariantLinks(v_docList,ftConfigData);
ELSIF  UPPER(i_tabName) = 'EPMSEPFAMILYTABLE' THEN
temp_reportData := ValidateEPMFamilyTable(v_docList,ftConfigData);
ELSIF  UPPER(i_tabName) = 'EPMSEPFAMILYTABLEMASTER' THEN
temp_reportData := ValidateEPMFamilyTableMasters(v_docList,ftConfigData);
ELSIF  UPPER(i_tabName) = 'EPMFEATUREVALUE' THEN
temp_reportData := ValidateEPMFeatureValues(v_docList,ftConfigData);
ELSIF  UPPER(i_tabName) = 'EPMPARAMETERVALUE' THEN
temp_reportData := ValidateEPMParameterValues(v_docList,ftConfigData);
ELSE
FOR i IN 1 .. FTCELL_TABLES.COUNT
LOOP
IF UPPER(i_tabName) = UPPER(FTCELL_TABLES(i)) THEN
temp_reportData := ValidateEPMFTCells(v_docList,ftConfigData);
v_found := TRUE;
EXIT;
END IF;
END LOOP;
IF NOT v_found THEN
FOR i IN 1 .. FTCOLUMN_TABLES.COUNT
LOOP
IF UPPER(i_tabName) = UPPER(FTCOLUMN_TABLES(i)) THEN
temp_reportData := ValidateEPMFTColumns(v_docList,ftConfigData);
v_found := TRUE;
EXIT;
END IF;
END LOOP;
END IF;
END IF;
FTValidator_Helper_PK.append_report_data(v_reportData, temp_reportData);
v_docList.delete;
EXIT WHEN c_all%NOTFOUND;
END LOOP;
CLOSE c_all;
RETURN v_reportData;
END ValidateEPMTableChunk;
FUNCTION  ValidateEPMTableNoChunk (i_tabName IN VARCHAR2, ftConfigData IN OUT FTVAL_CONFIG_TABLE, v_reportData IN OUT FT_REPORT_DATA) RETURN FT_REPORT_DATA
AS
c_all       SYS_REFCURSOR;
v_doclist	TABLE_OF_NUMBER;
o_errList	FT_STATUS_TABLE;
v_errList	FT_STATUS_TABLE;
v_stmt	VARCHAR2(1000);
v_found	BOOLEAN;
temp_reportData   FT_REPORT_DATA;
BEGIN
o_errList := new FT_STATUS_TABLE();
temp_reportData := new FT_REPORT_DATA();
v_docList := NULL;
v_found := FALSE;
FOR i IN 1 .. FTCELL_TABLES.COUNT
LOOP
IF UPPER(i_tabName) = UPPER(FTCELL_TABLES(i)) THEN
temp_reportData :=ValidateEPMFTCells(i_tabName,v_docList,ftConfigData);
FTValidator_Helper_PK.append_report_data(v_reportData, temp_reportData);
v_found := TRUE;
EXIT;
END IF;
END LOOP;
IF NOT v_found THEN
FOR i IN 1 .. FTCOLUMN_TABLES.COUNT
LOOP
IF UPPER(i_tabName) = UPPER(FTCOLUMN_TABLES(i)) THEN
temp_reportData := ValidateEPMFTColumns(i_tabName,v_docList,ftConfigData);
FTValidator_Helper_PK.append_report_data(v_reportData, temp_reportData);
EXIT;
END IF;
END LOOP;
END IF;
RETURN v_reportData;
END ValidateEPMTableNoChunk;
FUNCTION  ValidateEPMTable (i_tabname IN VARCHAR2, ftConfigData IN OUT FTVAL_CONFIG_TABLE, i_chunksize IN NUMBER, i_chunkforce IN NUMBER ) RETURN FT_REPORT_DATA
AS
o_errList	   FT_STATUS_TABLE;
lTraceSql	   VARCHAR2(75);
v_reportData   FT_REPORT_DATA;
i_continue     BOOLEAN;
i_className    VARCHAR2(100);
BEGIN
v_reportData := new FT_REPORT_DATA();
i_className := getClassName(i_tabname);
IF i_className='-1' THEN
o_errList := new FT_STATUS_TABLE();
o_errList.extend();
o_errList(o_errList.LAST) := new FT_STATUS('ValidateEPMTableChunk: No idea how to validate table = ' || i_tabName,0, -1);
FTValidator_Helper_PK.record_errors(-1, i_tabname, ftConfigData, o_errList, v_reportData, i_continue);
IF NOT i_continue THEN
RETURN v_reportData;
END IF;
END IF;
FTValidator_Helper_PK.should_validate_class(i_className, ftConfigData , i_continue);
IF  i_continue = TRUE THEN
IF i_chunkforce = 0 AND Upper(i_tabName) IN ('EPMFAMILYTABLECELL','EPMFAMILYTABLECELLDEP','EPMFAMILYTABLEPARAMETER','EPMFAMILYTABLEFEATURE','EPMFAMILYTABLEMEMBER','EPMFAMILYTABLEATTRIBUTE','EPMFAMILYTABLEREFERENCE') Then
v_reportData := ValidateEPMTableNoChunk (i_tabName, ftConfigData, v_reportData);
ELSE
v_reportData := ValidateEPMTableChunk (i_tabName, i_className, i_chunksize, ftConfigData, v_reportData);
End IF;
END IF;
RETURN v_reportData;
END ValidateEPMTable;
END EPMFTValidatorPK;
/

