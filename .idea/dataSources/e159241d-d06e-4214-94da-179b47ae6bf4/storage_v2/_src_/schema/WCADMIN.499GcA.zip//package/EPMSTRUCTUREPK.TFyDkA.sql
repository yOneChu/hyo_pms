create PACKAGE EPMStructurePK IS
FUNCTION getDependencies(databaseIds TABLE_OF_NUMBER) RETURN LIST_OF_EPM_DEPENDENCIES;
FUNCTION navigate(listsOfTables TABLE_OF_VARCHAR2_200, queryTemplate VARCHAR2,
databaseIds TABLE_OF_NUMBER) RETURN LIST_OF_LINKS;
FUNCTION navigateToMaster(linkTableNames TABLE_OF_VARCHAR2_30, otherSideTableNames TABLE_OF_VARCHAR2_30,
queryTemplate VARCHAR2, databaseIds TABLE_OF_NUMBER)
RETURN LIST_OF_LINK_N_MASTERS;
TYPE LINK_RECORD IS RECORD (
roleAClassName VARCHAR(200),
roleAId        NUMBER,
roleBClassName VARCHAR(200),
roleBId        NUMBER,
className      VARCHAR(200),
id             NUMBER);
TYPE LINK_N_MASTER_RECORD IS RECORD (
roleAClassName  VARCHAR(200),
roleAId         NUMBER,
roleBClassName  VARCHAR(200),
roleBId         NUMBER,
className       VARCHAR(200),
id              NUMBER,
masterClassName VARCHAR(200),
masterId        NUMBER);
END EPMStructurePK;
/

