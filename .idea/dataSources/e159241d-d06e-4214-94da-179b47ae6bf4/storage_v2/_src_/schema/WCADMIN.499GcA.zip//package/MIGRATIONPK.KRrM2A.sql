create PACKAGE MigrationPK IS
  TYPE ArrayNumber    IS TABLE of NUMBER       INDEX BY BINARY_INTEGER;

PROCEDURE filterLOs ( IlinkDomainId VARCHAR2,
                     loIDs TABLE_OF_NUMBER,
                     lovsPerLOCount TABLE_OF_NUMBER,
                     lovIDs TABLE_OF_NUMBER,
                     topGenericPIVIDs TABLE_OF_NUMBER,
                     cisPerLOVCount TABLE_OF_NUMBER,
                     containedPIVIDs TABLE_OF_NUMBER,
                     varsPerLOVCount TABLE_OF_NUMBER,
                     genericPIIDs TABLE_OF_NUMBER,
                     variantPIVIDs TABLE_OF_NUMBER,
                     existingLOIdArr OUT TABLE_OF_NUMBER,
                     existingFTMasterIdArr OUT TABLE_OF_NUMBER,
                     ignoredLOVIds OUT TABLE_OF_NUMBER
);

FUNCTION insertLOs(containedType VARCHAR2,
                     epmDocumentClassName VARCHAR2,
                     epmDocumentMasterClassName VARCHAR2,
                     containedLinkClassName VARCHAR2,
                     variantLinkClassName VARCHAR2,
                     epmSepFTClassName VARCHAR2,
                     authAppVerClassName VARCHAR2,
                     adminDomainClassName VARCHAR2,

                     IlinkDomainId VARCHAR2,
                     lovLoaderSize number,
                     isLastrow number,
                     loIDs TABLE_OF_NUMBER,
                     ftmIDs TABLE_OF_NUMBER,
                     lovsPerLOCount TABLE_OF_NUMBER,
                     lovIDs TABLE_OF_NUMBER,
                     ftIDs TABLE_OF_NUMBER,
                     appVerIDs TABLE_OF_NUMBER,
                     appVerBools TABLE_OF_NUMBER,
                     lovCreatedOn TABLE_OF_DATE,
                     lovModifiedOn TABLE_OF_DATE,

                     topGenericPIVIDs TABLE_OF_NUMBER,
                     fileIds TABLE_OF_NUMBER,
                     fileNames uzy_mig_TABLE_OF_VARCHAR2_200,
                     fileSizes TABLE_OF_NUMBER,
                     fsHosts uzy_mig_TABLE_OF_VARCHAR2_200,
                     fsPorts TABLE_OF_NUMBER,
                     fpPaths TABLE_OF_VARCHAR2,
                     fMapNames uzy_mig_TABLE_OF_VARCHAR2_200,
                     categories uzy_mig_TABLE_OF_VARCHAR2_200,

                     cisPerLOVCount TABLE_OF_NUMBER,
                     containedPIVIDs TABLE_OF_NUMBER,
                     instanceStoredName UZY_MIG_TABLE_OF_VARCHAR2_200,
                     verStatuses TABLE_OF_NUMBER,
                     lockStatuses TABLE_OF_NUMBER,
                     varsPerLOVCount TABLE_OF_NUMBER,
                     genericPIIDs TABLE_OF_NUMBER,
                     variantPIVIDs TABLE_OF_NUMBER,
                     replicaLOVIDs TABLE_OF_NUMBER, replicaLOIDs TABLE_OF_NUMBER) RETURN NUMBER;

  FUNCTION insertLOProps( containedLinkClassName VARCHAR2,
                          epmSepFTMasterClassName VARCHAR2,
                          epmSepFTClassName VARCHAR2,
                          paramDefClassName VARCHAR2,
                          paramClassName VARCHAR2,
                          featureDefClassName VARCHAR2,
                          featureClassName VARCHAR2,
                          memberLinkClassName VARCHAR2,
                          refLinkClassName VARCHAR2,
                          attrClassName VARCHAR2,
                          cellClassName VARCHAR2,
                          cellDepClassName VARCHAR2,
                          epmDocumentClassName VARCHAR2,
                          paramValClassName VARCHAR2,
                          featureValClassName VARCHAR2,

                          IlinkDomainId VARCHAR2,
                          loIDs TABLE_OF_NUMBER, lovsPerLOCount TABLE_OF_NUMBER,
                          lovIDs TABLE_OF_NUMBER,
                          lovCreatedOn TABLE_OF_DATE,
                          lovModifiedOn TABLE_OF_DATE,

                          paramsPerLOVCount TABLE_OF_NUMBER,
                          pInstPIVIDs TABLE_OF_NUMBER,
                          piipInternalIds TABLE_OF_NUMBER, piipNames uzy_mig_TABLE_OF_VARCHAR2_200,
                          piipTypes TABLE_OF_NUMBER, piipValueTypes TABLE_OF_NUMBER,
                          pAttributes TABLE_OF_NUMBER, pColumnTypes TABLE_OF_NUMBER,
                          pTitles uzy_mig_TABLE_OF_VARCHAR2_200,
                          pOverridable TABLE_OF_NUMBER,
                          pDefinedHere TABLE_OF_NUMBER,

                          paramValsPerLOVCount TABLE_OF_NUMBER,
                          pValPIVIDs TABLE_OF_NUMBER,
                          pValpiipNames uzy_mig_TABLE_OF_VARCHAR2_200,
                          pValpiipValueTypes TABLE_OF_NUMBER,
                          piipValueLongs TABLE_OF_NUMBER, piipValueReals TABLE_OF_NUMBER,
                          piipValueStrings uzy_mig_TABLE_OF_VARCHAR2_200,

                          featuresPerLOVCount TABLE_OF_NUMBER,
                          fInstPIVIDs TABLE_OF_NUMBER,
                          pifInternalIds TABLE_OF_NUMBER, pifNames uzy_mig_TABLE_OF_VARCHAR2_200,
                          pifTypes TABLE_OF_NUMBER,
                          featureValueTypes TABLE_OF_NUMBER,
                          featureValueNumbers TABLE_OF_NUMBER, featureValueStrings uzy_mig_TABLE_OF_VARCHAR2_200,
                          fAttributes TABLE_OF_NUMBER, fColumnTypes TABLE_OF_NUMBER,
                          fTitles uzy_mig_TABLE_OF_VARCHAR2_200,
                          fOverridable TABLE_OF_NUMBER,
                          fDefinedHere TABLE_OF_NUMBER,

                          depsPerLOVCount TABLE_OF_NUMBER,
                          dInstPIVIDs TABLE_OF_NUMBER,
                          dlinkTypes TABLE_OF_NUMBER,
                          dSuppressed TABLE_OF_NUMBER, depNames uzy_mig_TABLE_OF_VARCHAR2_200,
                          dChildNames uzy_mig_TABLE_OF_VARCHAR2_200,
			  dDgids TABLE_OF_NUMBER,
                          dAttributes TABLE_OF_NUMBER, dColumnTypes TABLE_OF_NUMBER,
                          dTitles uzy_mig_TABLE_OF_VARCHAR2_200,
                          dOverridable TABLE_OF_NUMBER,
                          dDefinedHere TABLE_OF_NUMBER,


                          attrsPerLOVCount TABLE_OF_NUMBER,
                          aInstPIVIDs TABLE_OF_NUMBER,
                          attrDefIds TABLE_OF_NUMBER,
                          attrNames uzy_mig_TABLE_OF_VARCHAR2_200,
                          aAttributes TABLE_OF_NUMBER, aColumnTypes TABLE_OF_NUMBER,
                          aTitles uzy_mig_TABLE_OF_VARCHAR2_200,
                          aOverridable TABLE_OF_NUMBER,
                          aDefinedHere TABLE_OF_NUMBER

                          ) RETURN NUMBER;

  FUNCTION updateAttrStatus ( IlinkDomainId VARCHAR2,
                              success_code NUMBER,

                              piIDs TABLE_OF_NUMBER,
                              pivIDs TABLE_OF_NUMBER,
                              depIDs TABLE_OF_NUMBER ) RETURN NUMBER;

  FUNCTION insertOrUpdateLinks(parentClassName             VARCHAR2,
                           childClassName              VARCHAR2,
                           IlinkDomainId                                VARCHAR2,
                            unit                            VARCHAR2,
                            memlinkida2TypeDefRef       NUMBER,
                            memlinkbranchida2TypeDefRef NUMBER,
                            reflinkida2TypeDefRef       NUMBER,
                            reflinkbranchida2TypeDefRef NUMBER,
                            operInt                     NUMBER,

                           depDGId_arr                 TABLE_OF_NUMBER,
                           depWCId_arr                 TABLE_OF_NUMBER,
                           linkType_arr                TABLE_OF_NUMBER,
                           asStoredChildName_arr       uzy_mig_TABLE_OF_VARCHAR2_200,
                           depType_arr                 TABLE_OF_NUMBER,
                           identifier_arr              TABLE_OF_NUMBER,
                           name_arr                    uzy_mig_TABLE_OF_VARCHAR2_200,
                           placed_arr                  TABLE_OF_NUMBER,
                           quantity_arr                TABLE_OF_NUMBER,
                           ufQuantity_arr              TABLE_OF_NUMBER,
                           required_arr                TABLE_OF_NUMBER,
                           ida3a5_parent_arr           TABLE_OF_NUMBER,
                           ida3b5_child_arr            TABLE_OF_NUMBER,
                           parentDocType_arr          TABLE_OF_NUMBER,
                           childDocType_arr           TABLE_OF_NUMBER,
                           suppressed_arr              TABLE_OF_NUMBER,
                           substitute_arr                                                       TABLE_OF_NUMBER,
                           skeletonMemb_arr           TABLE_OF_NUMBER,
                           uniqueLinkId_arr            TABLE_OF_NUMBER,

                           createdOn_arr               TABLE_OF_DATE,
                           modifiedOn_arr                  TABLE_OF_DATE,
                           uniqueNDId_arr                  uzy_mig_TABLE_OF_VARCHAR2_200,
                           compNum_arr                     TABLE_OF_NUMBER,
                           compRevNum_arr                  TABLE_OF_NUMBER,
                           compLayerIdx_arr                TABLE_OF_NUMBER,

                           rcIsNull_arr                    TABLE_OF_NUMBER,
                           rcGeomRestrRecur_arr            TABLE_OF_NUMBER,
                           rcGeomRestr_arr                 TABLE_OF_NUMBER,
                           rcScope_arr                     TABLE_OF_NUMBER,
                           rcViolRestr_arr                 TABLE_OF_NUMBER,

                           transIsNull_arr                 TABLE_OF_NUMBER,
                           e_00_arr                        TABLE_OF_NUMBER,
                           e_01_arr                        TABLE_OF_NUMBER,
                           e_02_arr                        TABLE_OF_NUMBER,
                           e_10_arr                        TABLE_OF_NUMBER,
                           e_11_arr                        TABLE_OF_NUMBER,
                           e_12_arr                        TABLE_OF_NUMBER,
                           e_20_arr                        TABLE_OF_NUMBER,
                           e_21_arr                        TABLE_OF_NUMBER,
                           e_22_arr                        TABLE_OF_NUMBER,
                           e_30_arr                        TABLE_OF_NUMBER,
                           e_31_arr                        TABLE_OF_NUMBER,
                           e_32_arr                        TABLE_OF_NUMBER,
                           referenceType_arr               uzy_mig_TABLE_OF_VARCHAR2_200
                           ) RETURN NUMBER;

FUNCTION GetNewWCID RETURN NUMBER;

FUNCTION getPIIPValType( ilType number ) RETURN number;

FUNCTION getFeatureValType( ilType number ) RETURN number;

FUNCTION DeleteIBAValuesByHolders(iba_holder_list TABLE_OF_NUMBER,
                                    iba_holder_classname VARCHAR2) RETURN NUMBER;
FUNCTION InsertEPMParameterMapValues(param_map_list IN INSERT_EPM_PARAMETER_MAP_LIST,
                                     iba_holder_classname IN VARCHAR2)
                    RETURN NUMBER;


FUNCTION migInsertAsStoredMembers(as_stored_owner_oid_list IN MIG_EPM_AS_STORED_MEMBER_TABLE,
                                   as_stored_epmmem_oid_list IN MIG_EPM_AS_STORED_MEMBER_TABLE,
                                   as_stored_wtmem_oid_list IN MIG_EPM_AS_STORED_MEMBER_TABLE) RETURN NUMBER;

procedure countEPMObjects(
        ilDomainId IN number,
        sessionId IN varchar2,
        epmDocMCount OUT number,
        epmDocCount OUT number,
        wtDocMCount OUT number,
        wtDocCount OUT number,
        membLinkCount OUT number,
        refLinkCount OUT number,
        fileItemCount OUT number,
        epmBLCountDoc OUT number,
        epmBLCountPart OUT number,
        loCount OUT number,
        lovCount OUT number,
        epmDocMAttrs OUT number,
        epmDocAttrs OUT number,
        linkAttrs OUT number,
        wtPartCount OUT number);

FUNCTION InsertIBAValues(ibaHolderClassName VARCHAR2,
                         referenceClassName VARCHAR2,
                         referenceId NUMBER,

                         floatValueClassName VARCHAR2,
                         booleanValueClassName VARCHAR2,
                         integerValueClassName VARCHAR2,
                         stringValueClassName VARCHAR2,
                         timestampValueClassName VARCHAR2,

                         attrDefCount NUMBER,
                         definitionClassNames uzy_mig_TABLE_OF_VARCHAR2_200,
                         definitionIds TABLE_OF_NUMBER,
                         definitionHIds uzy_mig_TABLE_OF_VARCHAR2_150,

                         boolCount NUMBER,
                         boolHolderIds TABLE_OF_NUMBER,
                         boolAttrDefIds TABLE_OF_NUMBER,
                         boolValues TABLE_OF_NUMBER,

                         float_precision NUMBER,
                         flCount NUMBER,
                         flHolderIds TABLE_OF_NUMBER,
                         flAttrDefIds TABLE_OF_NUMBER,
                         flValues TABLE_OF_NUMBER,

                         intCount NUMBER,
                         intHolderIds TABLE_OF_NUMBER,
                         intAttrDefIds TABLE_OF_NUMBER,
                         intValues TABLE_OF_NUMBER,

                         strCount NUMBER,
                         strHolderIds TABLE_OF_NUMBER,
                         strAttrDefIds TABLE_OF_NUMBER,
                         strValues uzy_mig_TABLE_OF_VARCHAR2_6000,

                         tsCount NUMBER,
                         tsHolderIds TABLE_OF_NUMBER,
                         tsAttrDefIds TABLE_OF_NUMBER,
                         tsValues TABLE_OF_DATE,

                         paramMapClassName VARCHAR2,
                         pMapHolderIds TABLE_OF_NUMBER,
                         pMapNames uzy_mig_TABLE_OF_VARCHAR2_200,
                         pMapDefIds TABLE_OF_NUMBER) RETURN NUMBER;


function checkFlag (status in number, flag in number) return number;
function setEqual (status in number) return number;
function setUnEqual (status in number) return number;
function setCheckForEquality (status in number) return number;

FUNCTION bitor(p_dec1 NUMBER, p_dec2 NUMBER) RETURN NUMBER;
FUNCTION bitxor(p_dec1 NUMBER, p_dec2 NUMBER) RETURN NUMBER;
FUNCTION markForMerge (ilDomainId VARCHAR2) RETURN NUMBER;
PROCEDURE cwpRemoteInfo (ilDomainId VARCHAR2, WCDBLinkName  VARCHAR2);
FUNCTION deleteForRecalculate( cur IN SYS_REFCURSOR, pdomainid IN VARCHAR2, pchunkSize IN NUMBER, delete_pi IN number ) return number;
FUNCTION deleteForRecalculate( pdomainid IN VARCHAR2, pchunkSize IN NUMBER ) return number;
FUNCTION deleteForRecalculate( pdomainid IN VARCHAR2, pchunkSize IN NUMBER, piids IN TABLE_OF_NUMBER) return number;
FUNCTION deleteForRecalculate( pdomainid IN VARCHAR2, pchunkSize IN NUMBER, pstatus IN NUMBER) return number;


/*  Procedure insertInStatusTables(
              ilDomainId          number,
--              piIdArr           MY_TABLE_OF_NUMBER,
--              dMIdArr           MY_TABLE_OF_NUMBER,
--              piStatusArr       MY_TABLE_OF_NUMBER,
 --             pivIdArr          MY_TABLE_OF_NUMBER,
  --            docIdArr          MY_TABLE_OF_NUMBER,
   --           dgIdArr           MY_TABLE_OF_NUMBER,
    --          linkIdArr         MY_TABLE_OF_NUMBER,
              depTypeArr        MY_TABLE_OF_NUMBER  ); */

END MigrationPK;
/

