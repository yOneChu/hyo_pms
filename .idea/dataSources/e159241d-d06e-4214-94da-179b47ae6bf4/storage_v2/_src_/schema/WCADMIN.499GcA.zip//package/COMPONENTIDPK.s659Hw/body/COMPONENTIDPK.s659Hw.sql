create PACKAGE BODY ComponentIdPK IS
PROCEDURE UPDATE_COMPONENT_IDS(part_table_name IN VARCHAR2,
part_usage_link_usage_link IN VARCHAR2) IS
TYPE USAGE_LINK_INFO is REF CURSOR;
USAGE_LINK_INFO_CURSOR USAGE_LINK_INFO;
v_counter NUMBER := 0;
v_parentida2a2 NUMBER := 0;
v_temp_comp_id VARCHAR2(200) := ' ';
cursor_parentida2a2 NUMBER;
cursor_temp_componentid VARCHAR2(200);
cursor_curr_componentid VARCHAR2(200);
cursor_rowid ROWID;
v_sql_select_statement VARCHAR2(600);
v_sql_update_statement VARCHAR2(600);
BEGIN
v_sql_select_statement :=
'select parent_part.ida2a2, ' ||
'parent_part.idA3masterReference || ''_'' || link.ida3b5 || ''_'' ' ||
'|| nvl(link.valueb7, 0) || ''_'' || nvl(link.amountA7, 0), ' ||
'link.componentid, ' || 'link.ROWID ' ||
'from ' || part_usage_link_usage_link || ' link, ' || part_table_name || ' parent_part ' ||
'where link.ida3a5=parent_part.ida2a2 ' ||
'order by 1, 2';
v_sql_update_statement :=
'UPDATE ' || part_usage_link_usage_link ||
' SET componentid = :1 || ''_'' ||  :2 ' ||
'WHERE rowid = :3';
OPEN USAGE_LINK_INFO_CURSOR
FOR v_sql_select_statement;
LOOP
FETCH USAGE_LINK_INFO_CURSOR
INTO cursor_parentida2a2, cursor_temp_componentid, cursor_curr_componentid, cursor_rowid;
EXIT WHEN USAGE_LINK_INFO_CURSOR%NOTFOUND;
IF cursor_temp_componentid = v_temp_comp_id AND cursor_parentida2a2 = v_parentida2a2 THEN
v_counter := v_counter + 1;
ELSE
v_counter := 0;
END IF;
v_temp_comp_id := cursor_temp_componentid;
v_parentida2a2 := cursor_parentida2a2;
IF cursor_curr_componentid IS NULL THEN
EXECUTE IMMEDIATE v_sql_update_statement
USING cursor_temp_componentid, v_counter, cursor_rowid;
END IF;
END LOOP;
CLOSE USAGE_LINK_INFO_CURSOR;
COMMIT;
END UPDATE_COMPONENT_IDS;
END ComponentIdPK;
/

