create TYPE FT_INFO AS OBJECT (
master_id NUMBER,
doc_id  NUMBER
)
/

