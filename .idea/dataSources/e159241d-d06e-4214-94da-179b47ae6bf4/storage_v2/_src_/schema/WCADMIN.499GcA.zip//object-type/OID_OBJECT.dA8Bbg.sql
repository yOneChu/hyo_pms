create TYPE OID_OBJECT AS OBJECT (
   className   VARCHAR2(600),
   id   NUMBER)
/

