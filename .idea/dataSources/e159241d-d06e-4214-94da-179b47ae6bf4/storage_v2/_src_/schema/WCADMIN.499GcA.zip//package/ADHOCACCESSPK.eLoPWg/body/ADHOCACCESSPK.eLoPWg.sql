create Package Body AdHocAccessPK IS
PROCEDURE CopyPermissions(p_source_AdHocControlled IN NUMBER, p_target_AdHocControlled IN NUMBER, p_target_className IN VARCHAR2, p_owner IN VARCHAR2, p_starts_with IN NUMBER) IS
/* Define all variables here. */
v_current_time DATE;
v_id_count NUMBER :=0;
v_oid  NUMBER :=0;
v_wildcard VARCHAR2(1) := '';
v_owner VARCHAR2(200) := p_owner;
v_ae_oid			NUMBER :=0;
v_source_allExceptPrincipal 	NUMBER :=0;
v_source_permissionType	NUMBER :=0;
v_source_owner		VARCHAR2(200) := NULL;
v_source_mask			NUMBER :=0;
v_source_classNameKeyA3	VARCHAR2(200) := NULL;
v_source_principalRef		NUMBER :=0;
/* Define all cursors here. */
CURSOR copy_source_cursor(v_source_AdHocControlled NUMBER, v_owner VARCHAR2, v_wildcard VARCHAR2) IS
SELECT AE.IDA2a2, AE.allExceptPrincipal, AE.permissionType, AE.owner, AE.permissionMask,
AE.classNamekeyA3, AE.ida3a3
FROM   WTAclEntry AE
Where  AE.ida3b3 = v_source_AdHocControlled
AND    AE.owner LIKE v_owner || v_wildcard;
BEGIN
BEGIN
select systimestamp at time zone 'GMT' INTO v_current_time FROM DUAL;
if (p_starts_with = 1) then
v_wildcard := '%';
end if;
if (p_owner IS NULL) then
v_owner := '%';
end if;
/*
* Note: If we decide to require Change Permissions rather than Full Control for
* copying permissions, and only copy those permissions that the current user has,
* then the following needs to change. The user's permission mask would need to be
* passed to this stored procedure and target entry could not be unconditionally
* removed. Only those permissions that the current user has could be added or
* removed from the target object. For example, if p_mask is user's permission mask,
* the target entry's mask should be set to BITAND(v_source_mask, p_mask) and
* the entry should be deleted if the resulting mask is 0.
*/
/* Delete all existing ad hoc entries for the target object with a matching owner */
DELETE FROM WTAclEntry AE
WHERE AE.ida3b3 = p_target_AdHocControlled
AND AE.owner LIKE p_owner || v_wildcard;
/* Get all existing ad hoc entries for the source object with a matching owner */
OPEN copy_source_cursor(p_source_AdHocControlled, v_owner, v_wildcard);
v_id_count := 0;
LOOP
FETCH copy_source_cursor into v_ae_oid, v_source_allExceptPrincipal, v_source_permissionType,
v_source_owner, v_source_mask, v_source_classNameKeyA3, v_source_principalRef;
EXIT WHEN copy_source_cursor%NOTFOUND;
/* Create ad hoc entries for the target objects corresponding to each source entry found */
if v_id_count = 0 then
v_id_count := 100;
select id_sequence.NEXTVAL into v_oid from dual;
end if;
INSERT INTO WTAclEntry (CLASSNAMEKEYB3,IDA3B3,ALLEXCEPTPRINCIPAL,PERMISSIONTYPE,OWNER,
PERMISSIONMASK,CLASSNAMEKEYA3,IDA3A3,CREATESTAMPA2,MARKFORDELETEA2,
MODIFYSTAMPA2,CLASSNAMEA2A2,IDA2A2,UPDATECOUNTA2,UPDATESTAMPA2)
VALUES(p_target_className,p_target_AdHocControlled,v_source_allExceptPrincipal,v_source_permissionType,
v_source_owner,v_source_mask,v_source_classNameKeyA3,v_source_principalRef,v_current_time,0,
v_current_time,'wt.access.WTAclEntry',v_oid,1,v_current_time);
v_id_count := v_id_count - 1;
v_oid := v_oid + 1;
END LOOP;
CLOSE copy_source_cursor;
END;
END CopyPermissions;
/*--------------------------------------------------------------------------------------------------------*/
PROCEDURE MCopyPermissions(p_source_AdHocControlled IN NUMBER, p_target_AdHocControlled_List IN OID_OBJECT_LIST, p_owner IN VARCHAR2, p_starts_with IN NUMBER) IS
/* Define all variables here. */
v_current_time DATE;
v_id_count NUMBER :=0;
v_oid  NUMBER :=0;
v_wildcard VARCHAR2(1) := '';
v_owner VARCHAR2(200) := p_owner;
v_ae_oid			NUMBER :=0;
v_source_allExceptPrincipal 	NUMBER :=0;
v_source_permissionType	NUMBER :=0;
v_source_owner		VARCHAR2(200) := NULL;
v_source_mask			NUMBER :=0;
v_source_classNameKeyA3	VARCHAR2(200) := NULL;
v_source_principalRef		NUMBER :=0;
/* Define all cursors here. */
CURSOR copy_source_cursor(v_source_AdHocControlled NUMBER, v_owner VARCHAR2, v_wildcard VARCHAR2) IS
SELECT AE.IDA2a2, AE.allExceptPrincipal, AE.permissionType, AE.owner, AE.permissionMask,
AE.classNamekeyA3, AE.ida3a3
FROM   WTAclEntry AE
WHERE  AE.ida3b3 = v_source_AdHocControlled
AND    AE.owner LIKE v_owner || v_wildcard;
BEGIN
BEGIN
select systimestamp at time zone 'GMT' INTO v_current_time FROM DUAL;
if (p_starts_with = 1) then
v_wildcard := '%';
end if;
if (p_owner IS NULL) then
v_owner := '%';
end if;
/*
* Note: If we decide to require Change Permissions rather than Full Control for
* copying permissions, and only copy those permissions that the current user has,
* then the following needs to change. The user's permission mask would need to be
* passed to this stored procedure and target entries could not be unconditionally
* removed. Only those permissions that the current user has could be added or
* removed from the target object. For example, if p_mask is user's permission mask,
* the target entry's mask should be set to BITAND(v_source_mask, p_mask) and
* the entry should be deleted if the resulting mask is 0.
*/
/* Delete all existing ad hoc entries for the target objects with a matching owner */
FOR i IN 1..p_target_AdHocControlled_List.COUNT LOOP
DELETE FROM WTAclEntry AE
WHERE AE.ida3b3 = p_target_AdHocControlled_List(i).id
AND AE.owner LIKE p_owner || v_wildcard;
END LOOP;
/* Get all existing ad hoc entries for the source object with a matching owner */
OPEN copy_source_cursor(p_source_AdHocControlled, v_owner, v_wildcard);
v_id_count := 0;
LOOP
FETCH copy_source_cursor into v_ae_oid, v_source_allExceptPrincipal, v_source_permissionType,
v_source_owner, v_source_mask, v_source_classNameKeyA3, v_source_principalRef;
EXIT WHEN copy_source_cursor%NOTFOUND;
/* Create ad hoc entries for the target objects corresponding to each source entry found */
FOR i IN 1..p_target_AdHocControlled_List.COUNT LOOP
if v_id_count = 0 then
v_id_count := 100;
select id_sequence.NEXTVAL into v_oid from dual;
end if;
INSERT INTO WTAclEntry (CLASSNAMEKEYB3,IDA3B3,ALLEXCEPTPRINCIPAL,PERMISSIONTYPE,OWNER,
PERMISSIONMASK,CLASSNAMEKEYA3,IDA3A3,CREATESTAMPA2,MARKFORDELETEA2,
MODIFYSTAMPA2,CLASSNAMEA2A2,IDA2A2,UPDATECOUNTA2,UPDATESTAMPA2)
VALUES(p_target_AdHocControlled_List(i).className,p_target_AdHocControlled_List(i).id,
v_source_allExceptPrincipal,v_source_permissionType,v_source_owner,
v_source_mask,v_source_classNameKeyA3,v_source_principalRef,v_current_time,0,
v_current_time,'wt.access.WTAclEntry',v_oid,1,v_current_time);
v_id_count := v_id_count - 1;
v_oid := v_oid + 1;
END LOOP;
END LOOP;
CLOSE copy_source_cursor;
END;
END MCopyPermissions;
/*--------------------------------------------------------------------------------------------------------*/
PROCEDURE MCopyAllPermissions(p_source_AdHocControlled_List IN OID_OBJECT_LIST, p_target_AdHocControlled_List IN OID_OBJECT_LIST) IS
/* Define all variables here. */
v_current_time DATE;
v_id_count NUMBER :=0;
v_oid  NUMBER :=0;
v_source_AdHocControlled_oid	NUMBER :=0;
v_ae_oid			NUMBER :=0;
v_source_allExceptPrincipal 	NUMBER :=0;
v_source_permissionType	NUMBER :=0;
v_source_owner		VARCHAR2(200) := NULL;
v_source_mask			NUMBER :=0;
v_source_classNameKeyA3	VARCHAR2(200) := NULL;
v_source_principalRef		NUMBER :=0;
/* Define all cursors here. */
CURSOR copy_source_cursor(v_source_AdHocControlled_oid NUMBER) IS
SELECT AE.IDA2a2, AE.allExceptPrincipal, AE.permissionType, AE.owner, AE.permissionMask,
AE.classNamekeyA3, AE.ida3a3
FROM   WTAclEntry AE
WHERE  AE.ida3b3 = v_source_AdHocControlled_oid;
BEGIN
BEGIN
select systimestamp at time zone 'GMT' INTO v_current_time FROM DUAL;
/*
* Note: If we decide to require Change Permissions rather than Full Control for
* copying permissions, and only copy those permissions that the current user has,
* then the following needs to change. The user's permission mask would need to be
* passed to this stored procedure and target entries could not be unconditionally
* removed. Only those permissions that the current user has could be added or
* removed from the target object. For example, if p_mask is user's permission mask,
* the target entry's mask should be set to BITAND(v_source_mask, p_mask) and
* the entry should be deleted if the resulting mask is 0.
*/
/* Delete all existing ad hoc entries for the target objects */
FOR i IN 1..p_target_AdHocControlled_List.COUNT LOOP
DELETE FROM WTAclEntry AE
WHERE AE.ida3b3 = p_target_AdHocControlled_List(i).id;
END LOOP;
FOR i IN 1..p_source_AdHocControlled_List.COUNT LOOP
/* Get all existing ad hoc entries for the source object */
v_source_AdHocControlled_oid := p_source_AdHocControlled_List(i).id;
OPEN copy_source_cursor(v_source_AdHocControlled_oid);
v_id_count := 0;
LOOP
FETCH copy_source_cursor into v_ae_oid, v_source_allExceptPrincipal, v_source_permissionType,
v_source_owner, v_source_mask, v_source_classNameKeyA3, v_source_principalRef;
EXIT WHEN copy_source_cursor%NOTFOUND;
/* Create ad hoc entries for the target object corresponding to each source ad hoc entry found */
if v_id_count = 0 then
v_id_count := 100;
select id_sequence.NEXTVAL into v_oid from dual;
end if;
INSERT INTO WTAclEntry (CLASSNAMEKEYB3,IDA3B3,ALLEXCEPTPRINCIPAL,PERMISSIONTYPE,OWNER,
PERMISSIONMASK,CLASSNAMEKEYA3,IDA3A3,CREATESTAMPA2,MARKFORDELETEA2,
MODIFYSTAMPA2,CLASSNAMEA2A2,IDA2A2,UPDATECOUNTA2,UPDATESTAMPA2)
VALUES(p_target_AdHocControlled_List(i).className,p_target_AdHocControlled_List(i).id,
v_source_allExceptPrincipal,v_source_permissionType,v_source_owner,v_source_mask,
v_source_classNameKeyA3,v_source_principalRef,v_current_time,0,
v_current_time,'wt.access.WTAclEntry',v_oid,1,v_current_time);
v_id_count := v_id_count - 1;
v_oid := v_oid + 1;
END LOOP;
CLOSE copy_source_cursor;
END LOOP;
END;
END MCopyAllPermissions;
/*--------------------------------------------------------------------------------------------------------*/
PROCEDURE ReassignPermissions(p_AdHocControlled IN NUMBER,p_old_principal_ref IN NUMBER, p_new_principal_ref IN NUMBER, p_owner IN VARCHAR2, p_starts_with IN NUMBER) IS
/* Define all variables here. */
v_current_time DATE;
v_wildcard VARCHAR2(1) := '';
v_ae_oid			NUMBER :=0;
v_new_oid			NUMBER :=0;
v_source_owner		VARCHAR2(200) := NULL;
v_source_mask			NUMBER :=0;
/* Define all cursors here. */
CURSOR reassign_cursor(v_oid NUMBER, v_owner VARCHAR2, v_wildcard VARCHAR2, v_old_principal_ref NUMBER) IS
SELECT AE.ida2a2, AE.owner, AE.permissionMask
FROM   WTAclEntry AE
Where  AE.ida3b3 = v_oid
AND    AE.owner LIKE v_owner || v_wildcard
AND    AE.ida3a3 = v_old_principal_ref;
BEGIN
BEGIN
select systimestamp at time zone 'GMT' INTO v_current_time FROM DUAL;
if (p_starts_with = 1) then
v_wildcard := '%';
end if;
OPEN reassign_cursor(p_AdHocControlled, p_owner, v_wildcard, p_old_principal_ref);
LOOP
FETCH reassign_cursor into v_ae_oid,v_source_owner,v_source_mask;
EXIT WHEN reassign_cursor%NOTFOUND;
-- The sub-select SQL Statement should return Zero rows or at most one row
-- Throws an exception, If sub-select returns more than one row
UPDATE WTAclEntry
Set permissionMask = (permissionMask + v_source_mask) - BITAND(permissionMask,v_source_mask), -- Logical Bitwise OR
updatecounta2 = updatecounta2+1,
updatestampa2 = v_current_time,
modifystampa2 = v_current_time
WHERE ida2a2 = (SELECT AE.ida2a2
FROM WTAclEntry AE
WHERE AE.ida3b3 = p_AdHocControlled
AND   AE.owner = v_source_owner
AND   AE.ida3a3 = p_new_principal_ref);
if SQL%NOTFOUND then
/* Move the permission to new Principal. */
UPDATE WTAclEntry
SET ida3a3 = p_new_principal_ref,
updatecounta2 = updatecounta2+1,
updatestampa2 = v_current_time,
modifystampa2 = v_current_time
WHERE ida2a2 = v_ae_oid;
else
/* delete the old principals record */
DELETE FROM WTAclEntry WHERE ida2a2 = v_ae_oid;
end if;
END LOOP;
CLOSE reassign_cursor;
END;
END ReassignPermissions;
/*--------------------------------------------------------------------------------------------------------*/
PROCEDURE RemovePermissions(p_AdHocControlled IN NUMBER, p_owner IN VARCHAR2, p_starts_with IN NUMBER) IS
/* Define all variables here. */
v_wildcard VARCHAR2(1) := '';
BEGIN
BEGIN
if (p_starts_with = 1) then
v_wildcard := '%';
end if;
DELETE  FROM   WTAclEntry AE
WHERE  AE.ida3b3 = p_AdHocControlled
AND    AE.owner LIKE p_owner || v_wildcard;
END;
END RemovePermissions;
/*--------------------------------------------------------------------------------------------------------*/
PROCEDURE MRemovePermissions(p_AdHocControlled_List IN OID_OBJECT_LIST, p_owner IN VARCHAR2, p_starts_with IN NUMBER) IS
/* Define all variables here. */
v_wildcard VARCHAR2(1) := '';
BEGIN
BEGIN
if (p_starts_with = 1) then
v_wildcard := '%';
end if;
FOR i IN 1..p_AdHocControlled_List.COUNT LOOP
DELETE FROM WTAclEntry AE
WHERE AE.ida3b3 = p_AdHocControlled_List(i).id
AND AE.owner LIKE p_owner || v_wildcard;
END LOOP;
END;
END MRemovePermissions;
/*--------------------------------------------------------------------------------------------------------*/
END AdHocAccessPK;
/

