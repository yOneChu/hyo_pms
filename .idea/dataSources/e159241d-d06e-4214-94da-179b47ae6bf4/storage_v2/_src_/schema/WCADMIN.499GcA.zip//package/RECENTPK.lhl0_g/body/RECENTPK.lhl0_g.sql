create Package Body RecentPK IS
PROCEDURE DeleteOldestFromList(keepItems IN NUMBER) IS
/* Define all variables here. */
v_listKeyName VARCHAR2(200) := NULL;
v_idA3A4 NUMBER := NULL;
v_idA2A2 NUMBER := NULL;
v_COUNT NUMBER := NULL;
v_ID_COUNT NUMBER := NULL;
i NUMBER := 0;
/* Define all cursors here. */
CURSOR AllLists IS
SELECT RU.ListKeyName, RU.IDA3A4, count(*)
FROM   RecentUpdate RU
GROUP BY RU.ListKeyName, RU.IDA3A4;
CURSOR ItemsPerList(p_listKeyName VARCHAR2, p_idA3A4 NUMBER) IS
SELECT RU.IDA2A2
FROM   RecentUpdate RU
WHERE ListKeyName = p_listKeyName
AND IDA3A4 = p_idA3A4
ORDER BY MODIFYSTAMPA2 ASC;
TYPE id_table_type IS TABLE OF NUMBER
INDEX BY BINARY_INTEGER;
id_table id_table_type;
BEGIN
--    DBMS_OUTPUT.PUT_LINE( 'From stored procedure: DeleteOldestFromList');
OPEN AllLists;
v_id_count := 0;
LOOP
FETCH AllLists into v_listKeyName,v_idA3A4,v_COUNT;
EXIT WHEN AllLists%NOTFOUND;
--         DBMS_OUTPUT.PUT_LINE( v_listKeyName);
--         DBMS_OUTPUT.PUT_LINE( v_idA3A4);
--         DBMS_OUTPUT.PUT_LINE(v_COUNT);
--         DBMS_OUTPUT.PUT_LINE('----------');
if v_COUNT > keepItems then
i := v_COUNT - keepItems;
OPEN ItemsPerList(v_listKeyName, v_idA3A4);
LOOP
FETCH ItemsPerList into v_idA2A2;
EXIT WHEN AllLists%NOTFOUND;
--            DBMS_OUTPUT.PUT_LINE(v_idA2A2);
--            DBMS_OUTPUT.PUT_LINE(i);
DELETE RECENTUPDATE WHERE IDA2A2 = v_idA2A2;
i := i - 1;
EXIT WHEN (i < 0) ;
END LOOP;
CLOSE ItemsPerList;
end if;
END LOOP;
CLOSE AllLists;
END DeleteOldestFromList;
END RecentPK;
/

