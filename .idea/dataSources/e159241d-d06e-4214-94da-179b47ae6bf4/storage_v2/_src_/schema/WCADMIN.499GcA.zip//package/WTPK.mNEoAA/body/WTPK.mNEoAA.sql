create Package Body WTPK IS
v_timeZoneOffset NUMBER := 0;
PROCEDURE createSequence(
/* Creates a Sequence and ignores Oracle error if it
already exists.
Usage: exec WTPK.createSequence('aSequenceName');
*/
p_sequenceName IN varchar2,
p_startWith  IN NUMBER DEFAULT 1,
p_incrementBy  IN NUMBER DEFAULT 1) IS
v_cursor INTEGER;
v_status INTEGER;
BEGIN
DBMS_OUTPUT.ENABLE(100000);
dropSequence(p_sequenceName);
v_cursor := DBMS_SQL.OPEN_CURSOR;
DBMS_SQL.PARSE(v_cursor,'CREATE SEQUENCE ' || p_sequenceName ||
' START WITH ' || p_startWith ||
' INCREMENT BY ' || p_incrementBy,
DBMS_SQL.NATIVE);
v_status := DBMS_SQL.EXECUTE(v_cursor);
DBMS_OUTPUT.PUT_LINE('Sequence ' ||
p_sequenceName || ' created.');
DBMS_SQL.CLOSE_CURSOR(v_cursor);
EXCEPTION WHEN OTHERS THEN
IF DBMS_SQL.IS_OPEN(v_cursor) THEN
DBMS_SQL.CLOSE_CURSOR(v_cursor);
END IF;
RAISE;
END createSequence;
PROCEDURE dropSequence (
/* Drops the sequence and ignores Oracle error if sequence does not exist.
Usage: exec WTPK.dropSequence('aSequenceName');
*/
p_sequenceName IN VARCHAR2) IS
v_cursor        NUMBER;
v_sequenceString    VARCHAR2(100);
BEGIN
/* Open the cursor for processing. */
v_cursor := DBMS_SQL.OPEN_CURSOR;
/* Drop the table  */
v_sequenceString := 'DROP SEQUENCE ' || p_sequenceName;
/* Parse the 'DROP SEQUENCE' command, which also executes it. Trap the
ORA-2289 error in case the sequence doesn't yet exist. */
BEGIN
-- DBMS_SQL.NATIVE is a constant defined in the package header.
DBMS_SQL.PARSE(v_Cursor, v_sequenceString, DBMS_SQL.NATIVE);
DBMS_OUTPUT.PUT_LINE('Sequence ' ||
p_sequenceName || ' dropped.');
EXCEPTION
WHEN OTHERS THEN
IF SQLCODE != -2289 THEN
RAISE;
END IF;
END;
/* Close the cursor, now that we are finished. */
DBMS_SQL.CLOSE_CURSOR(v_cursor);
EXCEPTION
WHEN OTHERS THEN
/* Close the cursor first, then reraise the error so it is
propagated out. */
DBMS_SQL.CLOSE_CURSOR(v_cursor);
RAISE;
END dropSequence;
PROCEDURE dropTable (
/* Drops the table and ignores Oracle error if table does
not exist.
Usage: exec WTPK.dropTable('aTablename');
*/
p_TableName IN VARCHAR2) IS
v_cursor        NUMBER;
v_dropString    VARCHAR2(100);
BEGIN
/* Open the cursor for processing. */
v_cursor := DBMS_SQL.OPEN_CURSOR;
/* Drop the table  */
v_DropString := 'DROP TABLE ' || p_TableName || ' cascade constraint';
/* Parse the 'DROP TABLE' command, which also executes it. Trap the
ORA-942 error in case the table doesn't yet exist. */
BEGIN
-- DBMS_SQL.NATIVE is a constant defined in the package header.
DBMS_SQL.PARSE(v_Cursor, v_DropString, DBMS_SQL.NATIVE);
DBMS_OUTPUT.PUT_LINE('Table ' ||
p_TableName || ' dropped.');
EXCEPTION
WHEN OTHERS THEN
IF SQLCODE != -942 THEN
RAISE;
END IF;
END;
/* Close the cursor, now that we are finished. */
DBMS_SQL.CLOSE_CURSOR(v_cursor);
EXCEPTION
WHEN OTHERS THEN
/* Close the cursor first, then reraise the error so it is
propagated out. */
DBMS_SQL.CLOSE_CURSOR(v_cursor);
RAISE;
END dropTable;
PROCEDURE dropView (
/* Drops the view and ignores Oracle error if view does not exist.
Usage: exec WTPK.dropView('aViewname');
*/
p_ViewName IN VARCHAR2) IS
v_cursor        NUMBER;
v_dropString    VARCHAR2(100);
BEGIN
/* Open the cursor for processing. */
v_cursor := DBMS_SQL.OPEN_CURSOR;
/* Drop the view  */
v_DropString := 'DROP VIEW ' || p_ViewName;
/* Parse the 'DROP VIEW' command, which also executes it. Trap the
ORA-942 error in case the view doesn't yet exist. */
BEGIN
-- DBMS_SQL.NATIVE is a constant defined in the package header.
DBMS_SQL.PARSE(v_Cursor, v_DropString, DBMS_SQL.NATIVE);
DBMS_OUTPUT.PUT_LINE('View ' || p_ViewName || ' dropped.');
EXCEPTION
WHEN OTHERS THEN
IF SQLCODE != -942 THEN
RAISE;
END IF;
END;
/* Close the cursor, now that we are finished. */
DBMS_SQL.CLOSE_CURSOR(v_cursor);
EXCEPTION
WHEN OTHERS THEN
/* Close the cursor first, then reraise the error so it is
propagated out. */
DBMS_SQL.CLOSE_CURSOR(v_cursor);
RAISE;
END dropView;
PROCEDURE dropPackage (
/* Drops the package and ignores Oracle error if package does not exist.
Usage: exec WTPK.dropPackage('aPackagename');
*/
p_PackageName IN VARCHAR2) IS
v_cursor        NUMBER;
v_dropString    VARCHAR2(100);
BEGIN
/* Open the cursor for processing. */
v_cursor := DBMS_SQL.OPEN_CURSOR;
/* Drop the package  */
v_DropString := 'DROP PACKAGE ' || p_PackageName;
/* Parse the 'DROP PACKAGE' command, which also executes it. Trap the
ORA-4043 error in case the package doesn't yet exist. */
BEGIN
-- DBMS_SQL.NATIVE is a constant defined in the package header.
DBMS_SQL.PARSE(v_Cursor, v_DropString, DBMS_SQL.NATIVE);
DBMS_OUTPUT.PUT_LINE('Package ' || p_PackageName || ' dropped.');
EXCEPTION
WHEN OTHERS THEN
IF SQLCODE != -4043 THEN
RAISE;
END IF;
END;
/* Close the cursor, now that we are finished. */
DBMS_SQL.CLOSE_CURSOR(v_cursor);
EXCEPTION
WHEN OTHERS THEN
/* Close the cursor first, then reraise the error so it is
propagated out. */
DBMS_SQL.CLOSE_CURSOR(v_cursor);
RAISE;
END dropPackage;
PROCEDURE dropType (
/* Drops the type and ignores Oracle error if table does
not exist.
Usage: exec WTPK.dropType('aTypename');
*/
p_TypeName IN VARCHAR2) IS
v_cursor        NUMBER;
v_dropString    VARCHAR2(100);
BEGIN
/* Open the cursor for processing. */
v_cursor := DBMS_SQL.OPEN_CURSOR;
/* Drop the type  */
v_DropString := 'DROP TYPE ' || p_TypeName;
/* Parse the 'DROP TYPE' command, which also executes it. Trap the
ORA-4043 error in case the table doesn't yet exist. */
BEGIN
-- DBMS_SQL.NATIVE is a constant defined in the package header.
DBMS_SQL.PARSE(v_Cursor, v_DropString, DBMS_SQL.NATIVE);
DBMS_OUTPUT.PUT_LINE('Type ' ||
p_TypeName || ' dropped.');
EXCEPTION
WHEN OTHERS THEN
IF SQLCODE != -4043 THEN
RAISE;
END IF;
END;
/* Close the cursor, now that we are finished. */
DBMS_SQL.CLOSE_CURSOR(v_cursor);
EXCEPTION
WHEN OTHERS THEN
/* Close the cursor first, then reraise the error so it is
propagated out. */
DBMS_SQL.CLOSE_CURSOR(v_cursor);
RAISE;
END dropType;
PROCEDURE dropIndex (
/* Drops the Index and ignores Oracle error if Index does  not exist.
Usage: exec WTPK.dropIndex('aIndexname');
*/
p_IndexName IN VARCHAR2) IS
v_cursor        NUMBER;
v_dropString    VARCHAR2(100);
BEGIN
/* Open the cursor for processing. */
v_cursor := DBMS_SQL.OPEN_CURSOR;
/* Drop the index  */
v_DropString := 'DROP INDEX ' || p_IndexName;
/* Parse the 'DROP INDEX' command, which also executes it. Trap the
ORA-01418 error in case the index doesn't yet exist. */
BEGIN
-- DBMS_SQL.NATIVE is a constant defined in the package header.
DBMS_SQL.PARSE(v_Cursor, v_DropString, DBMS_SQL.NATIVE);
DBMS_OUTPUT.PUT_LINE('Index ' ||
p_IndexName || ' dropped.');
EXCEPTION
WHEN OTHERS THEN
IF SQLCODE != -1418 THEN
RAISE;
END IF;
END;
/* Close the cursor, now that we are finished. */
DBMS_SQL.CLOSE_CURSOR(v_cursor);
EXCEPTION
WHEN OTHERS THEN
/* Close the cursor first, then reraise the error so it is
propagated out. */
DBMS_SQL.CLOSE_CURSOR(v_cursor);
RAISE;
END dropIndex;
PROCEDURE dropFKConstraint (
/* Drops the foreign key constraint and ignores Oracle error if constraint does  not exist.
Usage: exec WTPK.dropFKConstraint('aTablename','aConstraintName');
*/
p_tableName IN VARCHAR2,
p_FKConstraintName IN VARCHAR2) IS
v_cursor        NUMBER;
v_dropString    VARCHAR2(100);
BEGIN
/* Open the cursor for processing. */
v_cursor := DBMS_SQL.OPEN_CURSOR;
/* Drop the constraint  */
v_DropString := 'ALTER TABLE ' || p_tableName || ' DROP CONSTRAINT ' || p_FKConstraintName;
/* Parse the 'ALTER TABLE' command, which also executes it. Trap the
ORA-02443 error in case the constraint doesn't yet exist. */
BEGIN
-- DBMS_SQL.NATIVE is a constant defined in the package header.
DBMS_SQL.PARSE(v_Cursor, v_DropString, DBMS_SQL.NATIVE);
DBMS_OUTPUT.PUT_LINE('Constraint ' ||
p_FKConstraintName || ' dropped.');
EXCEPTION
WHEN OTHERS THEN
IF SQLCODE != -2443 AND SQLCODE != -942 THEN
RAISE;
END IF;
END;
/* Close the cursor, now that we are finished. */
DBMS_SQL.CLOSE_CURSOR(v_cursor);
EXCEPTION
WHEN OTHERS THEN
/* Close the cursor first, then reraise the error so it is
propagated out. */
DBMS_SQL.CLOSE_CURSOR(v_cursor);
RAISE;
END dropFKConstraint;
END WTPK;
/

