create package body epm_family_table_utils as
type epmArrayId is table of number index by binary_integer;
--  type epmArrayVarchar200 is table of varchar2(200) index by binary_integer;
--
procedure getFTMaster(p_docs          in out nocopy table_of_number,
p_ft_master_id     out table_of_number,
p_ft_master_name   out table_of_varchar2) is
v_calls_number number;
begin
getFTMaster(p_docs,p_ft_master_id,p_ft_master_name,v_calls_number);
end;
--
procedure getFTMaster(p_docs          in out nocopy table_of_number,
p_ft_master_id     out table_of_number,
p_ft_master_name   out table_of_varchar2,
p_num_calls        out number) is
--    v_id            number;
--    v_master_id     number;
--    v_master_name   varchar2(200);
v_ft_members table_of_number;
v_calls_counter number;
v_sql_text         varchar2(32767);
--    doc_ft_map      epmArrayId;
--    ft_master_map   epmArrayId;
--    master_name_map epmArrayVarchar200;
begin
v_ft_members     := table_of_number();
p_ft_master_id   := table_of_number();
p_ft_master_name := table_of_varchar2();
for v_calls_counter in 1..20
loop
begin
v_sql_text := 'select a.inst_id ,c.ida2a2, c.name
from (select a.column_value inst_id , (select b.ida3b5 from epmContainedIn b
where b.ida3a5 = a.column_value
and exists ( select 1 from epmSepFamilyTable d where d.ida2a2 = b.ida3b5 )
and rownum < 2 ) ftid
from (select /*+ cardinality ( a_i ' || p_docs.count || ' ) */
a_i.column_value from table(cast(:1 as table_of_number)) a_i where rownum > 0) a
) a , epmSepFamilyTable b , epmSepFamilyTableMaster c
where b.ida2a2 = a.ftid
and c.ida2a2 = b.ida3masterreference';
EXECUTE IMMEDIATE v_sql_text BULK COLLECT INTO v_ft_members , p_ft_master_id , p_ft_master_name USING p_docs;
p_num_calls := v_calls_counter;
exit; -- exits the loop if no exception
exception
when others
then
null;
end;
end loop;-- end of exception loop
p_docs := v_ft_members;
--    for i in 1..p_docs.count loop
--
--      select min(a.ida3b5) into v_id from epmContainedIn a
--      where a.ida3a5 = p_docs(i)
--        and exists ( select 1 from epmSepFamilyTable b where b.ida2a2 = a.ida3b5 )
--        and rownum < 2 ;
--
--      if v_id > 0 then
--        doc_ft_map(p_docs(i)) := v_id;
--
--        if not ft_master_map.exists(v_id) then
--
--          select c.ida2a2, c.name into v_master_id , v_master_name
--          from  epmSepFamilyTable b , epmSepFamilyTableMaster c
--          where b.ida2a2 = v_id
--            and c.ida2a2 = b.ida3familytablemasterreferen;
--
--          ft_master_map(v_id)          := v_master_id;
--          master_name_map(v_master_id) := v_master_name;
--        end if;
--      end if;
--    end loop;
--    --
--    p_docs.delete;
--    if doc_ft_map.count > 0 then
--      p_docs.extend(doc_ft_map.count);
--      p_ft_master_id.extend(doc_ft_map.count);
--      p_ft_master_name.extend(doc_ft_map.count);
--
--      v_id := doc_ft_map.first;
--      for i in 1..doc_ft_map.count loop
--        p_docs(i) := v_id;
--        p_ft_master_id(i)   := ft_master_map( doc_ft_map(v_id) );
--        p_ft_master_name(i) := master_name_map(p_ft_master_id(i));
--
--        v_id := doc_ft_map.next(v_id);
--      end loop;
--    end if;
end;
--
procedure getFTCompatible(p_docs             table_of_number,
p_proj_id          number,
p_proj_classes     table_of_varchar2,
p_masters      out table_of_number,
p_compatibles  out table_of_table_of_number,
p_content      out table_of_table_of_number,
p_completes    out table_of_table_of_number,
p_num_calls    out table_of_number) is
v_docs           table_of_number := p_docs;
v_master_ids     table_of_number ;
v_master_names   table_of_varchar2;
v_obj_count      epmArrayId;
v_members        table_of_number := table_of_number();
v_compatibles    table_of_number ;
v_calls_counter  number;
v_sql_text         varchar2(32767);
begin
p_masters     := table_of_number();
p_compatibles := table_of_table_of_number();
p_content     := table_of_table_of_number();
p_completes   := table_of_table_of_number();
p_num_calls   := table_of_number();
getFTMaster(v_docs,v_master_ids,v_master_names,v_calls_counter);
p_num_calls.extend;
p_num_calls(p_num_calls.count) := v_calls_counter;
if v_docs.count > 0 then
for v_calls_counter in 1..20
loop
begin
v_sql_text :=
'select a.column_value ida2a2, count(*)
from table(cast(:1 as table_of_number)) a
where rownum > 0
group by a.column_value';
EXECUTE IMMEDIATE v_sql_text BULK COLLECT INTO p_masters , v_obj_count USING v_master_ids;
p_num_calls.extend;
p_num_calls(p_num_calls.count) := v_calls_counter;
exit; -- exits the loop if no exception
exception
when others
then
null;
end;
end loop;-- end of exception loop
for i in 1.. p_masters.count loop
-- collect ft members which belong to p_masters(i)
v_members.delete;
for j in 1..v_master_ids.count loop
if v_master_ids(j) = p_masters(i) then
v_members.extend;
v_members(v_members.count) := v_docs(j);
end if;
end loop;
p_content.extend;
p_content(p_content.count) := v_members;
--        dbms_output.put_line('master ftid='||p_masters(i)||' '||v_members(i)||' v_members.count='||v_members.count);
for v_calls_counter in 1..20
loop
begin
v_sql_text := 'select d.ida3b5
from  epmContainedIn d
where d.ida3b5 in ( select a.ida2a2 from epmSepFamilyTable a
where  a.ida3masterreference = :1 )
and d.ida3a5 in ( select /*+ cardinality ( b ' || v_members.count || ' ) */ b.column_value from table(cast(:2 as table_of_number)) b where (rownum > 0) )
group by d.ida3b5 having count (*) = :3' ;
EXECUTE IMMEDIATE v_sql_text BULK COLLECT INTO v_compatibles USING p_masters(i), v_members, v_obj_count(i);
p_num_calls.extend;
p_num_calls(p_num_calls.count) := v_calls_counter;
exit; -- exits the loop if no exception
exception
when others
then
null;
end;
end loop; -- end of exception loop
p_compatibles.extend;
if p_proj_id > 0 or p_proj_classes.count > 0 then
for v_calls_counter in 1..20
loop
begin
v_sql_text :=
'select b.ida3b5
from epmContainedIn b,
epmDocument c
where b.ida3b5 in (select /*+ cardinality (a ' || v_compatibles.count || ') */
a.column_value acv
from table(cast(:1 as table_of_number)) a where rownum > 0)
and c.ida2a2 = b.ida3a5
and (c.IDA3CONTAINERREFERENCE = :2)
union
select b.ida3b5
from epmContainedIn b,
epmDocument c
where b.ida3b5 in (select /*+ cardinality (a ' || v_compatibles.count || ') */
a.column_value acv
from table(cast(:3 as table_of_number)) a where rownum > 0)
and c.ida2a2 = b.ida3a5
and not exists ( select null
from (select /*+ cardinality (d_i ' || p_proj_classes.count || ') */
d_i.column_value dcv
from table(cast(:4 as table_of_varchar2)) d_i where rownum > 0) d
where c.CLASSNAMEKEYCONTAINERREFEREN = d.dcv )';
EXECUTE IMMEDIATE v_sql_text BULK COLLECT INTO p_compatibles(p_compatibles.count)
USING v_compatibles,  p_proj_id, v_compatibles, p_proj_classes;
p_num_calls.extend;
p_num_calls(p_num_calls.count) := v_calls_counter;
exit; -- exits the loop if no exception
exception
when others
then
null;
end;
end loop; -- end of exception loop
else
p_compatibles(p_compatibles.count) := v_compatibles;
end if;
p_completes.extend;
for v_calls_counter in 1..20
loop
begin
v_sql_text := 'select a.ida3b5
from  epmContainedIn a
where a.ida3b5 in ( select /*+ cardinality ( b ' || p_compatibles(p_compatibles.count).count || ' ) */ b.column_value from table(cast(:1 as table_of_number)) b where (rownum > 0) )
group by a.ida3b5 having count (*) = :2';
EXECUTE IMMEDIATE v_sql_text BULK COLLECT INTO p_completes(p_completes.count) USING p_compatibles(p_compatibles.count), v_obj_count(i);
p_num_calls.extend;
p_num_calls(p_num_calls.count) := v_calls_counter;
exit; -- exits the loop if no exception
exception
when others
then
null;
end;
end loop; -- end of exception loop
end loop; -- end of for loop
end if;
end;
--
end;
/

