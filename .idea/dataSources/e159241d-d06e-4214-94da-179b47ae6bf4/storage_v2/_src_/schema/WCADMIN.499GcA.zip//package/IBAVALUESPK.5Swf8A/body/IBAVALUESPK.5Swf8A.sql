create Package Body IBAValuesPK IS
FUNCTION getMatchingStringValue(definitionID1 NUMBER, definitionID2 NUMBER, value VARCHAR2) RETURN VARCHAR2 IS
BEGIN
IF definitionID1 = definitionID2 THEN
RETURN value;
ELSE
RETURN NULL;
END IF;
END getMatchingStringValue;
FUNCTION getMatchingNumberValue(definitionID1 NUMBER, definitionID2 NUMBER, value NUMBER) RETURN NUMBER IS
BEGIN
IF definitionID1 = definitionID2 THEN
RETURN value;
ELSE
RETURN NULL;
END IF;
END getMatchingNumberValue;
FUNCTION getMatchingDateValue(definitionID1 NUMBER, definitionID2 NUMBER, value DATE) RETURN DATE IS
BEGIN
IF definitionID1 = definitionID2 THEN
RETURN value;
ELSE
RETURN NULL;
END IF;
END getMatchingDateValue;
/* Use a Binary search to find the new oid for an old oid */
/* (Can't use Associative Arrays since BINARY_INTEGER is limited to 32 bit values) */
FUNCTION getNewOid(sorted_id_oid_object_list ID_OID_OBJECT_LIST, oldoid NUMBER) RETURN NUMBER IS
newoid NUMBER;
low INTEGER;
mid INTEGER;
high INTEGER;
binary_search_error EXCEPTION;
BEGIN
BEGIN
if (sorted_id_oid_object_list.last = 1) then
if (sorted_id_oid_object_list(1).id = oldoid) then
return sorted_id_oid_object_list(1).oid.id;
else
raise binary_search_error;
end if;
end if;
newoid := -1;
low := 1;
high := sorted_id_oid_object_list.last;
loop
if (low >= high) then
exit;
end if;
mid := (low + high) / 2;
if (sorted_id_oid_object_list(mid).id > oldoid) then
high:= mid - 1;
else
if ( sorted_id_oid_object_list(mid).id < oldoid) then
low := mid + 1;
else
return sorted_id_oid_object_list(mid).oid.id;
end if;
end if;
end loop;
if (( low <= sorted_id_oid_object_list.last) and ( sorted_id_oid_object_list(low).id = oldoid)) then
newoid := sorted_id_oid_object_list(low).oid.id;
end if;
IF newoid = -1 THEN
RAISE binary_search_error;
else
return newoid;
END IF;
EXCEPTION  -- exception handlers begin
WHEN binary_search_error THEN  -- handles failed insert
RAISE_APPLICATION_ERROR(-20505, 'BINARY SEARCH FAILED ' || oldoid);
END;
END getNewOid;
/* This implementation of CopyIBAValuesMultiple uses advanced PL/SQL features to perform IBA copy forward */
/* QA observed error: java.sql.SQLException: ORA-00902: invalid datatype                                  */
/* SPR is 1548729. I suspect a bug in Oracle that may be fixed in future.                                 */
FUNCTION BulkCopyIBAValuesMultiple(i_id_oid_object_list IN ID_OID_OBJECT_LIST) RETURN NUMBER IS
TYPE booleanVTab is TABLE OF booleanvalue%rowtype;
TYPE floatVTab is TABLE OF floatvalue%rowtype;
TYPE integerVTab is TABLE OF integervalue%rowtype;
TYPE ratioVTab is TABLE OF ratiovalue%rowtype;
TYPE referenceVTab is TABLE OF referencevalue%rowtype;
TYPE stringVTab is TABLE OF stringvalue%rowtype;
TYPE timestampVTab is TABLE OF timestampvalue%rowtype;
TYPE unitVTab is TABLE OF unitvalue%rowtype;
TYPE urlVTab is TABLE OF urlvalue%rowtype;
booleanValues booleanVTab;
floatValues floatVTab;
integerValues integerVTab;
ratioValues ratioVTab;
referenceValues referenceVTab;
stringValues stringVTab;
timestampValues timestampVTab;
unitValues unitVTab;
urlvalues urlVTab;
v_old_ida3a4s TABLE_OF_NUMBER := TABLE_OF_NUMBER();
v_current_time DATE;
v_id_count NUMBER :=0;
v_oid  NUMBER :=0;
new_ida3a4 NUMBER := 0;
prev_ida3a4 NUMBER := 0;
v_loop_count NUMBER := 1;
v_copy_count NUMBER := 0;
dynstr VARCHAR2(256);
cur SYS_REFCURSOR;
sorted_id_oid_object_list ID_OID_OBJECT_LIST;
reference_id_oid_object_list ID_OID_OBJECT_LIST := ID_OID_OBJECT_LIST();
sorted_ref_oid_object_list ID_OID_OBJECT_LIST;
BEGIN
BEGIN
SELECT sysdate INTO v_current_time FROM DUAL;
LOOP
IF NOT i_id_oid_object_list.EXISTS(v_loop_count) THEN
EXIT;
END IF;
v_old_ida3a4s.extend;
v_old_ida3a4s(v_loop_count) := i_id_oid_object_list(v_loop_count).id;
v_loop_count := v_loop_count + 1;
END LOOP;
/* ORA-00902: invalid datatype was thrown when executing this line */
select cast (multiset (select * FROM TABLE( i_id_oid_object_list) ORDER BY 1) as ID_OID_OBJECT_LIST) INTO sorted_id_oid_object_list from dual ;
dynstr := 'SELECT * FROM referencevalue WHERE IDA3A4 IN (SELECT /*+ CARDINALITY(t ' || cardinality(v_old_ida3a4s) || ') */ * from TABLE(:v_old_ida3a4s) t) order by ida3a4';
OPEN cur FOR dynstr USING IN v_old_ida3a4s;
FETCH cur BULK COLLECT INTO referenceValues;
CLOSE cur;
if referenceValues.count > 0 then
v_loop_count := 1;
for i in referenceValues.first .. referenceValues.last
loop
if v_id_count = 0 then
v_id_count := 100;
select id_sequence.NEXTVAL into v_oid from dual;
end if;
referenceValues(i).createstampa2 := v_current_time;
referenceValues(i).modifystampa2 := v_current_time;
referenceValues(i).markfordeletea2 := 0;
reference_id_oid_object_list.extend;
reference_id_oid_object_list(v_loop_count) := ID_OID_OBJECT(referenceValues(i).ida2a2, OID_OBJECT('wt.iba.value.ReferenceValue', v_oid));
referenceValues(i).ida2a2 := 	v_oid;
referenceValues(i).updatecounta2 := 1;
referenceValues(i).updatestampa2 := v_current_time;
if (referenceValues(i).ida3a4 <> prev_ida3a4) then
prev_ida3a4 := referenceValues(i).ida3a4;
new_ida3a4 := getNewOid(sorted_id_oid_object_list, referenceValues(i).ida3a4);
end if;
referenceValues(i).ida3a4 := new_ida3a4;
v_id_count := v_id_count - 1;
v_oid := v_oid + 1;
v_loop_count := v_loop_count + 1;
end loop;
select cast (multiset (select * FROM TABLE( reference_id_oid_object_list) ORDER BY 1) as ID_OID_OBJECT_LIST) INTO sorted_ref_oid_object_list from dual ;
FORALL j IN referenceValues.FIRST..referenceValues.LAST
insert into referenceValue values referenceValues(j) ;
FOR k IN referenceValues.FIRST..referenceValues.LAST
LOOP
v_copy_count := v_copy_count + SQL%BULK_ROWCOUNT(k);
END LOOP;
referenceValues.DELETE;
end if;
dynstr := 'SELECT * FROM booleanvalue WHERE IDA3A4 IN (SELECT /*+ CARDINALITY(t ' || cardinality(v_old_ida3a4s) || ') */ * from TABLE(:v_old_ida3a4s) t) order by ida3a4';
OPEN cur FOR dynstr USING IN v_old_ida3a4s;
FETCH cur BULK COLLECT INTO booleanValues;
CLOSE cur;
if booleanValues.count > 0 then
prev_ida3a4 := 0;
for i in booleanValues.first .. booleanValues.last
loop
if v_id_count = 0 then
v_id_count := 100;
select id_sequence.NEXTVAL into v_oid from dual;
end if;
booleanValues(i).createstampa2 := v_current_time;
booleanValues(i).modifystampa2 := v_current_time;
booleanValues(i).markfordeletea2 := 0;
booleanValues(i).ida2a2 := 	v_oid;
booleanValues(i).updatecounta2 := 1;
booleanValues(i).updatestampa2 := v_current_time;
if (booleanValues(i).ida3a4 <> prev_ida3a4) then
prev_ida3a4 := booleanValues(i).ida3a4;
new_ida3a4 := getNewOid(sorted_id_oid_object_list, booleanValues(i).ida3a4);
end if;
booleanValues(i).ida3a4 := new_ida3a4;
if (booleanValues(i).ida3a5 <> 0) then
booleanValues(i).ida3a5 := getNewOid(sorted_ref_oid_object_list, booleanValues(i).ida3a5 );
end if;
v_id_count := v_id_count - 1;
v_oid := v_oid + 1;
end loop;
FORALL j IN booleanValues.FIRST..booleanValues.LAST
insert into booleanvalue values booleanValues(j) ;
FOR k IN booleanValues.FIRST..booleanValues.LAST
LOOP
v_copy_count := v_copy_count + SQL%BULK_ROWCOUNT(k);
END LOOP;
booleanValues.DELETE;
end if;
dynstr := 'SELECT * FROM floatvalue WHERE IDA3A4 IN (SELECT /*+ CARDINALITY(t ' || cardinality(v_old_ida3a4s) || ') */ * from TABLE(:v_old_ida3a4s) t) order by ida3a4';
OPEN cur FOR dynstr USING IN v_old_ida3a4s;
FETCH cur BULK COLLECT INTO floatValues;
CLOSE cur;
if floatValues.count > 0 then
prev_ida3a4 := 0;
for i in floatValues.first .. floatValues.last
loop
if v_id_count = 0 then
v_id_count := 100;
select id_sequence.NEXTVAL into v_oid from dual;
end if;
floatValues(i).createstampa2 := v_current_time;
floatValues(i).modifystampa2 := v_current_time;
floatValues(i).markfordeletea2 := 0;
floatValues(i).ida2a2 := 	v_oid;
floatValues(i).updatecounta2 := 1;
floatValues(i).updatestampa2 := v_current_time;
if (floatValues(i).ida3a4 <> prev_ida3a4) then
prev_ida3a4 := floatValues(i).ida3a4;
new_ida3a4 := getNewOid(sorted_id_oid_object_list, floatValues(i).ida3a4);
end if;
floatValues(i).ida3a4 := new_ida3a4;
if (floatValues(i).ida3a5 <> 0) then
floatValues(i).ida3a5 := getNewOid(sorted_ref_oid_object_list, floatValues(i).ida3a5 );
end if;
v_id_count := v_id_count - 1;
v_oid := v_oid + 1;
end loop;
FORALL j IN floatValues.FIRST..floatValues.LAST
insert into floatValue values floatValues(j) ;
FOR k IN floatValues.FIRST..floatValues.LAST
LOOP
v_copy_count := v_copy_count + SQL%BULK_ROWCOUNT(k);
END LOOP;
floatValues.delete;
end if;
dynstr := 'SELECT * FROM integervalue WHERE IDA3A4 IN (SELECT /*+ CARDINALITY(t ' || cardinality(v_old_ida3a4s) || ') */ * from TABLE(:v_old_ida3a4s) t) order by ida3a4';
OPEN cur FOR dynstr USING IN v_old_ida3a4s;
FETCH cur BULK COLLECT INTO integerValues;
CLOSE cur;
if integerValues.count > 0 then
prev_ida3a4 := 0;
for i in integerValues.first .. integerValues.last
loop
if v_id_count = 0 then
v_id_count := 100;
select id_sequence.NEXTVAL into v_oid from dual;
end if;
integerValues(i).createstampa2 := v_current_time;
integerValues(i).modifystampa2 := v_current_time;
integerValues(i).markfordeletea2 := 0;
integerValues(i).ida2a2 := 	v_oid;
integerValues(i).updatecounta2 := 1;
integerValues(i).updatestampa2 := v_current_time;
if (integerValues(i).ida3a4 <> prev_ida3a4) then
prev_ida3a4 := integerValues(i).ida3a4;
new_ida3a4 := getNewOid(sorted_id_oid_object_list, integerValues(i).ida3a4);
end if;
integerValues(i).ida3a4 := new_ida3a4;
if (integerValues(i).ida3a5 <> 0) then
integerValues(i).ida3a5 := getNewOid(sorted_ref_oid_object_list, integerValues(i).ida3a5 );
end if;
v_id_count := v_id_count - 1;
v_oid := v_oid + 1;
end loop;
FORALL j IN integerValues.FIRST..integerValues.LAST
insert into integerValue values integerValues(j) ;
FOR k IN integerValues.FIRST..integerValues.LAST
LOOP
v_copy_count := v_copy_count + SQL%BULK_ROWCOUNT(k);
END LOOP;
integerValues.DELETE;
end if;
dynstr := 'SELECT * FROM ratiovalue WHERE IDA3A4 IN (SELECT /*+ CARDINALITY(t ' || cardinality(v_old_ida3a4s) || ') */ * from TABLE(:v_old_ida3a4s) t) order by ida3a4';
OPEN cur FOR dynstr USING IN v_old_ida3a4s;
FETCH cur BULK COLLECT INTO ratioValues;
CLOSE cur;
if ratioValues.count > 0 then
prev_ida3a4 := 0;
for i in ratioValues.first .. ratioValues.last
loop
if v_id_count = 0 then
v_id_count := 100;
select id_sequence.NEXTVAL into v_oid from dual;
end if;
ratioValues(i).createstampa2 := v_current_time;
ratioValues(i).modifystampa2 := v_current_time;
ratioValues(i).markfordeletea2 := 0;
ratioValues(i).ida2a2 := 	v_oid;
ratioValues(i).updatecounta2 := 1;
ratioValues(i).updatestampa2 := v_current_time;
if (ratioValues(i).ida3a4 <> prev_ida3a4) then
prev_ida3a4 := ratioValues(i).ida3a4;
new_ida3a4 := getNewOid(sorted_id_oid_object_list, ratioValues(i).ida3a4);
end if;
ratioValues(i).ida3a4 := new_ida3a4;
if (ratioValues(i).ida3a5 <> 0) then
ratioValues(i).ida3a5 := getNewOid(sorted_ref_oid_object_list, ratioValues(i).ida3a5 );
end if;
v_id_count := v_id_count - 1;
v_oid := v_oid + 1;
end loop;
FORALL j IN ratioValues.FIRST..ratioValues.LAST
insert into ratioValue values ratioValues(j) ;
FOR k IN ratioValues.FIRST..ratioValues.LAST
LOOP
v_copy_count := v_copy_count + SQL%BULK_ROWCOUNT(k);
END LOOP;
ratioValues.DELETE;
end if;
dynstr := 'SELECT * FROM stringvalue WHERE IDA3A4 IN (SELECT /*+ CARDINALITY(t ' || cardinality(v_old_ida3a4s) || ') */ * from TABLE(:v_old_ida3a4s) t) order by ida3a4';
OPEN cur FOR dynstr USING IN v_old_ida3a4s;
FETCH cur BULK COLLECT INTO stringValues;
CLOSE cur;
if stringValues.count > 0 then
prev_ida3a4 := 0;
for i in stringValues.first .. stringValues.last
loop
if v_id_count = 0 then
v_id_count := 100;
select id_sequence.NEXTVAL into v_oid from dual;
end if;
stringValues(i).createstampa2 := v_current_time;
stringValues(i).modifystampa2 := v_current_time;
stringValues(i).markfordeletea2 := 0;
stringValues(i).ida2a2 := 	v_oid;
stringValues(i).updatecounta2 := 1;
stringValues(i).updatestampa2 := v_current_time;
if (stringValues(i).ida3a4 <> prev_ida3a4) then
prev_ida3a4 := stringValues(i).ida3a4;
new_ida3a4 := getNewOid(sorted_id_oid_object_list, stringValues(i).ida3a4);
end if;
stringValues(i).ida3a4 := new_ida3a4;
if (stringValues(i).ida3a5 <> 0) then
stringValues(i).ida3a5 := getNewOid(sorted_ref_oid_object_list, stringValues(i).ida3a5 );
end if;
v_id_count := v_id_count - 1;
v_oid := v_oid + 1;
end loop;
FORALL j IN stringValues.FIRST..stringValues.LAST
insert into stringvalue values stringValues(j) ;
FOR k IN stringValues.FIRST..stringValues.LAST
LOOP
v_copy_count := v_copy_count + SQL%BULK_ROWCOUNT(k);
END LOOP;
stringValues.DELETE;
end if;
dynstr := 'SELECT * FROM timestampvalue WHERE IDA3A4 IN (SELECT /*+ CARDINALITY(t ' || cardinality(v_old_ida3a4s) || ') */ * from TABLE(:v_old_ida3a4s) t) order by ida3a4';
OPEN cur FOR dynstr USING IN v_old_ida3a4s;
FETCH cur BULK COLLECT INTO timestampValues;
CLOSE cur;
if timestampValues.count > 0 then
prev_ida3a4 := 0;
for i in timestampValues.first .. timestampValues.last
loop
if v_id_count = 0 then
v_id_count := 100;
select id_sequence.NEXTVAL into v_oid from dual;
end if;
timestampValues(i).createstampa2 := v_current_time;
timestampValues(i).modifystampa2 := v_current_time;
timestampValues(i).markfordeletea2 := 0;
timestampValues(i).ida2a2 := 	v_oid;
timestampValues(i).updatecounta2 := 1;
timestampValues(i).updatestampa2 := v_current_time;
if (timestampValues(i).ida3a4 <> prev_ida3a4) then
prev_ida3a4 := timestampValues(i).ida3a4;
new_ida3a4 := getNewOid(sorted_id_oid_object_list, timestampValues(i).ida3a4);
end if;
timestampValues(i).ida3a4 := new_ida3a4;
if (timestampValues(i).ida3a5 <> 0) then
timestampValues(i).ida3a5 := getNewOid(sorted_ref_oid_object_list, timestampValues(i).ida3a5 );
end if;
v_id_count := v_id_count - 1;
v_oid := v_oid + 1;
end loop;
FORALL j IN timestampValues.FIRST..timestampValues.LAST
insert into timestampvalue values timestampValues(j) ;
FOR k IN timestampValues.FIRST..timestampValues.LAST
LOOP
v_copy_count := v_copy_count + SQL%BULK_ROWCOUNT(k);
END LOOP;
timestampValues.DELETE;
end if;
dynstr := 'SELECT * FROM unitvalue WHERE IDA3A4 IN (SELECT /*+ CARDINALITY(t ' || cardinality(v_old_ida3a4s) || ') */ * from TABLE(:v_old_ida3a4s) t) order by ida3a4';
OPEN cur FOR dynstr USING IN v_old_ida3a4s;
FETCH cur BULK COLLECT INTO unitValues;
CLOSE cur;
if unitValues.count > 0 then
prev_ida3a4 := 0;
for i in unitValues.first .. unitValues.last
loop
if v_id_count = 0 then
v_id_count := 100;
select id_sequence.NEXTVAL into v_oid from dual;
end if;
unitValues(i).createstampa2 := v_current_time;
unitValues(i).modifystampa2 := v_current_time;
unitValues(i).markfordeletea2 := 0;
unitValues(i).ida2a2 := 	v_oid;
unitValues(i).updatecounta2 := 1;
unitValues(i).updatestampa2 := v_current_time;
if (unitValues(i).ida3a4 <> prev_ida3a4) then
prev_ida3a4 := unitValues(i).ida3a4;
new_ida3a4 := getNewOid(sorted_id_oid_object_list, unitValues(i).ida3a4);
end if;
unitValues(i).ida3a4 := new_ida3a4;
if (unitValues(i).ida3a5 <> 0) then
unitValues(i).ida3a5 := getNewOid(sorted_ref_oid_object_list, unitValues(i).ida3a5 );
end if;
v_id_count := v_id_count - 1;
v_oid := v_oid + 1;
end loop;
FORALL j IN unitValues.FIRST..unitValues.LAST
insert into unitvalue values unitValues(j) ;
FOR k IN unitValues.FIRST..unitValues.LAST
LOOP
v_copy_count := v_copy_count + SQL%BULK_ROWCOUNT(k);
END LOOP;
unitValues.DELETE;
end if;
dynstr := 'SELECT * FROM urlvalue WHERE IDA3A4 IN (SELECT /*+ CARDINALITY(t ' || cardinality(v_old_ida3a4s) || ') */ * from TABLE(:v_old_ida3a4s) t) order by ida3a4';
OPEN cur FOR dynstr USING IN v_old_ida3a4s;
FETCH cur BULK COLLECT INTO urlValues;
CLOSE cur;
if urlValues.count > 0 then
prev_ida3a4 := 0;
for i in urlValues.first .. urlValues.last
loop
if v_id_count = 0 then
v_id_count := 100;
select id_sequence.NEXTVAL into v_oid from dual;
end if;
urlValues(i).createstampa2 := v_current_time;
urlValues(i).modifystampa2 := v_current_time;
urlValues(i).markfordeletea2 := 0;
urlValues(i).ida2a2 := 	v_oid;
urlValues(i).updatecounta2 := 1;
urlValues(i).updatestampa2 := v_current_time;
if (urlValues(i).ida3a4 <> prev_ida3a4) then
prev_ida3a4 := urlValues(i).ida3a4;
new_ida3a4 := getNewOid(sorted_id_oid_object_list, urlValues(i).ida3a4);
end if;
urlValues(i).ida3a4 := new_ida3a4;
if (urlValues(i).ida3a5 <> 0) then
urlValues(i).ida3a5 := getNewOid(sorted_ref_oid_object_list, urlValues(i).ida3a5 );
end if;
v_id_count := v_id_count - 1;
v_oid := v_oid + 1;
end loop;
FORALL j IN urlValues.FIRST..urlValues.LAST
insert into urlvalue values urlValues(j) ;
FOR k IN urlValues.FIRST..urlValues.LAST
LOOP
v_copy_count := v_copy_count + SQL%BULK_ROWCOUNT(k);
END LOOP;
urlValues.DELETE;
end if;
return v_copy_count;
END;
END BulkCopyIBAValuesMultiple;
FUNCTION CopyIBAValues (i_old_IBAHolder_oid IN NUMBER, i_new_IBAHolder_oid IN NUMBER,i_new_IBAHolder_classname IN VARCHAR2) RETURN NUMBER IS
/* Define all variables here. */
v_current_time DATE;
v_id_count NUMBER :=0;
v_oid  NUMBER :=0;
v_loop_count NUMBER :=1;
v_value_oid                 NUMBER :=0;
v_reference_classname       VARCHAR2(200) := NULL;
v_reference_oid             NUMBER :=0;
v_hierarchy_id              VARCHAR2(150) := NULL;
v_def_classname             VARCHAR2(200) := NULL;
v_def_oid                   NUMBER :=0;
v_boolean_value             NUMBER :=0;
v_float_value               NUMBER :=0;
v_integer_value             NUMBER :=0;
v_ratio_value               NUMBER :=0;
v_string_value              VARCHAR2(4000) := NULL;
v_string_value2             VARCHAR2(4000) := NULL;
v_timestamp_value           DATE;
v_unit_value                NUMBER :=0;
v_url_value                 VARCHAR2(4000) := NULL;
v_reference_id              VARCHAR2(500) := NULL;
v_wtprecision               NUMBER :=0;
v_denominator               NUMBER :=0;
v_description               VARCHAR2(4000) := NULL;
TYPE ref_oid_map_record_type IS RECORD
( old_oid   ReferenceValue.ida2a2%TYPE,
new_oid   ReferenceValue.ida2a2%TYPE);
TYPE ref_oid_map_table_type IS TABLE OF ref_oid_map_record_type
INDEX BY BINARY_INTEGER;
ref_oid_map_table ref_oid_map_table_type;
/* Define all cursors here. */
CURSOR boolean_cursor(v_oid NUMBER) IS
SELECT CLASSNAMEKEYA5,IDA3A5,HIERARCHYIDA6,CLASSNAMEKEYA6,IDA3A6,VALUE
FROM   BooleanValue
WHERE  IDA3A4 = v_oid;
CURSOR float_cursor(v_oid NUMBER) IS
SELECT CLASSNAMEKEYA5,IDA3A5,HIERARCHYIDA6,CLASSNAMEKEYA6,IDA3A6,WTPRECISION,VALUE
FROM   FloatValue
WHERE  IDA3A4 = v_oid;
CURSOR integer_cursor(v_oid NUMBER) IS
SELECT CLASSNAMEKEYA5,IDA3A5,HIERARCHYIDA6,CLASSNAMEKEYA6,IDA3A6,VALUE
FROM   IntegerValue
WHERE  IDA3A4 = v_oid;
CURSOR ratio_cursor(v_oid NUMBER) IS
SELECT CLASSNAMEKEYA5,IDA3A5,HIERARCHYIDA6,CLASSNAMEKEYA6,IDA3A6,DENOMINATOR,VALUE
FROM   RatioValue
WHERE  IDA3A4 = v_oid;
CURSOR string_cursor(v_oid NUMBER) IS
SELECT CLASSNAMEKEYA5,IDA3A5,HIERARCHYIDA6,CLASSNAMEKEYA6,IDA3A6,VALUE,VALUE2
FROM   StringValue
WHERE  IDA3A4 = v_oid;
CURSOR timestamp_cursor(v_oid NUMBER) IS
SELECT CLASSNAMEKEYA5,IDA3A5,HIERARCHYIDA6,CLASSNAMEKEYA6,IDA3A6,VALUE
FROM   TimestampValue
WHERE  IDA3A4 = v_oid;
CURSOR unit_cursor(v_oid NUMBER) IS
SELECT CLASSNAMEKEYA5,IDA3A5,HIERARCHYIDA6,CLASSNAMEKEYA6,IDA3A6,WTPRECISION,VALUE
FROM   UnitValue
WHERE  IDA3A4 = v_oid;
CURSOR url_cursor(v_oid NUMBER) IS
SELECT CLASSNAMEKEYA5,IDA3A5,HIERARCHYIDA6,CLASSNAMEKEYA6,IDA3A6,DESCRIPTION,VALUE
FROM   URLValue
WHERE  IDA3A4 = v_oid;
CURSOR reference_cursor(v_oid NUMBER) IS
SELECT IDA2A2,HIERARCHYIDA5,CLASSNAMEKEYA5,IDA3A5,CLASSNAMEKEYB5,IDA3B5,REFERENCEIDB5
FROM   ReferenceValue
WHERE  IDA3A4 = v_oid;
BEGIN
BEGIN
SELECT sysdate INTO v_current_time FROM DUAL;
/*--Copy IBA Values in REFERENCEVALUE--------------------------------------------------------------------------*/
OPEN reference_cursor(i_old_IBAHolder_oid);
v_id_count := 0;
v_loop_count :=1;
LOOP
FETCH reference_cursor into v_value_oid,v_hierarchy_id,v_def_classname,v_def_oid,v_reference_classname,v_reference_oid,
v_reference_id;
EXIT WHEN reference_cursor%NOTFOUND;
if v_id_count = 0 then
v_id_count := 100;
select id_sequence.NEXTVAL into v_oid from dual;
end if;
/* insert reference value oids into map table */
/* these are used to correctly update the contextual values reference keys */
ref_oid_map_table(v_loop_count).old_oid := v_value_oid;
ref_oid_map_table(v_loop_count).new_oid := v_oid;
/* Insert new values with new sequence values. */
INSERT INTO REFERENCEValue (HIERARCHYIDA5,CLASSNAMEKEYA5,IDA3A5,
CLASSNAMEKEYA4,IDA3A4,
CLASSNAMEKEYB5,IDA3B5,REFERENCEIDB5,
CREATESTAMPA2,MODIFYSTAMPA2,CLASSNAMEA2A2,IDA2A2,
UPDATECOUNTA2,UPDATESTAMPA2,MARKFORDELETEA2)
VALUES(v_hierarchy_id,v_def_classname,v_def_oid,
i_new_IBAHolder_classname,i_new_IBAHolder_oid,
v_reference_classname,v_reference_oid,v_reference_id,
v_current_time,v_current_time,'wt.iba.value.ReferenceValue',v_oid,1,v_current_time,0);
v_id_count := v_id_count - 1;
v_oid := v_oid + 1;
v_loop_count := v_loop_count + 1;
END LOOP;
CLOSE reference_cursor;
/*--Copy IBA Values in BOOLEANVALUE---------------------------------------------*/
OPEN boolean_cursor(i_old_IBAHolder_oid);
v_id_count := 0;
LOOP
FETCH boolean_cursor into v_reference_classname,v_reference_oid,v_hierarchy_id,v_def_classname,v_def_oid,
v_boolean_value;
EXIT WHEN boolean_cursor%NOTFOUND;
/* if value is a dependent value, swap the old reference oid with the newly copied reference oid */
/* from the reference oid map table */
if v_reference_oid = 0 then
v_reference_oid := NULL;
end if;
if v_reference_oid IS NOT NULL then
v_loop_count := 1;
LOOP
if NOT ref_oid_map_table.EXISTS(v_loop_count) then
v_reference_oid := NULL;
EXIT;
end if;
if ref_oid_map_table(v_loop_count).old_oid = v_reference_oid then
v_reference_oid := ref_oid_map_table(v_loop_count).new_oid;
EXIT;
end if;
v_loop_count := v_loop_count + 1;
END LOOP;
end if;
if v_id_count = 0 then
v_id_count := 100;
select id_sequence.NEXTVAL into v_oid from dual;
end if;
/* Insert new values with new sequence values. */
INSERT INTO BooleanValue (CLASSNAMEKEYA5,IDA3A5,HIERARCHYIDA6,
CLASSNAMEKEYA6,IDA3A6,CLASSNAMEKEYA4,IDA3A4,CREATESTAMPA2,
MODIFYSTAMPA2,CLASSNAMEA2A2,IDA2A2,UPDATECOUNTA2,UPDATESTAMPA2,
VALUE,MARKFORDELETEA2)
VALUES(v_reference_classname,v_reference_oid,v_hierarchy_id,
v_def_classname,v_def_oid,i_new_IBAHolder_classname,i_new_IBAHolder_oid,v_current_time,
v_current_time,'wt.iba.value.BooleanValue',v_oid,1,v_current_time,
v_boolean_value,0);
v_id_count := v_id_count - 1;
v_oid := v_oid + 1;
END LOOP;
CLOSE boolean_cursor;
/*--Copy IBA Values in FLOATVALUE-------------------------------------------*/
OPEN float_cursor(i_old_IBAHolder_oid);
v_id_count := 0;
LOOP
FETCH float_cursor into v_reference_classname,v_reference_oid,v_hierarchy_id,v_def_classname,v_def_oid,
v_wtprecision,v_float_value;
EXIT WHEN float_cursor%NOTFOUND;
/* if value is a dependent value, swap the old reference oid with the newly copied reference oid */
/* from the reference oid map table */
if v_reference_oid = 0 then
v_reference_oid := NULL;
end if;
if v_reference_oid IS NOT NULL then
v_loop_count := 1;
LOOP
if NOT ref_oid_map_table.EXISTS(v_loop_count) then
v_reference_oid := NULL;
EXIT;
end if;
if ref_oid_map_table(v_loop_count).old_oid = v_reference_oid then
v_reference_oid := ref_oid_map_table(v_loop_count).new_oid;
EXIT;
end if;
v_loop_count := v_loop_count + 1;
END LOOP;
end if;
if v_id_count = 0 then
v_id_count := 100;
select id_sequence.NEXTVAL into v_oid from dual;
end if;
/* Insert new values with new sequence values. */
INSERT INTO FloatValue (CLASSNAMEKEYA5,IDA3A5,HIERARCHYIDA6,
CLASSNAMEKEYA6,IDA3A6,WTPRECISION,CLASSNAMEKEYA4,IDA3A4,CREATESTAMPA2,
MODIFYSTAMPA2,CLASSNAMEA2A2,IDA2A2,UPDATECOUNTA2,UPDATESTAMPA2,
VALUE,MARKFORDELETEA2)
VALUES(v_reference_classname,v_reference_oid,v_hierarchy_id,
v_def_classname,v_def_oid,v_wtprecision,i_new_IBAHolder_classname,i_new_IBAHolder_oid,v_current_time,
v_current_time,'wt.iba.value.FloatValue',v_oid,1,v_current_time,
v_float_value,0);
v_id_count := v_id_count - 1;
v_oid := v_oid + 1;
END LOOP;
CLOSE float_cursor;
/*--Copy IBA Values in INTEGERVALUE-------------------------------------------------------------------*/
OPEN integer_cursor(i_old_IBAHolder_oid);
v_id_count := 0;
LOOP
FETCH integer_cursor into v_reference_classname,v_reference_oid,v_hierarchy_id,v_def_classname,v_def_oid,
v_integer_value;
EXIT WHEN integer_cursor%NOTFOUND;
/* if value is a dependent value, swap the old reference oid with the newly copied reference oid */
/* from the reference oid map table */
if v_reference_oid = 0 then
v_reference_oid := NULL;
end if;
if v_reference_oid IS NOT NULL then
v_loop_count := 1;
LOOP
if NOT ref_oid_map_table.EXISTS(v_loop_count) then
v_reference_oid := NULL;
EXIT;
end if;
if ref_oid_map_table(v_loop_count).old_oid = v_reference_oid then
v_reference_oid := ref_oid_map_table(v_loop_count).new_oid;
EXIT;
end if;
v_loop_count := v_loop_count + 1;
END LOOP;
end if;
if v_id_count = 0 then
v_id_count := 100;
select id_sequence.NEXTVAL into v_oid from dual;
end if;
/* Insert new values with new sequence values. */
INSERT INTO IntegerValue (CLASSNAMEKEYA5,IDA3A5,HIERARCHYIDA6,
CLASSNAMEKEYA6,IDA3A6,CLASSNAMEKEYA4,IDA3A4,CREATESTAMPA2,
MODIFYSTAMPA2,CLASSNAMEA2A2,IDA2A2,UPDATECOUNTA2,UPDATESTAMPA2,
VALUE,MARKFORDELETEA2)
VALUES(v_reference_classname,v_reference_oid,v_hierarchy_id,
v_def_classname,v_def_oid,i_new_IBAHolder_classname,i_new_IBAHolder_oid,v_current_time,
v_current_time,'wt.iba.value.IntegerValue',v_oid,1,v_current_time,
v_integer_value,0);
v_id_count := v_id_count - 1;
v_oid := v_oid + 1;
END LOOP;
CLOSE integer_cursor;
/*--Copy IBA Values in RATIOVALUE--------------------------------------------------------------------------*/
OPEN ratio_cursor(i_old_IBAHolder_oid);
v_id_count := 0;
LOOP
FETCH ratio_cursor into v_reference_classname,v_reference_oid,v_hierarchy_id,v_def_classname,v_def_oid,
v_denominator,v_ratio_value;
EXIT WHEN ratio_cursor%NOTFOUND;
/* if value is a dependent value, swap the old reference oid with the newly copied reference oid */
/* from the reference oid map table */
if v_reference_oid = 0 then
v_reference_oid := NULL;
end if;
if v_reference_oid IS NOT NULL then
v_loop_count := 1;
LOOP
if NOT ref_oid_map_table.EXISTS(v_loop_count) then
v_reference_oid := NULL;
EXIT;
end if;
if ref_oid_map_table(v_loop_count).old_oid = v_reference_oid then
v_reference_oid := ref_oid_map_table(v_loop_count).new_oid;
EXIT;
end if;
v_loop_count := v_loop_count + 1;
END LOOP;
end if;
if v_id_count = 0 then
v_id_count := 100;
select id_sequence.NEXTVAL into v_oid from dual;
end if;
/* Insert new values with new sequence values. */
INSERT INTO RatioValue (CLASSNAMEKEYA5,IDA3A5,HIERARCHYIDA6,
CLASSNAMEKEYA6,IDA3A6,DENOMINATOR,CLASSNAMEKEYA4,IDA3A4,CREATESTAMPA2,
MODIFYSTAMPA2,CLASSNAMEA2A2,IDA2A2,UPDATECOUNTA2,UPDATESTAMPA2,
VALUE,MARKFORDELETEA2)
VALUES(v_reference_classname,v_reference_oid,v_hierarchy_id,
v_def_classname,v_def_oid,v_denominator,i_new_IBAHolder_classname,i_new_IBAHolder_oid,v_current_time,
v_current_time,'wt.iba.value.RatioValue',v_oid,1,v_current_time,
v_ratio_value,0);
v_id_count := v_id_count - 1;
v_oid := v_oid + 1;
END LOOP;
CLOSE ratio_cursor;
/*--Copy IBA Values in STRINGVALUE--------------------------------------------------------------------------*/
OPEN string_cursor(i_old_IBAHolder_oid);
v_id_count := 0;
LOOP
FETCH string_cursor into v_reference_classname,v_reference_oid,v_hierarchy_id,v_def_classname,
v_def_oid,v_string_value,v_string_value2;
EXIT WHEN string_cursor%NOTFOUND;
/* if value is a dependent value, swap the old reference oid with the newly copied reference oid */
/* from the reference oid map table */
if v_reference_oid = 0 then
v_reference_oid := NULL;
end if;
if v_reference_oid IS NOT NULL then
v_loop_count := 1;
LOOP
if NOT ref_oid_map_table.EXISTS(v_loop_count) then
v_reference_oid := NULL;
EXIT;
end if;
if ref_oid_map_table(v_loop_count).old_oid = v_reference_oid then
v_reference_oid := ref_oid_map_table(v_loop_count).new_oid;
EXIT;
end if;
v_loop_count := v_loop_count + 1;
END LOOP;
end if;
if v_id_count = 0 then
v_id_count := 100;
select id_sequence.NEXTVAL into v_oid from dual;
end if;
/* Insert new values with new sequence values. */
INSERT INTO StringValue (CLASSNAMEKEYA5,IDA3A5,HIERARCHYIDA6,
CLASSNAMEKEYA6,IDA3A6,CLASSNAMEKEYA4,IDA3A4,CREATESTAMPA2,
MODIFYSTAMPA2,CLASSNAMEA2A2,IDA2A2,UPDATECOUNTA2,UPDATESTAMPA2,
VALUE,VALUE2,MARKFORDELETEA2)
VALUES(v_reference_classname,v_reference_oid,v_hierarchy_id,
v_def_classname,v_def_oid,i_new_IBAHolder_classname,i_new_IBAHolder_oid,v_current_time,
v_current_time,'wt.iba.value.StringValue',v_oid,1,v_current_time,
v_string_value, v_string_value2,0);
v_id_count := v_id_count - 1;
v_oid := v_oid + 1;
END LOOP;
CLOSE string_cursor;
/*--Copy IBA Values in TIMESTAMPVALUE--------------------------------------------------------------------------*/
OPEN timestamp_cursor(i_old_IBAHolder_oid);
v_id_count := 0;
LOOP
FETCH timestamp_cursor into v_reference_classname,v_reference_oid,v_hierarchy_id,v_def_classname,v_def_oid,
v_timestamp_value;
EXIT WHEN timestamp_cursor%NOTFOUND;
/* if value is a dependent value, swap the old reference oid with the newly copied reference oid */
/* from the reference oid map table */
if v_reference_oid = 0 then
v_reference_oid := NULL;
end if;
if v_reference_oid IS NOT NULL then
v_loop_count := 1;
LOOP
if NOT ref_oid_map_table.EXISTS(v_loop_count) then
v_reference_oid := NULL;
EXIT;
end if;
if ref_oid_map_table(v_loop_count).old_oid = v_reference_oid then
v_reference_oid := ref_oid_map_table(v_loop_count).new_oid;
EXIT;
end if;
v_loop_count := v_loop_count + 1;
END LOOP;
end if;
if v_id_count = 0 then
v_id_count := 100;
select id_sequence.NEXTVAL into v_oid from dual;
end if;
/* Insert new values with new sequence values. */
INSERT INTO TimestampValue (CLASSNAMEKEYA5,IDA3A5,HIERARCHYIDA6,
CLASSNAMEKEYA6,IDA3A6,CLASSNAMEKEYA4,IDA3A4,CREATESTAMPA2,
MODIFYSTAMPA2,CLASSNAMEA2A2,IDA2A2,UPDATECOUNTA2,UPDATESTAMPA2,
VALUE,MARKFORDELETEA2)
VALUES(v_reference_classname,v_reference_oid,v_hierarchy_id,
v_def_classname,v_def_oid,i_new_IBAHolder_classname,i_new_IBAHolder_oid,v_current_time,
v_current_time,'wt.iba.value.TimestampValue',v_oid,1,v_current_time,
v_timestamp_value,0);
v_id_count := v_id_count - 1;
v_oid := v_oid + 1;
END LOOP;
CLOSE timestamp_cursor;
/*--Copy IBA Values in UNITVALUE--------------------------------------------------------------------------*/
OPEN unit_cursor(i_old_IBAHolder_oid);
v_id_count := 0;
LOOP
FETCH unit_cursor into v_reference_classname,v_reference_oid,v_hierarchy_id,v_def_classname,v_def_oid,
v_wtprecision,v_unit_value;
EXIT WHEN unit_cursor%NOTFOUND;
/* if value is a dependent value, swap the old reference oid with the newly copied reference oid */
/* from the reference oid map table */
if v_reference_oid = 0 then
v_reference_oid := NULL;
end if;
if v_reference_oid IS NOT NULL then
v_loop_count := 1;
LOOP
if NOT ref_oid_map_table.EXISTS(v_loop_count) then
v_reference_oid := NULL;
EXIT;
end if;
if ref_oid_map_table(v_loop_count).old_oid = v_reference_oid then
v_reference_oid := ref_oid_map_table(v_loop_count).new_oid;
EXIT;
end if;
v_loop_count := v_loop_count + 1;
END LOOP;
end if;
if v_id_count = 0 then
v_id_count := 100;
select id_sequence.NEXTVAL into v_oid from dual;
end if;
/* Insert new values with new sequence values. */
INSERT INTO UnitValue (CLASSNAMEKEYA5,IDA3A5,HIERARCHYIDA6,
CLASSNAMEKEYA6,IDA3A6,WTPRECISION,CLASSNAMEKEYA4,IDA3A4,CREATESTAMPA2,
MODIFYSTAMPA2,CLASSNAMEA2A2,IDA2A2,UPDATECOUNTA2,UPDATESTAMPA2,
VALUE,MARKFORDELETEA2)
VALUES(v_reference_classname,v_reference_oid,v_hierarchy_id,
v_def_classname,v_def_oid,v_wtprecision,i_new_IBAHolder_classname,i_new_IBAHolder_oid,v_current_time,
v_current_time,'wt.iba.value.UnitValue',v_oid,1,v_current_time,
v_unit_value,0);
v_id_count := v_id_count - 1;
v_oid := v_oid + 1;
END LOOP;
CLOSE unit_cursor;
/*--Copy IBA Values in URLVALUE--------------------------------------------------------------------------*/
OPEN url_cursor(i_old_IBAHolder_oid);
v_id_count := 0;
LOOP
FETCH url_cursor into v_reference_classname,v_reference_oid,v_hierarchy_id,v_def_classname,v_def_oid,
v_description,v_url_value;
EXIT WHEN url_cursor%NOTFOUND;
/* if value is a dependent value, swap the old reference oid with the newly copied reference oid */
/* from the reference oid map table */
if v_reference_oid = 0 then
v_reference_oid := NULL;
end if;
if v_reference_oid IS NOT NULL then
v_loop_count := 1;
LOOP
if NOT ref_oid_map_table.EXISTS(v_loop_count) then
v_reference_oid := NULL;
EXIT;
end if;
if ref_oid_map_table(v_loop_count).old_oid = v_reference_oid then
v_reference_oid := ref_oid_map_table(v_loop_count).new_oid;
EXIT;
end if;
v_loop_count := v_loop_count + 1;
END LOOP;
end if;
if v_id_count = 0 then
v_id_count := 100;
select id_sequence.NEXTVAL into v_oid from dual;
end if;
/* Insert new values with new sequence values. */
INSERT INTO URLValue (CLASSNAMEKEYA5,IDA3A5,HIERARCHYIDA6,
CLASSNAMEKEYA6,IDA3A6,DESCRIPTION,CLASSNAMEKEYA4,IDA3A4,CREATESTAMPA2,
MODIFYSTAMPA2,CLASSNAMEA2A2,IDA2A2,UPDATECOUNTA2,UPDATESTAMPA2,
VALUE,MARKFORDELETEA2)
VALUES(v_reference_classname,v_reference_oid,v_hierarchy_id,
v_def_classname,v_def_oid,v_description,i_new_IBAHolder_classname,i_new_IBAHolder_oid,v_current_time,
v_current_time,'wt.iba.value.URLValue',v_oid,1,v_current_time,
v_url_value,0);
v_id_count := v_id_count - 1;
v_oid := v_oid + 1;
END LOOP;
CLOSE url_cursor;
END;
RETURN 0;
END CopyIBAValues;
FUNCTION CopyIBAValuesMultiple(i_id_oid_object_list IN ID_OID_OBJECT_LIST) RETURN NUMBER IS
v_loop_count NUMBER := 1;
v_return NUMBER := 0;
v_copy_return NUMBER := 0;
BEGIN
BEGIN
LOOP
IF NOT i_id_oid_object_list.EXISTS(v_loop_count) THEN
EXIT;
END IF;
v_copy_return := CopyIBAValues(i_id_oid_object_list(v_loop_count).id,
i_id_oid_object_list(v_loop_count).oid.id,
i_id_oid_object_list(v_loop_count).oid.classname);
v_return := v_return + v_copy_return;
v_loop_count := v_loop_count + 1;
END LOOP;
END;
RETURN v_return;
END CopyIBAValuesMultiple;
END IBAValuesPK;
/

