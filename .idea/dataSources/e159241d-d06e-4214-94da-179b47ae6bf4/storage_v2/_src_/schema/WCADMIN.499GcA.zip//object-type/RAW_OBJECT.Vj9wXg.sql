create TYPE RAW_OBJECT AS OBJECT (
   blobData   BLOB,
   blobLength   NUMBER)
/

