create trigger CLEANUPIBACTXVALFORREF_TRIGGER
    after delete
    on REFERENCEVALUE
    for each row
BEGIN
DELETE FROM StringValue
WHERE  idA3A5 = :old.IDA2A2;
DELETE FROM FloatValue
WHERE  idA3A5 = :old.IDA2A2;
DELETE FROM UnitValue
WHERE  idA3A5 = :old.IDA2A2;
DELETE FROM TimestampValue
WHERE  idA3A5 = :old.IDA2A2;
DELETE FROM RatioValue
WHERE  idA3A5 = :old.IDA2A2;
DELETE FROM IntegerValue
WHERE  idA3A5 = :old.IDA2A2;
DELETE FROM BooleanValue
WHERE  idA3A5 = :old.IDA2A2;
DELETE FROM URLValue
WHERE  idA3A5 = :old.IDA2A2;
END;
/

