create type WTACLENTRY_INS_VALUES as object(AdHocControlled_classname VARCHAR2(200), AdHocControlled_refid NUMBER, owner VARCHAR2(200), permissionmask NUMBER, principal_classname VARCHAR2(200), principal_refid NUMBER)
/

