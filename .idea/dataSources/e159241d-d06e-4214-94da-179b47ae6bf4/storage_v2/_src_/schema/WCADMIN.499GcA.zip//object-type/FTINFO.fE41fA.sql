create TYPE FTInfo AS OBJECT (
   doc_id   NUMBER,
   master_id   NUMBER)
/

