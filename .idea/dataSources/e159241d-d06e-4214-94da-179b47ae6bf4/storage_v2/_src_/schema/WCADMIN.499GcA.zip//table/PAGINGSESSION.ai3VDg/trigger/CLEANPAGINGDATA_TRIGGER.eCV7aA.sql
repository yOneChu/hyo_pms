create trigger CLEANPAGINGDATA_TRIGGER
    after delete
    on PAGINGSESSION
    for each row
BEGIN
DELETE FROM pageResults
WHERE  sessionId = :old.IDA2A2;
DELETE FROM ExtendedPageResults
WHERE  sessionId = :old.IDA2A2;
END;
/

