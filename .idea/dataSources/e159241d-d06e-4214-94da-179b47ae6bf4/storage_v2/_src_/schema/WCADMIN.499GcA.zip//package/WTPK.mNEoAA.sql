create PACKAGE WTPK IS
PROCEDURE createSequence(p_sequenceName IN VARCHAR2,
p_startWith  IN NUMBER DEFAULT 1,
p_incrementBy  IN NUMBER DEFAULT 1);
PROCEDURE dropSequence(p_sequenceName IN VARCHAR2);
PROCEDURE dropPackage(p_packageName IN VARCHAR2);
PROCEDURE dropView(p_ViewName IN VARCHAR2);
PROCEDURE dropTable(p_TableName IN VARCHAR2);
PROCEDURE dropType(p_TypeName IN VARCHAR2);
PROCEDURE dropIndex(p_IndexName IN VARCHAR2);
PROCEDURE dropFKConstraint (p_tableName IN VARCHAR2,p_FKConstraintName IN VARCHAR2);
END WTPK;
/

