create procedure heal_itr_folder_memberlink (v_lasthealedtimestamp IN date, v_error OUT varchar2) is

   v_healable varchar2(100);
   v_max_run_cnt number;
   v_rows_updated number;
   v_sqlstmt varchar2(8000);
   type refcur is ref cursor;
   c_hifml4 refcur;

 TYPE fetch_array_master IS TABLE OF MIG$FOLMLDOC%ROWTYPE;
 s_array_fts fetch_array_master;

begin

  dbms_output.put_line('============================================================');
  dbms_output.put_line('Heal Alignment corruption....heal_iterated_folder_memberlink_4.sql');
  dbms_output.put_line(to_char(sysdate,'MM/DD/YYYY HH24:MI:SS'));
  dbms_output.put_line('============================================================');

  dbms_output.put_line('update iteratedfoldermemberlink to be set to parentfolder value from latest where it is mismatched');

  dbms_output.put_line(to_char(sysdate,'MM/DD/YYYY HH24:MI:SS'));

  v_sqlstmt := 'select distinct  l.idA2A2 fl_ida2a2,l.BRANCHIDA3B5 fl_branchida3b5, d.idA3B2folderingInfo doc_idA3B2folderingInfo,
                l.idA3A5 fl_ida3a5, sysdate createstamp
              ,decode(pivs.status,null,''Object not Migrated'',
                    decode(pivs.status,1,
                        decode(d.STATECHECKOUTINFO,''c/i'',''Healable'',''Object not checked in''),''Object was not migrated successfully'')) isHealable
              , :max_run_cnt  runcount
       from     EPMDocument d, IterFolderMemberLink l, pivtowcstatus pivs
       where     d.branchIditerationInfo = l.branchIdA3B5
           and d.ida2a2=pivs.epmdocumentid(+)
           and d.idA3B2folderingInfo <> l.idA3A5 and d.latestiterationInfo = 1 and d.idA3B2folderingInfo <> 0
        and d.classnamekeycontainerreferen in (''wt.inf.library.WTLibrary'',''wt.pdmlink.PDMLinkProduct'')';


  select nvl(max(runcount),0) into  v_max_run_cnt from MIG$FOLMLDOC;
  v_max_run_cnt := v_max_run_cnt+1;
  v_error :='No Errors';

  if (v_lasthealedtimestamp is not null) then
    v_sqlstmt := v_sqlstmt||' and loadtime>'''||v_lasthealedtimestamp||'''';
  end if;

  dbms_output.put_line(to_char(sysdate,'MM/DD/YYYY HH24:MI:SS'));

  OPEN c_hifml4 for v_sqlstmt using v_max_run_cnt;
  LOOP
    FETCH c_hifml4 BULK COLLECT INTO s_array_fts LIMIT 10000;
    FORALL i IN 1..s_array_fts.COUNT
     insert into MIG$folmlDoc values s_array_fts(i);
    EXIT WHEN c_hifml4%NOTFOUND;
  END LOOP;
  CLOSE c_hifml4;

  dbms_output.put_line(to_char(sysdate,'MM/DD/YYYY HH24:MI:SS'));

  --
  update IterFolderMemberLink l
  set idA3A5 = (select d.DOC_IDA3B2FOLDERINGINFO  from mig$folmlDoc d where l.idA2A2 = d.fl_idA2A2 and runcount=v_max_run_cnt and healable = 'Healable')
  where idA2A2 in (  select fl_idA2A2  from mig$folmlDoc where runcount=v_max_run_cnt and healable = 'Healable');
  --
  v_rows_updated:=sql%rowcount;
  dbms_output.put_line('IterFolderMemberLink Rows Updated='||v_rows_updated);

  commit;

  dbms_output.put_line(to_char(sysdate,'MM/DD/YYYY HH24:MI:SS'));

  exception when others then
       	Rollback;
       	v_error := DBMS_UTILITY.format_error_stack;
       	dbms_output.put_line('FILENAME$NonHealable_iterated_folder_memberlink_4.html$');

end;
/

