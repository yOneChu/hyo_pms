create TYPE FTCellInfo AS OBJECT (
   cell_id   NUMBER,
   className   VARCHAR2(600),
   column_id   NUMBER,
   link_id   NUMBER)
/

