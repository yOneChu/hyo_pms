create Package Body WTReversePK IS
FUNCTION ReverseChars(p_value IN VARCHAR2) RETURN VARCHAR2 IS
v_length 			NUMBER := 0;
v_reverse_value              	VARCHAR2(4000) := NULL;
BEGIN
IF p_value IS NOT NULL THEN
v_length := LENGTH(p_value);
v_reverse_value := SUBSTR(p_value, v_length, 1);
LOOP
v_length := v_length - 1;
IF v_length = 0 THEN
EXIT;
END IF;
v_reverse_value := v_reverse_value || SUBSTR(p_value, v_length, 1);
END LOOP;
END IF;
RETURN (v_reverse_value);
END ReverseChars;
END WTReversePK;
/

