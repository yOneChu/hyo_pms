create TYPE FTStatus AS OBJECT (
   className   VARCHAR2(600),
   err_cd   NUMBER,
   oid   NUMBER)
/

