create PACKAGE BODY EPMSupportingDataPK IS
-- a privtae function. Not declared in package specification
PROCEDURE nullifyRetunList(return_list IN OUT OID_OBJECT_LIST)
IS
BEGIN
IF return_list.COUNT = 0 THEN
return_list.EXTEND;
return_list(1)  := OID_OBJECT('wt.epm.supportingdata.EPMSupportingData', -999);
ELSE
FOR i IN 1..return_list.COUNT LOOP
return_list(i) := OID_OBJECT('wt.epm.supportingdata.EPMSupportingData', -999);
END LOOP;
END IF;
END nullifyRetunList;
FUNCTION CopyEpmSupportingData(source_epm_supporting_data IN TABLE_OF_NUMBER , holder_object IN OID_OBJECT) RETURN OID_OBJECT_LIST IS
v_current_time DATE;
v_authoringApplication EPMSUPPORTINGDATA.authoringApplication%TYPE;
v_description EPMSUPPORTINGDATA.description%TYPE;
v_name EPMSUPPORTINGDATA.name%TYPE;
v_ownerApplication EPMSUPPORTINGDATA.ownerApplication%TYPE;
v_className EPMSUPPORTINGDATA.classNameA2A2%TYPE;
v_markForDelete EPMSUPPORTINGDATA.markForDeleteA2%TYPE;
v_id_count NUMBER :=0;
v_oid  NUMBER :=0;
num_recs NUMBER := 0;
v_InsertRetTable OID_OBJECT_LIST  := OID_OBJECT_LIST ();
v_table_counter  BINARY_INTEGER := 1;
v_blob_loc BLOB;
insert_error EXCEPTION;
BEGIN
BEGIN
SELECT sysdate INTO v_current_time FROM DUAL;
num_recs := source_epm_supporting_data.LAST;
FOR i IN 1..num_recs LOOP
IF v_id_count = 0 THEN
v_id_count := 100;
SELECT id_sequence.NEXTVAL INTO v_oid FROM DUAL;
END IF;
SELECT authoringApplication,
data,
description,
name,
classNameA2A2,
ownerApplication,
markForDeleteA2
INTO
v_authoringApplication,
v_blob_loc,
v_description,
v_name,
v_className,
v_ownerApplication,
v_markForDelete
FROM
epmsupportingdata
WHERE idA2A2 =  source_epm_supporting_data(i);
INSERT INTO epmsupportingdata
(AUTHORINGAPPLICATION,
DATA,
DESCRIPTION,
CLASSNAMEKEYA3,
IDA3A3,
NAME,
OWNERAPPLICATION,
CREATESTAMPA2,
MODIFYSTAMPA2,
CLASSNAMEA2A2,
IDA2A2,
UPDATECOUNTA2,
UPDATESTAMPA2,
MARKFORDELETEA2)
VALUES(v_authoringApplication,
EMPTY_BLOB(),
v_description,
holder_object.className,
holder_object.id,
v_name,
v_ownerApplication,
v_current_time,
v_current_time,
v_className,
v_oid,
1,
v_current_time,
v_markForDelete );
IF SQL%ROWCOUNT = 0 THEN
RAISE insert_error;
END IF;
UPDATE epmsupportingdata
SET data = v_blob_loc
WHERE idA2A2 = v_oid;
v_InsertRetTable.EXTEND;
v_InsertRetTable(v_table_counter)  := OID_OBJECT(v_className, v_oid);
v_table_counter   := v_table_counter + 1;
v_id_count := v_id_count - 1;
v_oid := v_oid + 1;
END LOOP;
EXCEPTION  -- exception handlers begin
WHEN insert_error THEN  -- handles failed insert
DBMS_OUTPUT.PUT_LINE('INSERT ERROR OCCURED');
nullifyRetunList(v_InsertRetTable);
RETURN(v_InsertRetTable);
WHEN OTHERS THEN  -- handles all other errors
DBMS_OUTPUT.PUT_LINE('OTHER ERROR OCCURED');
nullifyRetunList(v_InsertRetTable);
RETURN(v_InsertRetTable);
END;
RETURN (v_InsertRetTable);
END CopyEpmSupportingData;
FUNCTION saveEPMSupportingData(epm_supporting_data IN TABLE_OF_EPM_SUPPORTING_INFO, NumblobsToUse IN TABLE_OF_NUMBER, blobDataList IN RAW_OBJECT_LIST)
RETURN OID_OBJECT_LIST IS
v_current_time DATE;
v_InsertRetTable OID_OBJECT_LIST  := OID_OBJECT_LIST ();
v_table_counter  BINARY_INTEGER := 1;
v_id_count NUMBER :=0;
v_oid  NUMBER :=0;
num_recs NUMBER := 0;
blob_locator BLOB;
rawData RAW(32767);
raw_object_data RAW_OBJECT;
blobsToUse NUMBER := 1;
bolbUseIndex NUMBER := 1;
offset INTEGER := 1;
amount NUMBER := 0;
newUpdateCount NUMBER := 0;
idToUse NUMBER := 0; -- 0 means we have to create a new record. Otherwise modify
insert_error EXCEPTION;
update_error EXCEPTION;
v_error_code NUMBER;
v_error_msg VARCHAR2(1000);
BEGIN
BEGIN
SELECT sysdate INTO v_current_time FROM DUAL;
num_recs := epm_supporting_data.LAST;
FOR i IN 1..num_recs LOOP
idToUse := epm_supporting_data(i).toModifyId;
IF idToUse = 0 THEN
IF v_id_count = 0 THEN
v_id_count := 100;
select id_sequence.NEXTVAL into v_oid from dual;
END IF;
idToUse := v_oid;
-- new Data. Do a insert
INSERT INTO epmsupportingdata
(AUTHORINGAPPLICATION,
DATA,
DESCRIPTION,
CLASSNAMEKEYA3,
IDA3A3,
NAME,
OWNERAPPLICATION,
CREATESTAMPA2,
MODIFYSTAMPA2,
CLASSNAMEA2A2,
IDA2A2,
UPDATECOUNTA2,
UPDATESTAMPA2,
MARKFORDELETEA2)
VALUES(epm_supporting_data(i).autoringApplication,
EMPTY_BLOB(),
epm_supporting_data(i).description,
epm_supporting_data(i).holderclassName,
epm_supporting_data(i).holderClassId,
epm_supporting_data(i).name,
epm_supporting_data(i).ownerApplication,
v_current_time,
v_current_time,
'wt.epm.supportingdata.EPMSupportingData',
idToUse,
1,
v_current_time,
epm_supporting_data(i).markForDelete );
IF SQL%ROWCOUNT = 0 THEN
RAISE insert_error;
END IF;
v_id_count := v_id_count - 1;
v_oid := v_oid + 1;
ELSE
-- Update the existing data.
SELECT UPDATECOUNTA2 INTO newUpdateCount
FROM epmsupportingdata
WHERE idA2A2 = idToUse;
newUpdateCount := newUpdateCount + 1;
UPDATE epmsupportingdata
SET AUTHORINGAPPLICATION = epm_supporting_data(i).autoringApplication,
DESCRIPTION = epm_supporting_data(i).description,
CLASSNAMEKEYA3 = epm_supporting_data(i).holderclassName,
IDA3A3 = epm_supporting_data(i).holderClassId,
NAME = epm_supporting_data(i).name,
OWNERAPPLICATION = epm_supporting_data(i).ownerApplication,
MODIFYSTAMPA2 = v_current_time,
MARKFORDELETEA2 = epm_supporting_data(i).markForDelete,
UPDATECOUNTA2 = newUpdateCount,
UPDATESTAMPA2 = v_current_time
WHERE idA2A2 = idToUse;
IF SQL%ROWCOUNT = 0 THEN
RAISE update_error;
END IF;
END IF;
-- Get the Blob locator
SELECT DATA INTO blob_locator FROM epmsupportingdata WHERE idA2A2 = idToUse FOR UPDATE;
blobsToUse := NumblobsToUse(i);
FOR j IN 1..blobsToUse LOOP
raw_object_data := blobDataList(bolbUseIndex);
amount := raw_object_data.blobLength;
rawData := raw_object_data.blobData;
IF j = 1 THEN
DBMS_LOB.WRITE(blob_locator, amount, 1, rawData);
ELSE
DBMS_LOB.WRITEAPPEND(blob_locator, amount,rawData);
END IF;
bolbUseIndex := bolbUseIndex + 1;
END LOOP;
v_InsertRetTable.EXTEND;
v_InsertRetTable(v_table_counter)  := OID_OBJECT('wt.epm.supportingdata.EPMSupportingData', idToUse);
v_table_counter   := v_table_counter + 1;
END LOOP;
EXCEPTION  -- exception handlers begin
WHEN insert_error THEN  -- handles failed insert
DBMS_OUTPUT.PUT_LINE('INSERT ERROR OCCURED');
nullifyRetunList(v_InsertRetTable);
RAISE_APPLICATION_ERROR(-20505, 'INSERT FAILED');
RETURN(v_InsertRetTable);
WHEN update_error THEN
DBMS_OUTPUT.PUT_LINE('UPDATE ERROR OCCURED');
nullifyRetunList(v_InsertRetTable);
RAISE_APPLICATION_ERROR(-20505, 'UPDATE FAILED');
RETURN(v_InsertRetTable);
WHEN NO_DATA_FOUND THEN
nullifyRetunList(v_InsertRetTable);
RAISE_APPLICATION_ERROR(-20506, 'SELECT STATEMENT FOR BLOB FAILED');
RETURN(v_InsertRetTable);
WHEN OTHERS THEN
v_error_code := SQLCODE;
v_error_msg := SQLERRM;
-- Put the errors in a table
-- INSERT INTO ET
-- VALUES(v_error_code, v_error_msg);
nullifyRetunList(v_InsertRetTable);
RAISE_APPLICATION_ERROR(-20506,'OTHER ERROR OCCURED');
RETURN(v_InsertRetTable);
END;
RETURN (v_InsertRetTable);
END saveEPMSupportingData;
FUNCTION removeEPMSupportingData(epm_supporting_data IN TABLE_OF_NUMBER) RETURN NUMBER
IS
retResult NUMBER := 1;	-- 0 false, 1 true;
BEGIN
FOR i IN 1..epm_supporting_data.COUNT LOOP
DELETE FROM epmsupportingdata
WHERE idA2A2 = epm_supporting_data(i);
END LOOP;
EXCEPTION
WHEN OTHERS THEN
retResult := 0;
return retResult;
END removeEPMSupportingData;
FUNCTION CopySupportingData(sourceSupportingdata IN TABLE_OF_NUMBER , holderObjects IN OID_OBJECT_LIST, changeDataHolderToUse IN TABLE_OF_NUMBER)
RETURN OID_OBJECT_LIST IS
v_current_time DATE;
v_authoringApplication EPMSUPPORTINGDATA.authoringApplication%TYPE;
v_description EPMSUPPORTINGDATA.description%TYPE;
v_name EPMSUPPORTINGDATA.name%TYPE;
v_ownerApplication EPMSUPPORTINGDATA.ownerApplication%TYPE;
v_className EPMSUPPORTINGDATA.classNameA2A2%TYPE;
v_markForDelete EPMSUPPORTINGDATA.markForDeleteA2%TYPE;
v_id_count NUMBER :=0;
v_oid  NUMBER :=0;
num_recs NUMBER := 0;
holder_index NUMBER := 1;
holder_object OID_OBJECT ;
changeHolder NUMBER := 0;
holder_count NUMBER := 0;
v_InsertRetTable OID_OBJECT_LIST  := OID_OBJECT_LIST ();
v_table_counter  BINARY_INTEGER := 1;
v_blob_loc BLOB;
insert_error EXCEPTION;
BEGIN
BEGIN
SELECT sysdate INTO v_current_time FROM DUAL;
num_recs := sourceSupportingdata.LAST;
holder_count := holderObjects.LAST;
FOR i IN 1..num_recs LOOP
IF ( holder_index <= holder_count ) THEN
changeHolder := changeDataHolderToUse(holder_index);
IF i = changeHolder THEN
holder_object := holderObjects(holder_index);
holder_index := holder_index + 1;
END IF;
END IF;
IF v_id_count = 0 THEN
v_id_count := 100;
SELECT id_sequence.NEXTVAL INTO v_oid FROM DUAL;
END IF;
SELECT authoringApplication,
data,
description,
name,
classNameA2A2,
ownerApplication,
markForDeleteA2
INTO
v_authoringApplication,
v_blob_loc,
v_description,
v_name,
v_className,
v_ownerApplication,
v_markForDelete
FROM
epmsupportingdata
WHERE idA2A2 =  sourceSupportingdata(i);
INSERT INTO epmsupportingdata
(AUTHORINGAPPLICATION,
DATA,
DESCRIPTION,
CLASSNAMEKEYA3,
IDA3A3,
NAME,
OWNERAPPLICATION,
CREATESTAMPA2,
MODIFYSTAMPA2,
CLASSNAMEA2A2,
IDA2A2,
UPDATECOUNTA2,
UPDATESTAMPA2,
MARKFORDELETEA2)
VALUES(v_authoringApplication,
EMPTY_BLOB(),
v_description,
holder_object.className,
holder_object.id,
v_name,
v_ownerApplication,
v_current_time,
v_current_time,
v_className,
v_oid,
1,
v_current_time,
v_markForDelete );
IF SQL%ROWCOUNT = 0 THEN
RAISE insert_error;
END IF;
UPDATE epmsupportingdata
SET data = v_blob_loc
WHERE idA2A2 = v_oid;
v_InsertRetTable.EXTEND;
v_InsertRetTable(v_table_counter)  := OID_OBJECT(v_className, v_oid);
v_table_counter   := v_table_counter + 1;
v_id_count := v_id_count - 1;
v_oid := v_oid + 1;
END LOOP;
EXCEPTION  -- exception handlers begin
WHEN insert_error THEN  -- handles failed insert
DBMS_OUTPUT.PUT_LINE('INSERT ERROR OCCURED');
nullifyRetunList(v_InsertRetTable);
RETURN(v_InsertRetTable);
--	    WHEN OTHERS THEN  -- handles all other errors
--		DBMS_OUTPUT.PUT_LINE('OTHER ERROR OCCURED');
--		nullifyRetunList(v_InsertRetTable);
--		RETURN(v_InsertRetTable);
END;
RETURN (v_InsertRetTable);
END CopySupportingData;
END EPMSupportingDataPK;
/

