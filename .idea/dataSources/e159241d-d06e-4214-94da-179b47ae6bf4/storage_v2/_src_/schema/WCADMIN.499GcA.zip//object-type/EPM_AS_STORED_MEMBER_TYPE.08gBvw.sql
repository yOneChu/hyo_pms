create TYPE EPM_AS_STORED_MEMBER_TYPE AS OBJECT (
className             VARCHAR2(200),
id                    NUMBER,
owner         NUMBER)
/

