create PACKAGE BODY EPMStructurePK IS
-- Navigates the dependencies for a set of EPMDocuments. This function queries
-- for EPMMember, EPMReference and EPMVariant links on each document.
-- Input Parameters:
--     databaseIds -- database identifiers of the EPMDocuments
-- Returns:
--     For each link found, the function returns object identifiers of the
--     link, its role A object and its role B object. It also returns the
--     required flag and the dependency type.
FUNCTION getDependencies(databaseIds TABLE_OF_NUMBER)
RETURN LIST_OF_EPM_DEPENDENCIES IS
dependencies LIST_OF_EPM_DEPENDENCIES;
Card NUMBER(10,0);
CardHint VARCHAR2(100);
DepQuery VARCHAR2(4000);
BEGIN
SELECT count(*) INTO Card FROM TABLE(databaseIds);
IF (Card > 10) THEN
Card := round(EXP(0.3465736 * round(2.88539 * LN(Card))));
END IF;
CardHint := ' /*+ CARDINALITY(wtot ' || TO_CHAR(Card) || ') */ ';
DepQuery := '
SELECT EPM_DEPENDENCY(classnamekeyroleAObjectRef, idA3A5, classnamekeyroleBObjectRef, idA3B5, classnameA2A2, idA2A2, required, depType)
FROM EPMMemberLink
WHERE idA3A5 IN (SELECT ' || CardHint || ' * FROM TABLE(:1) wtot)
UNION ALL
SELECT EPM_DEPENDENCY(classnamekeyroleAObjectRef, idA3A5, classnamekeyroleBObjectRef, idA3B5, classnameA2A2, idA2A2, required, depType)
FROM EPMReferenceLink
WHERE idA3A5 IN (SELECT ' || CardHint || ' * FROM TABLE(:2) wtot)
UNION ALL
SELECT EPM_DEPENDENCY(classnamekeyroleAObjectRef, idA3A5, classnamekeyroleBObjectRef, idA3B5, classnameA2A2, idA2A2, required, NULL)
FROM EPMVariantLink
WHERE idA3A5 IN (SELECT ' || CardHint || ' * FROM TABLE(:3) wtot)';
EXECUTE IMMEDIATE DepQuery
BULK COLLECT INTO dependencies
USING databaseIds,databaseIds,databaseIds;
RETURN dependencies;
END getDependencies;
/* -------------------------------------------------------------------------- */
-- Navigates a link class (and its subclasses).
-- Input Parameters:
--     listsOfTables  -- lists of the database tables to execute the query over
--     queryTemplate  -- query to execute
--     databaseIds    -- database identifiers of the role objects to navigate from
-- Returns:
--     object identifier or version key of the role A and role B objects plus the
--     object identifier of the link
FUNCTION navigate(listsOfTables TABLE_OF_VARCHAR2_200, queryTemplate VARCHAR2, databaseIds TABLE_OF_NUMBER)
RETURN LIST_OF_LINKS IS
query VARCHAR2(32767);
TYPE LinkCursorType IS REF CURSOR;
linkCursor LinkCursorType;
link LINK_RECORD;
links LIST_OF_LINKS := LIST_OF_LINKS();
BEGIN
FOR i IN listsOfTables.FIRST..listsOfTables.LAST
LOOP
query := REPLACE(queryTemplate, '@tables', listsOfTables(i));
FOR j IN databaseIds.FIRST..databaseIds.LAST
LOOP
OPEN linkCursor FOR query USING databaseIds(j);
LOOP
FETCH linkCursor INTO link;
EXIT WHEN linkCursor%NOTFOUND;
links.EXTEND();
links(links.LAST) := LINK_OBJECT(link.roleAClassName, link.roleAId,
link.roleBClassName, link.roleBId,
link.className, link.id);
END LOOP;
CLOSE linkCursor;
END LOOP;
END LOOP;
RETURN links;
END navigate;
/* -------------------------------------------------------------------------- */
-- Navigates a link class (and its subclasses) to the other side object.
-- In addition to the link, it returns the object identifier of the master of
-- the other side object.
-- Input Parameters:
--     linkTableNames      -- names of the database tables for the link class and its subclasses
--     otherSideTableNames -- names of the database tables for the other side object classes
--     queryTemplate       -- query to execute
--     databaseIds         -- database identifiers of the role objects to navigate from
-- Returns:
--     object identifier or version key of the role A and role B objects, the object
--     identifier of the link and the object identifier of the master of the other
--     side object
FUNCTION navigateToMaster(linkTableNames TABLE_OF_VARCHAR2_30, otherSideTableNames TABLE_OF_VARCHAR2_30,
queryTemplate VARCHAR2, databaseIds TABLE_OF_NUMBER)
RETURN LIST_OF_LINK_N_MASTERS IS
query VARCHAR2(32767);
TYPE LinkCursorType IS REF CURSOR;
linkCursor LinkCursorType;
linkAndMaster LINK_N_MASTER_RECORD;
linkAndMasters LIST_OF_LINK_N_MASTERS := LIST_OF_LINK_N_MASTERS();
BEGIN
FOR i IN linkTableNames.FIRST..linkTableNames.LAST
LOOP
FOR j IN otherSideTableNames.FIRST..otherSideTableNames.LAST
LOOP
query := REPLACE(REPLACE(queryTemplate, '@linkTable', linkTableNames(i)),
'@otherSideTable', otherSideTableNames(j));
FOR j IN databaseIds.FIRST..databaseIds.LAST
LOOP
OPEN linkCursor FOR query USING databaseIds(j);
LOOP
FETCH linkCursor INTO linkAndMaster;
EXIT WHEN linkCursor%NOTFOUND;
linkAndMasters.EXTEND();
linkAndMasters(linkAndMasters.LAST) :=
LINK_N_MASTER(linkAndMaster.roleAClassName, linkAndMaster.roleAId,
linkAndMaster.roleBClassName, linkAndMaster.roleBId,
linkAndMaster.className, linkAndMaster.id,
linkAndMaster.masterClassName, linkAndMaster.masterId);
END LOOP;
CLOSE linkCursor;
END LOOP;
END LOOP;
END LOOP;
RETURN linkAndMasters;
END navigateToMaster;
/* -------------------------------------------------------------------------- */
END EPMStructurePK;
/

