create procedure heal_misalign_containers_ft (v_lasthealedtimestamp IN date, v_error OUT varchar2) is

   v_healable varchar2(100);
   v_max_run_cnt number;
   v_rows_updated number;
   v_sqlstmt varchar2(8000);
   type refcur is ref cursor;
   c_ALIGNMENT_EPMFTS refcur;

 TYPE fetch_array_master IS TABLE OF MIG$EPMFTCONTAINERS%ROWTYPE;
 s_array_fts fetch_array_master;

begin

  dbms_output.put_line('============================================================');
  dbms_output.put_line('Heal Alignment corruption....heal_misalign_containers_FT-7.sql');
  dbms_output.put_line(to_char(sysdate,'MM/DD/YYYY HH24:MI:SS'));
  dbms_output.put_line('============================================================');

  dbms_output.put_line('Align container of each family table with that of its top-level generic if the container does not match.');

  v_sqlstmt := 'select distinct  ft.ida2a2 FTID, ft.classnamea2a2, gen.classnamekeycontainerreferen GENCLASSREF, gen.ida3containerreference GENCREF
   		, ft.classnamekeycontainerreferen FTCLASSREF, ft.ida3containerreference FTCREF, sysdate
   		, decode(lovst.status,null,''Object not Migrated'',decode(lovst.status,1,decode(ft.STATECHECKOUTINFO,''c/i'',''Healable'',''Object not checked in''),''Object was not migrated successfully'')) isHealable
              	, :max_run_cnt  runcount
		from epmsepfamilytable ft , epmcontainedin ci, epmdocument gen, lovtowcstatus lovst
		where
		      ft.ida2a2 = ci.ida3b5
		      and ci.ida3a5 = gen.ida2a2
		      and gen.familyTableStatus = 2
		      and gen.ida3containerreference <> ft.ida3containerreference
		      and lovst.epmsepfamilytableid(+) = ft.ida2a2
		      and ft.classnamekeycontainerreferen in (''wt.inf.library.WTLibrary'',''wt.pdmlink.PDMLinkProduct'')';

  select nvl(max(runcount),0) into  v_max_run_cnt from MIG$EPMFTCONTAINERS;
  v_max_run_cnt := v_max_run_cnt+1;
  v_error :='No Errors';

  if (v_lasthealedtimestamp is not null) then
    v_sqlstmt := v_sqlstmt||' and loadtime>'''||v_lasthealedtimestamp||'''';
  end if;

  dbms_output.put_line(to_char(sysdate,'MM/DD/YYYY HH24:MI:SS'));

  OPEN c_ALIGNMENT_EPMFTS for v_sqlstmt using v_max_run_cnt;
  LOOP
    FETCH c_ALIGNMENT_EPMFTS BULK COLLECT INTO s_array_fts LIMIT 10000;
    FORALL i IN 1..s_array_fts.COUNT
     insert into MIG$EPMFTCONTAINERS values s_array_fts(i);
    EXIT WHEN c_ALIGNMENT_EPMFTS%NOTFOUND;
  END LOOP;
  CLOSE c_ALIGNMENT_EPMFTS;

  dbms_output.put_line(to_char(sysdate,'MM/DD/YYYY HH24:MI:SS'));

  update epmsepfamilytable toUpdate set ( classnamekeycontainerreferen, ida3containerreference ) = ( select classnamekeycontainerreferen, ida3containerreference
                from MIG$EPMFTCONTAINERS where MIG$EPMFTCONTAINERS.ida2a2 = toUpdate.ida2a2 and runcount=v_max_run_cnt and healable = 'Healable' and MIG$EPMFTCONTAINERS.classnamea2a2 = 'wt.epm.familytable.EPMSepFamilyTable')
  where toUpdate.ida2a2 in ( select MIG$EPMFTCONTAINERS.ida2a2 from MIG$EPMFTCONTAINERS where runcount=v_max_run_cnt and healable = 'Healable' and MIG$EPMFTCONTAINERS.classnamea2a2 = 'wt.epm.familytable.EPMSepFamilyTable');
  v_rows_updated:=sql%rowcount;
  dbms_output.put_line('epmsepfamilytable Rows Updated='||v_rows_updated);
  dbms_output.put_line(to_char(sysdate,'MM/DD/YYYY HH24:MI:SS'));

  commit;

  dbms_output.put_line(to_char(sysdate,'MM/DD/YYYY HH24:MI:SS'));

  exception when others then
     	Rollback;
     	v_error := DBMS_UTILITY.format_error_stack;
	dbms_output.put_line('FILENAME$NonHealable_misalign_containers_ft-7.html$');

end;
/

