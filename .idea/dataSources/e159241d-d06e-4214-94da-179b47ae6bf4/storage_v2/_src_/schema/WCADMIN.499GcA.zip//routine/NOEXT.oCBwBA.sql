create function NOEXT(name varchar2) return varchar2 is
begin
    return SUBSTR(name,1,INSTR(name,'.',-1,1)-1);
end;
/

