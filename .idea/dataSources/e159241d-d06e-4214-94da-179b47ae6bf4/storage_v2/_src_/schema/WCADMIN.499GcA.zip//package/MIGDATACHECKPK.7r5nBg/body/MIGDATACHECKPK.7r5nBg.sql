create PACKAGE BODY migdatacheckpk
IS
   TYPE ttab_rid  IS TABLE OF ROWID         INDEX BY BINARY_INTEGER;
   TYPE ttab_name IS TABLE OF VARCHAR2(50)  INDEX BY BINARY_INTEGER;
   TYPE ttab_int  IS TABLE OF INTEGER       INDEX BY BINARY_INTEGER;
   TYPE ttab_num  IS TABLE OF NUMBER        INDEX BY BINARY_INTEGER;
   TYPE ttab_vint IS TABLE OF INTEGER       INDEX BY VARCHAR2(10);
   TYPE t_ref_cursor IS REF CURSOR;
   --
   TYPE trec_cols    IS RECORD (
            tab_name    VARCHAR2(50),
            col_name    VARCHAR2(50));
   TYPE ttab_cols    IS TABLE OF trec_cols INDEX BY BINARY_INTEGER;
   --
   v_functionname varchar2(50);
   type t_chr_arr is table of char index by binary_integer;
   type tofv_200 is table of varchar2(200);
   v_log tofv_200;
   --
   arr_chrs    t_chr_arr;
   str_chrs    varchar2(32); -- chr(1) .. chr(31) + '~'
   str_new_chrs    varchar2(64); -- chr(57345) .. chr(57375) + '~'
--------------------------------------------------
FUNCTION checkData RETURN number
IS
   excl_chars tofv := tofv(chr(9), chr(10), chr(13));
   tempNum number;
BEGIN
   restartMethodServer:=0;
   truncateMigVerifyDatalog;
   replacenonUnicode;
   --- processHasControls(excl_chars);
   fixNullAttrvalFamTabs;
   detectAndHealPTCCommonName(tempNum);
   FIXNEWLINEINATTRVALFAMTABS;
   healMemberLinkIdentifier;
   healUniqueLinkId;
   RETURN restartMethodServer;
END checkData;
--
--    Convert seconds to printable format h:m:s
FUNCTION f_msec2time
   (a_msec  PLS_INTEGER)  -- Mseconts(0.01sec)
    RETURN  VARCHAR2
IS
BEGIN
   RETURN LTRIM(RTRIM(LTRIM(NUMTODSINTERVAL(a_msec/100,'SECOND'),'+0 '),'0'),':')||'0';
END f_msec2time;
--
PROCEDURE push (the_list IN OUT tofv_200, new_value IN VARCHAR2)
AS
BEGIN
   the_list.EXTEND;
   the_list(the_list.LAST) := new_value;
END;
PROCEDURE insertLogs (vfunc varchar2)
IS
   temp varchar2(500);
BEGIN
 FOR i IN v_log.first..v_log.last  loop
   temp:=v_log(i);
    begin
      execute immediate 'INSERT INTO  mig_verify_datalog VALUES ( '||i||','''||vfunc||''', '''||temp||''')';
   exception when others then
    temp:='insert into table mig_verify_datalog error: '||sqlerrm(sqlcode);
    dbms_output.put_line('insert into table mig_verify_datalog error: '||sqlerrm(sqlcode) );
    --raise;
   end;
 end loop;
 commit;
EXCEPTION when others THEN
   NULL;
END;
--
PROCEDURE detectAndHealPTCCommonName ( var_rows OUT NUMBER )
  AS
  	CURSOR curSelectQuery IS select distinct  dd.IDA2A2  ,mm.NAME
	      	from
	      		epmSepFamilyTable       ft
	      	      , epmSepFamilyTableMaster fm
	      	      , epmParameterDefinition  pd
	      	      , epmDocument             dd
	      	      , epmContainedIn          cc
	      	      , epmDocumentMaster       mm
	      	where 1=1
	      	    and   fm.IDA2A2 = pd.IDA3A3
	      	    and   pd.NAME   = 'PTC_COMMON_NAME'
	      	    and   fm.IDA2A2 = ft.IDA3MASTERREFERENCE
	      	    and   ft.IDA2A2 = cc.IDA3B5
	      	    and   dd.ida2a2=cc.ida3a5
	      	    and   dd.IDA3MASTERREFERENCE = mm.ida2a2
	      	    and   EXISTS (select 1
	      			  from LOTOWCstatus
	      			  where epmsepfamilytablemasterid=fm.ida2a2 and status=1)
	      	    and   EXISTS (select 1
	      			    from LOVTOWCstatus
	      			    where ft.IDA2A2 = epmsepfamilytableid and status=1)
	      	    and  dd.ida2a2  NOT IN (select pv.ida3a4  from epmParameterValue pv
	      						    where  pv.ida3a4 = dd.ida2a2
	      						      and  pv.NAME   = 'PTC_COMMON_NAME'
  						      and  dd.ida2a2 is not null);
  	v_docs TABLE_OF_NUMBER;
	v_names tofv_200;
   l_tm     PLS_INTEGER:=dbms_utility.get_time;
BEGIN
  var_rows := 0;
  v_log:=tofv_200();
  v_functionname:='detectAndHealPTCCommonName';

    begin
    	execute immediate 'CREATE INDEX idxtmp_LovTOWCstatus ON LOVTOWCSTATUS (epmsepfamilytableid) TABLESPACE "INDX"';
    	push(v_log,'INDEX idxtmp_LovTOWCstatus created');
    exception when others then
    	null;
    end;

    begin
    	execute immediate 'CREATE INDEX idxtmp_LoTOWCstatus ON LOTOWCSTATUS (epmsepfamilytablemasterid) TABLESPACE "INDX"';
        push(v_log,'INDEX idxtmp_LoTOWCstatus created');
    exception when others then
    	null;
    end;

	OPEN curSelectQuery;
	LOOP
		FETCH curSelectQuery BULK COLLECT INTO v_docs, v_names LIMIT 5000;

		push(v_log,'Number of rows being processed for missing PTC_COMMON_NAME in EPMParameterValue : ' || v_docs.count);

		FOR i IN 1..v_docs.COUNT LOOP

			insert into epmparametervalue(
			 CLASSNAMEKEYA4
			 ,IDA3A4
			 ,NAME
			 ,NUMBERVALUE
			 ,STRINGVALUE
			 ,CREATESTAMPA2
			 ,MARKFORDELETEA2
			 ,MODIFYSTAMPA2
			 ,CLASSNAMEA2A2
			 ,IDA2A2
			 ,UPDATECOUNTA2
			 ,UPDATESTAMPA2
			 ,VALUETYPE)
			values(
			'wt.epm.EPMDocument' --CLASSNAMEKEYA4
			 ,v_docs(i)          --IDA3A4
			 ,'PTC_COMMON_NAME'  --NAME
			 ,null               --NUMBERVALUE
			 ,v_names(i)           --STRINGVALUE
			 ,sysdate            --CREATESTAMPA2
			 ,0                  --MARKFORDELETEA2
			 ,sysdate            --MODIFYSTAMPA2
			 ,'wt.epm.familytable.EPMParameterValue'--CLASSNAMEA2A2
			 ,MigrationPK.GetNewWCID --IDA2A2
			-- ,id_sequence.NEXTVAL
			 ,1                   --UPDATECOUNTA2
			 ,sysdate             --UPDATESTAMPA2
			 ,4                   --VALUETYPE
			);

			var_rows := var_rows +1;

			push(v_log, 'Inserting missing PTC_COMMON_NAME into epmparametervalue for DocumentId : '||  v_docs(i)  ||', Value : ' || v_names(i) );
		END LOOP;
	EXIT WHEN curSelectQuery%NOTFOUND;
	END LOOP;
   if restartMethodServer=0 and var_rows >0 then
      restartMethodServer:=1;
   end if;

   push(v_log, var_rows || ' missing records for PTC_COMMON_NAME have been inserted into epmparametervalue for migrated family tables');

   if restartMethodServer=1 then
	     push(v_log,' ');
	     push(v_log,'======================================================================');
	     push(v_log,'Please restart the Method Server after this script is run successfully');
	     push(v_log,'======================================================================');
	     push(v_log,' ');
   end if;

  	execute immediate 'drop INDEX idxtmp_LoTOWCstatus';
  	push(v_log,'INDEX idxtmp_LoTOWCstatus dropped');

  	execute immediate 'drop INDEX idxtmp_LovTOWCstatus';
  	push(v_log,'INDEX idxtmp_LovTOWCstatus dropped');
   push(v_log,'Elapsed: '||f_msec2time(dbms_utility.get_time-l_tm));

   insertLogs(v_functionname);

End detectAndHealPTCCommonName;

PROCEDURE truncateMigVerifyDatalog IS
   l_ii     PLS_INTEGER;
   l_sql    VARCHAR2(3000);
BEGIN
   --check if table mig_verify_datalog exists
   SELECT COUNT(1) INTO l_ii FROM user_tables WHERE table_name='MIG_VERIFY_DATALOG';
   --
   IF l_ii=0 THEN
      l_sql:='CREATE TABLE mig_verify_datalog (count number, functionname VARCHAR2(100), logs varchar2(250))';
      DBMS_UTILITY.EXEC_DDL_STATEMENT(l_sql);
   ELSE
      l_sql:='TRUNCATE TABLE mig_verify_datalog';
      EXECUTE IMMEDIATE l_sql;
   END IF;
EXCEPTION
   WHEN OTHERS THEN
      dbms_output.put_line(l_sql);
      RAISE;
END;
--
function findNullAttrvalFamTabs  return number is
     -- find all documents and attributes for attribute cells
        CURSOR ftcolumns IS SELECT a.ida2a2, e.ida2a2, e.name
        from epmdocument a, epmcontainedin b,
		      epmfamilytablecell d, epmfamilytableattribute e
        where a.ida2a2 = b.ida3a5 and
			b.ida2a2 = d.ida3a3 and
			d.ida3b3 = e.ida2a2;
        v_docs TABLE_OF_NUMBER;
        v_columns TABLE_OF_NUMBER;
        v_sqltext VARCHAR2(500);
        v_col_names tofv_200;
	v_map_hid  VARCHAR2(450);
	v_attr_hid  VARCHAR2(450);
	v_attr_name VARCHAR2(200);
	v_exists NUMBER;
	v_str_count NUMBER := 0;
	v_int_count NUMBER := 0;
	v_float_count NUMBER := 0;
	v_timestamp_count NUMBER := 0;
	v_boolean_count NUMBER := 0;
	v_tot_str_count NUMBER := 0;
	v_tot_int_count NUMBER := 0;
	v_tot_float_count NUMBER := 0;
	v_tot_timestamp_count NUMBER := 0;
	v_tot_boolean_count NUMBER := 0;
	v_no_definition_count NUMBER := 0;
	v_type NUMBER := 0;
BEGIN
  v_functionname:='findNullAttrvalFamTabs';
  v_log:=tofv_200();
OPEN ftcolumns;
LOOP
	FETCH ftcolumns BULK COLLECT INTO v_docs, v_columns,v_col_names LIMIT 5000;
	push(v_log,'Processing rows : ' || v_docs.count);
	FOR i IN 1..v_docs.COUNT
	LOOP
		v_attr_hid := NULL;
		BEGIN
		SELECT a.HIERARCHYIDB4
		into v_map_hid from epmparametermap a
		WHERE a.ida3a4 = v_docs(i) and
			a.parametername = v_col_names(i);
		EXCEPTION
			WHEN NO_DATA_FOUND THEN
			v_map_hid := NULL;
		END;
		--
		IF v_map_hid IS NULL THEN
			BEGIN
				select hid, name, attrtype into v_attr_hid, v_attr_name, v_type from
         (select HIERARCHYID hid, NAME name, 1 attrtype from integerdefinition b where b.name = v_col_names(i) UNION
					select HIERARCHYID, NAME, 2 from stringdefinition b where b.name = v_col_names(i) UNION
					select HIERARCHYID, NAME, 3 from booleandefinition b where b.name = v_col_names(i) UNION
					select HIERARCHYID, NAME, 4 from floatdefinition b where b.name = v_col_names(i) UNION
					select HIERARCHYID, NAME, 5 from timestampdefinition b where b.name = v_col_names(i));
			EXCEPTION
				WHEN NO_DATA_FOUND THEN
					push(v_log,'No attribute definition found for EPMDocument:'||v_docs(i)||'|| EPMFTAttribute:'||v_columns(i)||'|| COL_NAME:'||v_col_names(i));
					v_no_definition_count := v_no_definition_count + 1;
			END;
		ELSE
			select hid, name, attrtype into v_attr_hid, v_attr_name, v_type from
       (select HIERARCHYID hid, NAME name, 1 attrtype from integerdefinition b where b.HIERARCHYID = v_map_hid  UNION
				select HIERARCHYID, NAME, 2 from stringdefinition b where b.HIERARCHYID = v_map_hid UNION
				select HIERARCHYID, NAME, 3 from booleandefinition b where b.HIERARCHYID = v_map_hid UNION
				select HIERARCHYID, NAME, 4 from floatdefinition b where b.HIERARCHYID = v_map_hid UNION
				select HIERARCHYID, NAME, 5 from timestampdefinition b where b.HIERARCHYID = v_map_hid );
		END IF;
		IF v_attr_hid IS NOT NULL THEN
			SELECT count(*) into v_exists from ( select ida2a2 from stringvalue where HIERARCHYIDA6 = v_attr_hid and IDA3A4 = v_docs(i) UNION
				select ida2a2 from integervalue where HIERARCHYIDA6 = v_attr_hid  and IDA3A4 = v_docs(i) UNION
				select ida2a2 from booleanvalue where HIERARCHYIDA6 = v_attr_hid  and IDA3A4 = v_docs(i) UNION
				select ida2a2 from floatvalue where HIERARCHYIDA6 = v_attr_hid  and IDA3A4 = v_docs(i) UNION
				select ida2a2 from timestampvalue where HIERARCHYIDA6 = v_attr_hid  and IDA3A4 = v_docs(i) );
			if v_type = 1 then
				v_tot_int_count := v_tot_int_count + 1;
			elsif v_type = 2 then
				v_tot_str_count := v_tot_str_count + 1;
			elsif v_type = 3 then
				v_tot_boolean_count := v_tot_boolean_count + 1;
			elsif v_type = 4 then
				v_tot_float_count := v_tot_float_count + 1;
			elsif v_type = 5 then
				v_tot_timestamp_count := v_tot_timestamp_count + 1;
			end if;
			if v_exists = 0 THEN
				if v_type = 1 then
					v_int_count := v_int_count + 1;
				elsif v_type = 2 then
					v_str_count := v_str_count + 1;
				elsif v_type = 3 then
					v_boolean_count := v_boolean_count + 1;
				elsif v_type = 4 then
					v_float_count := v_float_count + 1;
				elsif v_type = 5 then
					v_timestamp_count := v_timestamp_count + 1;
				end if;
				--
			end if;
		END IF;
	END LOOP;
	EXIT WHEN ftcolumns%NOTFOUND;
END LOOP;
CLOSE ftcolumns;
    push(v_log,'No. of cells with no definition = ' || v_no_definition_count);
    push(v_log,'No. of string cells with no value = ' || v_str_count);
    push(v_log,'No. of integer cells with no value = ' || v_int_count);
    push(v_log,'No. of boolean cells with no value = ' || v_boolean_count);
    push(v_log,'No. of float cells with no value = ' || v_float_count);
    push(v_log,'No. of timestamp cells with no value = ' || v_timestamp_count);
    insertLogs(v_functionname);
    if v_no_definition_count>0 then
     return 1;
    else
     return 0;
    end if;
end  findNullAttrvalFamTabs;

 procedure findNullAttrvalInfo is
 cursor nullattrinfo is
 select 'FamilyTableID: '||ci.ida3b5
 ||'---FTStatus: '||decode (doc.familytablestatus, 2, 'Gen', 'Inst')
 ||'---EPMDocId: '||ci.ida3a5
 ||'---CADName: '||docm.cadname
 ||'---Version: '||doc.VERSIONIDA2VERSIONINFO
 ||'---Iteration: '||doc.ITERATIONIDA2ITERATIONINFO
 ||'---Attributate: '||ftattr.name
 ||'---Inherited: '||decode(cell.inherited, 1, 'X', 0, '', '') line
        from epmcontainedin ci,
             epmdocument doc, epmdocumentmaster docm,
             epmfamilytablecell cell,
             epmfamilytableattribute ftattr,
             stringdefinition strdefn
       where ci.ida2a2 = cell.ida3a3 and
             ci.ida3a5 = doc.ida2a2 and
             docm.ida2a2 = doc.IDA3MASTERREFERENCE and
             cell.CLASSNAMEKEYB3 = 'wt.epm.familytable.EPMFamilyTableAttribute' and
             cell.ida3b3 = ftattr.ida2a2 and
             strdefn.name = ftattr.name and
             not exists
               (select 1 from stringvalue attrval
                 where attrval.ida3a4 = ci.ida3a5 and
                       attrval.CLASSNAMEKEYA4 = 'wt.epm.EPMDocument' and
                       attrval.ida3a6 = strdefn.ida2a2
               )
order by ci.ida3b5, ftattr.name, doc.familytablestatus desc;
 begin
 v_log:=tofv_200();
 v_functionname:='findNullAttrvalInfo';
 for c in nullattrinfo loop
  push(v_log,c.line);
 end loop;
 insertLogs(v_functionname);
 end;
 function replaceControls(in_str varchar2) return varchar2 is
  begin
    if in_str is null then
      return null;
    end if;
    return translate(in_str,str_chrs,str_new_chrs);
  end replaceControls;
--
FUNCTION hasControls(in_str varchar2) RETURN number IS
BEGIN
   IF in_str IS NOT NULL THEN
      FOR i in 1..arr_chrs.count LOOP
         IF INSTR(in_str,arr_chrs(i)) > 0 THEN
            RETURN 1;
         END IF;
      END LOOP;
   END IF;
   RETURN 0;
END hasControls;
--
FUNCTION getString return varchar2 is
BEGIN
   return str_chrs;
END getString;
--
FUNCTION getNewString return varchar2 is
BEGIN
   return str_new_chrs;
END getNewString;
--
PROCEDURE processHasControls(excl_chars tofv DEFAULT tofv())
IS
   t_cols   ttab_name;                -- column names
   t_vals   ttab_int;                 -- return value - result of hasControls()
   lb_chr   BOOLEAN;
   l_chrs   VARCHAR2(300);            -- for TRANSLATE
   l_sql    VARCHAR2(32000);
   l_tabn   PLS_INTEGER:=0;           -- total table verified
   l_coln   PLS_INTEGER:=0;           -- total columns verified
   l_tm     PLS_INTEGER:=dbms_utility.get_time;
BEGIN
   v_log:=tofv_200();
   v_functionname:='processHasControls';
   --
   l_chrs:=''; arr_chrs.DELETE;
   FOR ii IN 1..31 LOOP
      lb_chr:=True;
      IF excl_chars.COUNT > 0 THEN
         FOR jj IN 1..excl_chars.COUNT LOOP
            IF excl_chars(jj) = CHR(ii) THEN
               lb_chr:=False;
               EXIT;
            END IF;
         END LOOP;
      END IF;
      IF lb_chr THEN
         arr_chrs(arr_chrs.COUNT+1):=CHR(ii);
         l_chrs:=l_chrs||'CHR('||ii||')||';
      END IF;
   END LOOP;
   l_chrs:=l_chrs||'CHR(0)';
   arr_chrs(arr_chrs.COUNT+1):=CHR(0);
   --
   FOR rc IN (SELECT table_name
                FROM user_tables
               WHERE table_name NOT LIKE '%==%'  --some oracle internal tables
                 AND (table_name LIKE 'EPM%' OR
                      table_name IN ('STRINGVALUE','WTPART','WTPARTMASTER','TEAM'))
               ORDER BY 1)
   LOOP
      SELECT column_name
        BULK COLLECT INTO t_cols
        FROM user_tab_columns
       WHERE table_name = rc.table_name
         AND column_name NOT LIKE 'CLASSNAME%'
         AND data_type IN ('CHAR','VARCHAR2');
      --
      IF t_cols.COUNT > 0 THEN
         l_tabn:=l_tabn+1;
         l_coln:=l_coln+t_cols.COUNT;
         --
         l_sql:='SELECT CASE n.ii';
         FOR ii IN 1..t_cols.COUNT LOOP
            l_sql:=l_sql||' WHEN '||ii||' THEN val'||ii;
         END LOOP;
         l_sql:=l_sql||' END FROM (SELECT ';
         FOR ii IN 1..t_cols.COUNT LOOP
            --    alternative approach (works slower)
            --l_sql:=l_sql||CASE WHEN ii = 1 THEN '' ELSE ',' END||
            --            'SUM(MIGDATACHECKPK.hasControls('||t_cols(ii)||')) val'||ii;
            --l_sql:=l_sql||CASE WHEN ii = 1 THEN '' ELSE ',' END||
            --            'SUM(CASE WHEN REGEXP_LIKE ('||t_cols(ii)||',''['''||l_chrs||''']'',''m'') THEN 1 ELSE 0 END) val'||ii;
            --
            l_sql:=l_sql||CASE WHEN ii = 1 THEN '' ELSE ',' END||
                        'SUM(CASE WHEN '||t_cols(ii)||' IS NULL THEN 0'||
                        ' WHEN NVL(LENGTH('||t_cols(ii)||'),0)='||
                        ' NVL(LENGTH(TRANSLATE('||t_cols(ii)||',''~''||'||l_chrs||',''~'')),0)'||
                        ' THEN 0 ELSE 1 END) val'||ii;
         END LOOP;
         l_sql:=l_sql||' FROM '||rc.table_name||') '||
                       'CROSS JOIN (SELECT level ii FROM dual connect by level <= '||t_cols.COUNT||') n '||
                       'ORDER BY n.ii';
         --
         EXECUTE IMMEDIATE l_sql BULK COLLECT INTO t_vals;
         --
         IF t_cols.COUNT <> t_vals.COUNT THEN
            raise_application_error(-20100,'Error with calculating hasControls (cols='||t_cols.COUNT||' vals='||t_vals.COUNT);
         END IF;
         FOR ii IN 1..t_cols.COUNT LOOP
            IF t_vals(ii) > 0 THEN
               push(v_log,'Column: '||rc.table_name||'.'||t_cols(ii)||' has '||t_vals(ii)||' rows with control characters.');
            END IF;
         END LOOP;
      END IF;
   END LOOP;
   push(v_log,'Totally '||l_coln||' columns in '||l_tabn||' tables have been verified.');
   push(v_log,'Elapsed: '||f_msec2time(dbms_utility.get_time-l_tm));
   --
   insertLogs(v_functionname);
EXCEPTION
   WHEN OTHERS THEN
      dbms_output.put_line(v_functionname);
      dbms_output.put_line(l_sql);
      RAISE;
END processHasControls;
--
PROCEDURE replaceNonUnicode IS
   t_cols   ttab_name;                -- column names
   t_vals   ttab_int;                 -- return value - result of hasControls()
   l_chrs   VARCHAR2(300);            -- for TRANSLATE
   l_ttrs   VARCHAR2(300);
   --
   t_tcs    ttab_cols;                -- list of tables.columns for UPDATE
   t_rid    ttab_rid;                 -- table of rowid
   c_ref    t_ref_cursor;
   l_ii     PLS_INTEGER;
   l_sql    VARCHAR2(32000);
   l_tabn   PLS_INTEGER:=0;           -- total table verified
   l_coln   PLS_INTEGER:=0;           -- total columns verified
   l_rown   PLS_INTEGER:=0;           -- total rows updated
   l_tm     PLS_INTEGER:=dbms_utility.get_time;
BEGIN
   v_log:=tofv_200();
   v_functionname:='replaceNonUnicode';
   --
   l_chrs:=''; l_ttrs:=''; t_tcs.DELETE;
   FOR ii IN 1..31 LOOP
      IF ii NOT IN (9,10,13) THEN         -- these characters will not be replaced
         l_chrs:=l_chrs||'CHR('||ii||')||';
         l_ttrs:=l_ttrs||'\e'||LPAD(LTRIM(TO_CHAR(ii,'xxx')),3,'0');
      END IF;
   END LOOP;
   l_chrs:=l_chrs||'CHR(0)';   -- chr(0) will be removed, other will be replaced
   --
   --str := chr(01)||chr(02)||chr(03)||chr(04)||chr(05)||chr(06)||chr(07)||chr(08)||***
   --           chr(31)||'~'||chr(00);
   --ttr := unistr('\e001\e002\e003\e004\e005\e006\e007\e008\e00b\e00c\e00e\e00f\e010')||
   --               unistr('\e011\e012\e013\e014\e015\e016\e017\e018\e019\e01a\e01b\e01c\e01d\e01e\e01f')||'~';
   --
   FOR rc IN (SELECT table_name
                FROM user_tables
               WHERE table_name NOT LIKE '%==%'  --some oracle internal tables
                 AND (table_name LIKE 'EPM%' OR
                      table_name IN ('STRINGVALUE','WTPART','WTPARTMASTER','TEAM'))
               ORDER BY 1)
   LOOP
      SELECT column_name
        BULK COLLECT INTO t_cols
        FROM user_tab_columns
       WHERE table_name = rc.table_name
         AND column_name NOT LIKE 'CLASSNAME%'
         AND data_type IN ('CHAR','VARCHAR2');
      --
      IF t_cols.COUNT > 0 THEN
         l_tabn:=l_tabn+1;
         l_coln:=l_coln+t_cols.COUNT;
         --
         l_sql:='SELECT CASE n.ii';
         FOR ii IN 1..t_cols.COUNT LOOP
            l_sql:=l_sql||' WHEN '||ii||' THEN val'||ii;
         END LOOP;
         l_sql:=l_sql||' END FROM (SELECT ';
         FOR ii IN 1..t_cols.COUNT LOOP
            l_sql:=l_sql||CASE WHEN ii = 1 THEN '' ELSE ',' END||
                        'SUM(CASE WHEN '||t_cols(ii)||' IS NULL THEN 0'||
                        ' WHEN NVL(LENGTH('||t_cols(ii)||'),0)='||
                        ' NVL(LENGTH(TRANSLATE('||t_cols(ii)||',''~''||'||l_chrs||',''~'')),0)'||
                        ' THEN 0 ELSE 1 END) val'||ii;
         END LOOP;
         l_sql:=l_sql||' FROM '||rc.table_name||') '||
                       'CROSS JOIN (SELECT level ii FROM dual connect by level <= '||t_cols.COUNT||') n '||
                       'ORDER BY n.ii';
         -- dbms_output.put_line(rc.table_name||'.'||'sql_len='||LENGTH(l_sql));
         --
         EXECUTE IMMEDIATE l_sql BULK COLLECT INTO t_vals;
         --
         IF t_cols.COUNT <> t_vals.COUNT THEN
            raise_application_error(-20100,'Error with calculating hasControls (cols='||t_cols.COUNT||' vals='||t_vals.COUNT);
         END IF;
         FOR ii IN 1..t_cols.COUNT LOOP
            IF t_vals(ii) > 0 THEN
               l_ii:=t_tcs.COUNT+1;
               t_tcs(l_ii).tab_name:=rc.table_name;
               t_tcs(l_ii).col_name:=t_cols(ii);
               --
               push(v_log,'Column: '||rc.table_name||'.'||t_cols(ii)||' has '||t_vals(ii)||' rows with control characters.');
            END IF;
         END LOOP;
      END IF;
   END LOOP;
   --
   IF t_tcs.COUNT = 0 THEN
      push(v_log,'Totally '||l_coln||' columns in '||l_tabn||' tables have been verified and no control characters were found.');
      push(v_log,'Elapsed: '||f_msec2time(dbms_utility.get_time-l_tm));
   ELSE
      push(v_log,'Totally '||l_coln||' columns in '||l_tabn||' tables have been verified and '||t_tcs.COUNT||' should be updated.');
      push(v_log,'Elapsed: '||f_msec2time(dbms_utility.get_time-l_tm));
      l_tm:=dbms_utility.get_time;
      --
      FOR jj IN 1..t_tcs.COUNT LOOP
         l_rown:=0;
         OPEN c_ref FOR
            'SELECT rowid FROM '||t_tcs(jj).tab_name||
            ' WHERE NVL(LENGTH('||t_tcs(jj).col_name||'),0)<>'||
                   'NVL(LENGTH(TRANSLATE('||t_tcs(jj).col_name||',''~''||'||l_chrs||',''~'')),0)';
         LOOP
            t_rid.DELETE;
            FETCH c_ref BULK COLLECT INTO t_rid LIMIT 100000;
            EXIT WHEN t_rid.COUNT = 0;
            --
            l_sql:='UPDATE '||t_tcs(jj).tab_name||
                   '   SET '||t_tcs(jj).col_name||' = TRANSLATE('||t_tcs(jj).col_name||','||l_chrs||',:1)'||
                   ' WHERE rowid = :2';
            --
            FORALL rr IN INDICES OF t_rid
               EXECUTE IMMEDIATE l_sql USING unistr(l_ttrs), t_rid(rr);
            --
            FOR ii IN t_rid.FIRST..t_rid.LAST
            LOOP
               l_rown:=l_rown+SQL%BULK_ROWCOUNT(ii);
            END LOOP;
            COMMIT;
            --
            IF restartMethodServer = 0 THEN
               restartMethodServer:= 1;
            END IF;
            EXIT WHEN c_ref%NOTFOUND;
         END LOOP;
         push(v_log, l_rown||' rows updated in '||t_tcs(jj).tab_name||'.'||t_tcs(jj).col_name);
         CLOSE c_ref;
      END LOOP;
      push(v_log,'Elapsed: '||f_msec2time(dbms_utility.get_time-l_tm));
   END IF;
   insertLogs(v_functionname);
EXCEPTION
   WHEN OTHERS THEN
      dbms_output.put_line(v_functionname);
      dbms_output.put_line(l_sql);
      RAISE;
END replaceNonUnicode;
--
PROCEDURE fixNullAttrvalFamTabs IS
   t_nn     ttab_vint;                          -- counter changes
   l_tm     PLS_INTEGER:=dbms_utility.get_time;
   l_newId  NUMBER;
BEGIN
   v_log:=tofv_200();
   v_functionname:='fixNullAttrvalFamTabs';
   t_nn('ALL'):=0; t_nn('NOD'):=0; t_nn('S'):=0; t_nn('I'):=0; t_nn('B'):=0; t_nn('F'):=0; t_nn('T'):=0;
   --
   -- find all documents and attributes for attribute cells
   FOR rc IN (
      SELECT DISTINCT doc_id, attr_id, attr_name, attr_type, map_hid, attr_hid, defn_id,
             CASE attr_type
                  WHEN 'S' THEN sv.ida2a2
                  WHEN 'I' THEN iv.ida2a2
                  WHEN 'B' THEN bv.ida2a2
                  WHEN 'F' THEN fv.ida2a2
                  WHEN 'T' THEN tv.ida2a2
                  ELSE NULL
              END val_id
        FROM (SELECT a.ida2a2 doc_id, e.ida2a2 attr_id, e.name attr_name, m.hierarchyidb4 map_hid,
                     CASE WHEN NVL2(m.hierarchyidb4,hs.ida2a2,ds.ida2a2) IS NOT NULL THEN 'S'
                          WHEN NVL2(m.hierarchyidb4,hi.ida2a2,di.ida2a2) IS NOT NULL THEN 'I'
                          WHEN NVL2(m.hierarchyidb4,hb.ida2a2,db.ida2a2) IS NOT NULL THEN 'B'
                          WHEN NVL2(m.hierarchyidb4,hf.ida2a2,df.ida2a2) IS NOT NULL THEN 'F'
                          WHEN NVL2(m.hierarchyidb4,ht.ida2a2,dt.ida2a2) IS NOT NULL THEN 'T'
                          ELSE NULL
                      END attr_type,
                     CASE WHEN NVL2(m.hierarchyidb4,hs.ida2a2,ds.ida2a2) IS NOT NULL THEN NVL2(m.hierarchyidb4,hs.hierarchyid,ds.hierarchyid)
                          WHEN NVL2(m.hierarchyidb4,hi.ida2a2,di.ida2a2) IS NOT NULL THEN NVL2(m.hierarchyidb4,hi.hierarchyid,di.hierarchyid)
                          WHEN NVL2(m.hierarchyidb4,hb.ida2a2,db.ida2a2) IS NOT NULL THEN NVL2(m.hierarchyidb4,hb.hierarchyid,db.hierarchyid)
                          WHEN NVL2(m.hierarchyidb4,hf.ida2a2,df.ida2a2) IS NOT NULL THEN NVL2(m.hierarchyidb4,hf.hierarchyid,df.hierarchyid)
                          WHEN NVL2(m.hierarchyidb4,ht.ida2a2,dt.ida2a2) IS NOT NULL THEN NVL2(m.hierarchyidb4,ht.hierarchyid,dt.hierarchyid)
                          ELSE NULL
                      END attr_hid,
                     CASE WHEN NVL2(m.hierarchyidb4,hs.ida2a2,ds.ida2a2) IS NOT NULL THEN NVL2(m.hierarchyidb4,hs.ida2a2,ds.ida2a2)
                          WHEN NVL2(m.hierarchyidb4,hi.ida2a2,di.ida2a2) IS NOT NULL THEN NVL2(m.hierarchyidb4,hi.ida2a2,di.ida2a2)
                          WHEN NVL2(m.hierarchyidb4,hb.ida2a2,db.ida2a2) IS NOT NULL THEN NVL2(m.hierarchyidb4,hb.ida2a2,db.ida2a2)
                          WHEN NVL2(m.hierarchyidb4,hf.ida2a2,df.ida2a2) IS NOT NULL THEN NVL2(m.hierarchyidb4,hf.ida2a2,df.ida2a2)
                          WHEN NVL2(m.hierarchyidb4,ht.ida2a2,dt.ida2a2) IS NOT NULL THEN NVL2(m.hierarchyidb4,ht.ida2a2,dt.ida2a2)
                          ELSE NULL
                      END defn_id
                FROM epmdocument a
                JOIN epmcontainedin b ON (b.ida3a5 = a.ida2a2)
                JOIN epmfamilytablecell d ON (d.ida3a3 = b.ida2a2)
                JOIN epmfamilytableattribute e ON (e.ida2a2 = d.ida3b3)
                JOIN epmsepfamilytable s ON (s.ida2a2 = e.ida3a3)
                JOIN lotowcstatus l ON (l.epmsepfamilytablemasterid = s.ida3masterreference)
                LEFT JOIN epmparametermap m ON (m.ida3a4 = a.ida2a2 AND m.parametername = e.name)
                --
                LEFT JOIN stringdefinition ds    ON (ds.name = e.name)
                LEFT JOIN integerdefinition di   ON (di.name = e.name)
                LEFT JOIN booleandefinition db   ON (db.name = e.name)
                LEFT JOIN floatdefinition df     ON (df.name = e.name)
                LEFT JOIN timestampdefinition dt ON (dt.name = e.name)
                --
                LEFT JOIN stringdefinition hs    ON (hs.hierarchyid = m.hierarchyidb4)
                LEFT JOIN integerdefinition hi   ON (hi.hierarchyid = m.hierarchyidb4)
                LEFT JOIN booleandefinition hb   ON (hb.hierarchyid = m.hierarchyidb4)
                LEFT JOIN floatdefinition hf     ON (hf.hierarchyid = m.hierarchyidb4)
                LEFT JOIN timestampdefinition ht ON (ht.hierarchyid = m.hierarchyidb4)
               WHERE e.classnamekeya3 = 'wt.epm.familytable.EPMSepFamilyTable'
            )
        LEFT JOIN stringvalue sv    ON (sv.hierarchyida6 = attr_hid and sv.ida3a4 = doc_id)
        LEFT JOIN integervalue iv   ON (iv.hierarchyida6 = attr_hid and iv.ida3a4 = doc_id)
        LEFT JOIN booleanvalue bv   ON (bv.hierarchyida6 = attr_hid and bv.ida3a4 = doc_id)
        LEFT JOIN floatvalue fv     ON (fv.hierarchyida6 = attr_hid and fv.ida3a4 = doc_id)
        LEFT JOIN timestampvalue tv ON (tv.hierarchyida6 = attr_hid and tv.ida3a4 = doc_id))
   LOOP
      t_nn('ALL'):=t_nn('ALL')+1;
      --
      IF rc.attr_hid IS NULL THEN
         IF t_nn('NOD') < 100 THEN
            push(v_log,'No attribute definition found for EPMDocument:'||rc.doc_id||'|| EPMFTAttribute:'||rc.attr_id||'|| COL_NAME:'||rc.attr_name);
         END IF;
         t_nn('NOD'):=t_nn('NOD')+1;
      ELSE
         IF rc.val_id IS NULL THEN     -- attribute not found in stringvalue,integervalue, etc.
            IF rc.attr_type IN ('S','I','B','F','T') THEN
               t_nn(rc.attr_type):=t_nn(rc.attr_type)+1;
            ELSE
               raise_application_error(-20100,'Incorrect table type definition "'||rc.attr_type||'"');
            END IF;
            --
            l_newId := MigrationPK.GetNewWCID;
            EXECUTE IMMEDIATE
               'INSERT INTO '||CASE rc.attr_type
                                 WHEN 'S' THEN 'StringValue'
                                 WHEN 'I' THEN 'IntegerValue'
                                 WHEN 'B' THEN 'BooleanValue'
                                 WHEN 'F' THEN 'FloatValue'
                                 WHEN 'T' THEN 'TimestampValue'
                               END||
                     ' (classnamekeya5, ida3a5, hierarchyida6, classnamekeya6, ida3a6, classnamekeya4, ida3a4, createstampa2,'||
                     '  modifystampa2, classnamea2a2, ida2a2, updatecounta2, updatestampa2, value, markfordeletea2)'||
               ' VALUES (NULL, NULL, :1, :2, :3, :4, :5, :6, :7, :8, :9, :10, :11, :12, 0)'
               USING rc.attr_hid,
                     CASE rc.attr_type
                        WHEN 'S' THEN 'wt.iba.definition.StringDefinition'
                        WHEN 'I' THEN 'wt.iba.definition.IntegerDefinition'
                        WHEN 'B' THEN 'wt.iba.definition.BooleanDefinition'
                        WHEN 'F' THEN 'wt.iba.definition.FloatDefinition'
                        WHEN 'T' THEN 'wt.iba.definition.TimestampDefinition'
                     END,
                     rc.defn_id,
                     'wt.epm.EPMDocument',
                     rc.doc_id,
                     SYSDATE,
                     SYSDATE,
                     CASE rc.attr_type
                        WHEN 'S' THEN 'wt.iba.value.StringValue'
                        WHEN 'I' THEN 'wt.iba.value.IntegerValue'
                        WHEN 'B' THEN 'wt.iba.value.BooleanValue'
                        WHEN 'F' THEN 'wt.iba.value.FloatValue'
                        WHEN 'T' THEN 'wt.iba.value.TimestampValue'
                     END,
                     l_newId,
                     1,
                     SYSDATE,
                     CASE rc.attr_type
                        WHEN 'S' THEN ''
                        WHEN 'I' THEN '0'
                        WHEN 'B' THEN '0'
                        WHEN 'F' THEN '0'
                        WHEN 'T' THEN TO_CHAR(SYSDATE)
                     END;
            --
            IF restartMethodServer = 0 THEN
               restartMethodServer:=1;
            END IF;
         END IF;
      END IF;
   END LOOP;
   --
   push(v_log,'No. of cells = '||t_nn('ALL'));
   push(v_log,'No. of cells with no definition = '||t_nn('NOD'));
   push(v_log,'No. of string  cells inserted   = '||t_nn('S'));
   push(v_log,'No. of integer cells inserted   = '||t_nn('I'));
   push(v_log,'No. of boolean cells inserted   = '||t_nn('B'));
   push(v_log,'No. of float   cells inserted   = '||t_nn('F'));
   push(v_log,'No. of timestamp cells inserted = '||t_nn('T'));
   IF restartMethodServer = 1 THEN
      push(v_log,' ');
      push(v_log,'======================================================================');
      push(v_log,'Please restart the Method Server after this script is run successfully');
      push(v_log,'======================================================================');
      push(v_log,' ');
   END IF;
   push(v_log,'Elapsed: '||f_msec2time(dbms_utility.get_time-l_tm));
   --
   insertLogs(v_functionname);
   COMMIT;
END fixNullAttrvalFamTabs;
--
---========================================================================================

/* Added on 2009/07/22 19:09 */ -- SPR 1833016 Need to include the healing of migrated designated
-- FT dimensions [with linefeed character] automatically in post migration data check.
PROCEDURE fixnewlineinattrvalfamtabs
IS
   v_records_with_chr10    NUMBER  := 0;
   l_processed_records     INTEGER := 0;
   l_failed_records        INTEGER := 0;
   l_first_failure         BOOLEAN := TRUE;
   v_nlfta_count           NUMBER  := 0;
   v_records_updated       NUMBER  := 0;
   v_non_updated_records   NUMBER  := 0;
   l_tm     PLS_INTEGER:=dbms_utility.get_time;
BEGIN
   v_functionname := 'FIXNEWLINEINATTRVALFAMTABS';
   v_log:=tofv_200();
   BEGIN


--How many rows affected
      SELECT COUNT (*)
        INTO v_records_with_chr10
        FROM epmfamilytableattribute a,
             epmsepfamilytable f,
             epmsepfamilytablemaster m
       WHERE INSTR (title, CHR (10)) > 1
         AND a.ida3a3 = f.ida2a2
         AND f.ida3masterreference = m.ida2a2;

--How many FTs affected
      SELECT COUNT (DISTINCT m.NAME)
        INTO v_nlfta_count
        FROM epmfamilytableattribute a,
             epmsepfamilytable f,
             epmsepfamilytablemaster m
       WHERE INSTR (title, CHR (10)) > 1
         AND a.ida3a3 = f.ida2a2
         AND f.ida3masterreference = m.ida2a2;

--1
-- Auto Heal the ProE Objects

      FOR cur_rec IN
         (SELECT d.hierarchyid hierarchyidb4, d.classnamea2a2 classnamekeyb4,
                 d.ida2a2 ida3b4, a.part1 parametername,
                 'wt.epm.EPMDocument' classnamekeya4, a.part3 ida3a4,
                 SYSDATE createstampa2, 0 markfordeletea2,
                 SYSDATE modifystampa2,
                 'wt.epm.attributes.EPMParameterMap' classnamea2a2,
                 id_sequence.NEXTVAL ida2a2, 1 updatecounta2,
                 SYSDATE updatestampa2
            FROM floatdefinition d,
                 (SELECT DISTINCT SUBSTR (f.title,
                                          1,
                                          INSTR (f.title, CHR (10)) - 1
                                         ) part1,
                                  c.ida3a5 part3,
                                  UPPER (SUBSTR (title,
                                                 INSTR (title, CHR (10)) + 1
                                                )
                                        ) part2
                             FROM epmfamilytableattribute f, epmcontainedin c
                            WHERE INSTR (f.title, CHR (10)) > 1
                              AND f.ATTRIBUTE = 3
                              AND f.ida3a3 = c.ida3b5) a
           WHERE d.NAME = UPPER (a.part2))
      LOOP
         BEGIN
            INSERT INTO epmparametermap
                        (hierarchyidb4, classnamekeyb4,
                         ida3b4, parametername,
                         classnamekeya4, ida3a4,
                         createstampa2, markfordeletea2,
                         modifystampa2, classnamea2a2,
                         ida2a2, updatecounta2,
                         updatestampa2
                        )
                 VALUES (cur_rec.hierarchyidb4, cur_rec.classnamekeyb4,
                         cur_rec.ida3b4, cur_rec.parametername,
                         cur_rec.classnamekeya4, cur_rec.ida3a4,
                         cur_rec.createstampa2, cur_rec.markfordeletea2,
                         cur_rec.modifystampa2, cur_rec.classnamea2a2,
                         cur_rec.ida2a2, cur_rec.updatecounta2,
                         cur_rec.updatestampa2
                        );

            l_processed_records := l_processed_records + 1;
         EXCEPTION
            WHEN DUP_VAL_ON_INDEX
            THEN
               l_failed_records := l_failed_records + 1;

               IF l_first_failure
               THEN
                  l_first_failure := FALSE;
                  --DBMS_OUTPUT.put_line('The record(s) in EPMPARAMETERMAP table with the same unique key(s) already exist(s):');
               END IF;

               --DBMS_OUTPUT.put_line (   'IDA3B4='|| cur_rec.ida3b4|| ' IDA3A4='|| cur_rec.ida3a4);
         END;
      END LOOP;

      --DBMS_OUTPUT.put_line ('Inserted ' || l_processed_records || ' records.');
      --DBMS_OUTPUT.put_line ('Failed ' || l_failed_records || ' records.');
   END;

--2==
   BEGIN
      UPDATE epmfamilytableattribute
         SET NAME = SUBSTR (title, 1, INSTR (title, CHR (10)) - 1),
             title = UPPER (SUBSTR (title, INSTR (title, CHR (10)) + 1))
       WHERE INSTR (title, CHR (10)) > 1
         AND ida2a2 IN (
                SELECT DISTINCT f.ida2a2
                           FROM floatdefinition d,
                                epmfamilytableattribute f,
                                epmcontainedin c
                          WHERE 1 = 1
                            AND INSTR (f.title, CHR (10)) > 1
                            AND f.ATTRIBUTE = 3
                            AND f.ida3a3 = c.ida3b5
                            AND d.NAME = UPPER (SUBSTR (title,INSTR (title, CHR (10)) + 1))
                        );

      v_records_updated := SQL%ROWCOUNT;
--dbms_output.put_line('Updated '||sql%rowcount||' records.');
   END;

-- 3 Output of non-updated records
   SELECT COUNT (*)
     INTO v_non_updated_records
     FROM epmfamilytableattribute a,
          epmsepfamilytable f,
          epmsepfamilytablemaster m
    WHERE INSTR (title, CHR (10)) > 1
      AND a.ida3a3 = f.ida2a2
      AND f.ida3masterreference = m.ida2a2;

   push (v_log, 'No. of Records with problematic newline in attribute columns of family tables = ' || v_records_with_chr10);
   push (v_log, 'No. of Distinct Family tables with problematic newline in attribute columns  = ' || v_nlfta_count );
   push (v_log, 'No. of Records Updated to heal = ' || v_records_updated);
   push (v_log, 'No. of updates failed to heal = ' || l_failed_records);
   push (v_log, 'No. of Records with newline in attributes column after healing = '    || v_non_updated_records );
   push (v_log, 'Please contact PTC Support if there are some Records with newline char in attribute columns and these family table columns are not visible in ProE.');
   push (v_log, ' ');

if v_records_updated>0 then
   IF restartmethodserver = 0 THEN restartmethodserver := 1;
   END IF;
end if;

   IF restartmethodserver = 1 THEN
      push (v_log, ' ');
      push (v_log, '======================================================================' );
      push (v_log, 'Please restart the Method Server after this script is run successfully' );
      push (v_log, '======================================================================' );
      push (v_log, ' ');
   END IF;

   push(v_log,'Elapsed: '||f_msec2time(dbms_utility.get_time-l_tm));
   insertlogs (v_functionname);
   COMMIT;

END fixnewlineinattrvalfamtabs;

--======================================================================================================
-- Healing procedure for MemberLinks having duplicate identifier or identifier as -1. (SPR 2109980)
--
PROCEDURE healMemberLinkIdentifier
IS
   C1       t_ref_cursor;
   C2       t_ref_cursor;
   t_ids    ttab_num;                  -- table of ida2a2
   l_rows   PLS_INTEGER;               -- rows updated
   l_sql    CONSTANT VARCHAR2(300) := 'UPDATE EPMMEMBERLINK SET identifier = null WHERE ida2a2=:1';
   l_tm     PLS_INTEGER:=dbms_utility.get_time;
BEGIN
   v_log:=tofv_200();
   v_functionname:='healMemberLinkIdentifier';
   --
   -- 1. Heal EPMMemberLinks with duplicate identifier
   l_rows:=0; t_ids.DELETE;
   OPEN C1 FOR
      SELECT /*+USE_HASH(q s) LEADING(q) */ q.ida2a2
        FROM (SELECT ida2a2, ida3a5,
                     RANK() OVER (PARTITION BY ida3a5, identifier ORDER BY updatestampa2,ida2a2) SeqNumber
                FROM epmmemberlink
               WHERE identifier IS NOT NULL AND identifier !=-1) q
        JOIN deptowcstatus s ON (s.epmlinkid = q.ida2a2)
       WHERE s.status = 1 AND q.SeqNumber > 1;
   LOOP
      FETCH C1 BULK COLLECT INTO t_ids LIMIT 100000;
      IF t_ids.COUNT > 0 THEN
         FORALL i IN 1..t_ids.COUNT
            EXECUTE IMMEDIATE l_sql USING t_ids(i);
         l_rows:=l_rows+t_ids.COUNT;
      END IF;
      EXIT WHEN C1%NOTFOUND;
   END LOOP;
   CLOSE C1;
   push (v_log, 'No. of MemberLinks with duplicate identifier healed = '||l_rows);
   --
   -- 2. Heal EPMMemberLinks with identifier -1
   l_rows:=0; t_ids.DELETE;
   OPEN C2 FOR
      SELECT /*+USE_HASH(m s) LEADING(m) */ m.ida2a2
        FROM epmmemberlink m, deptowcstatus s
       WHERE s.epmlinkid = m.ida2a2
         AND s.status = 1
         AND m.identifier = -1;
   LOOP
      FETCH C2 BULK COLLECT INTO t_ids LIMIT 100000;
      IF t_ids.COUNT > 0 THEN
         FORALL i IN 1..t_ids.COUNT
            EXECUTE IMMEDIATE l_sql USING t_ids(i);
         l_rows:=l_rows+t_ids.COUNT;
      END IF;
      EXIT WHEN C2%NOTFOUND;
   END LOOP;
   CLOSE C2;
   push (v_log, 'No. of MemberLinks with -1 identifier healed = ' ||l_rows);
   push (v_log, 'Elapsed: '||f_msec2time(dbms_utility.get_time-l_tm));
   insertlogs (v_functionname);
   COMMIT;
EXCEPTION WHEN OTHERS THEN
   push (v_log, 'Error while healing MemberLink identifier : '||SUBSTR(SQLERRM,1,100));
   ROLLBACK;
   insertlogs (v_functionname);
END healMemberLinkIdentifier;
--
--========================================================================================================
-- Healing procedure for MemberLinks and ReferenceLinks having duplicate UniqueLinkId
--
PROCEDURE healUniqueLinkId
IS
   l_tm     PLS_INTEGER:=dbms_utility.get_time;
BEGIN
   v_log:=tofv_200();
   v_functionname:='healUniqueLinkId';
   --
   -- 1. Heal EPMMemberLinks with duplicate UniqueLinkId
   UPDATE epmmemberlink
      SET uniqueLinkId = migrationpk.getnewwcid
    WHERE rowid IN
           (SELECT /*+USE_HASH(q st) LEADING(q) */ q.row_id
              FROM (SELECT m.rowid row_id, m.ida2a2,
                           RANK() OVER (PARTITION BY m.ida3a5, m.uniquelinkid ORDER BY m.ida2a2) row_nums
                      FROM epmmemberlink m
                     WHERE m.uniquelinkid IS NOT NULL) q
              JOIN deptowcstatus st ON (st.epmlinkid = q.ida2a2)
             WHERE st.status = 1
               AND row_nums  > 1
             );
   push (v_log, 'No. of MemberLinks with duplicate UniqueLinkId healed = ' || SQL%ROWCOUNT);
   --
   -- 2. Heal EPMReferenceLinks duplicate UniqueLinkId
   UPDATE epmreferencelink
      SET uniqueLinkId = migrationpk.getnewwcid
    WHERE rowid IN
           (SELECT /*+USE_HASH(q st) LEADING(q) */ q.row_id
              FROM (SELECT r.rowid row_id, r.ida2a2,
                           RANK() OVER (PARTITION BY r.ida3a5, r.uniquelinkid ORDER BY r.ida2a2) row_nums
                      FROM epmreferencelink r
                     WHERE r.uniquelinkid IS NOT NULL) q
              JOIN deptowcstatus st ON (st.epmlinkid = q.ida2a2)
             WHERE st.status = 1
               AND row_nums > 1
             );
   push (v_log, 'No. of ReferenceLinks with duplicate UniqueLinkId healed = ' || SQL%ROWCOUNT);
   push (v_log, 'Elapsed: '||f_msec2time(dbms_utility.get_time-l_tm));
   insertlogs (v_functionname);
   COMMIT;
EXCEPTION WHEN OTHERS THEN
   push (v_log, 'Error while healing  MemberLink and ReferenceLink having duplicate UniqueLinkId : '||SUBSTR(SQLERRM,1,100));
   ROLLBACK;
   insertlogs (v_functionname);
END healUniqueLinkId;
END;
/

