create procedure heal_cab_folder_corruption (v_lasthealedtimestamp IN date, v_error OUT varchar2) is
   v_healable varchar2(100);
   v_max_run_cnt number;
   v_rows_updated number;
   type refcur is ref cursor;
   c_ALIGNMENT_EPMDOCUMENT refcur;

   v_sqlstmt varchar2(8000);


 TYPE fetch_array_document IS TABLE OF MIG$CABINETFOLDER%ROWTYPE;
 s_array_document fetch_array_document;

begin
  dbms_output.put_line('============================================================');
  dbms_output.put_line('Heal Alignment corruption....heal_cabinet_folder_corruption_3.sql');
  dbms_output.put_line(to_char(sysdate,'MM/DD/YYYY HH24:MI:SS'));
  dbms_output.put_line('============================================================');

  dbms_output.put_line('Update cabinet and parent folder of non latest-latest versions where cabinet is mismatched with latest-latest and not checked out');

  dbms_output.put_line(to_char(sysdate,'MM/DD/YYYY HH24:MI:SS'));

  v_sqlstmt := 'select distinct non_latest.idA2A2, null IDA3DOMAINREF, latest.idA3A2folderinginfo LCAB, latest.idA3B2folderinginfo LFOL
     		, latest.classnamekeyb2folderinginfo LCLASSCAB
      		, null NL_IDA3DOMAINREF, non_latest.idA3A2folderinginfo NONLCAB, non_latest.idA3B2folderinginfo NONLFOL
      		, non_latest.classnamekeyb2folderinginfo NONLCLASSCAB, sysdate
    		, decode(pivst.status,null,''Object not Migrated'',
    			decode(pivst.status,1,
    				decode(non_latest.STATECHECKOUTINFO,''c/i'',''Healable'',''Object not checked in''),''Object was not migrated successfully'')) isHealable
    		, :v_max_run_cnt  runcount
    		from EPMDocument latest, EPMDocument non_latest, pivtowcstatus pivst, (
  			    select * from (
  			      select idA2A2, rank() over (
  				partition by idA3masterReference
  				order by decode(statecheckoutinfo, ''wrk'', 0, 1) desc,
  				versionSortIdA2versionInfo desc
  			      ) rank
  			      from EPMDocument
  			      where latestiterationInfo = 1 and classnamekeycontainerreferen in (''wt.pdmlink.PDMLinkProduct'',''wt.inf.library.WTLibrary'')
  			     ) where rank = 1
  			   ) sub
    		where
  		    latest.idA3masterReference = non_latest.idA3masterReference
  		    and (latest.idA3A2folderingInfo <> non_latest.idA3A2folderingInfo or latest.idA3B2folderinginfo <> non_latest.idA3B2folderinginfo)
  		    and latest.latestIterationInfo=1
  		    and non_latest.latestIterationinfo=1
  		    and non_latest.statecheckoutInfo <> ''wrk''
  		    and latest.idA2A2 = sub.idA2A2
  		    and pivst.epmdocumentid(+) = non_latest.idA2A2
  		    and pivst.documenttype = 0
		    and non_latest.classnamekeycontainerreferen in (''wt.inf.library.WTLibrary'',''wt.pdmlink.PDMLinkProduct'')';

  select nvl(max(runcount),0) into  v_max_run_cnt from MIG$CABINETFOLDER where MIG$CABINETFOLDER.IDA3DOMAINREF is null;
  v_max_run_cnt := v_max_run_cnt+1;
  v_error :='No Errors';

  if (v_lasthealedtimestamp is not null) then
    v_sqlstmt := v_sqlstmt||' and loadtime>'''||v_lasthealedtimestamp||'''';
  end if;

  OPEN c_ALIGNMENT_EPMDOCUMENT for v_sqlstmt using v_max_run_cnt;
    LOOP
      FETCH c_ALIGNMENT_EPMDOCUMENT BULK COLLECT INTO s_array_document LIMIT 10000;
      FORALL i IN 1..s_array_document.COUNT
       insert into MIG$CABINETFOLDER values s_array_document(i);
      EXIT WHEN c_ALIGNMENT_EPMDOCUMENT%NOTFOUND;
    END LOOP;
  CLOSE c_ALIGNMENT_EPMDOCUMENT;

  dbms_output.put_line(to_char(sysdate,'MM/DD/YYYY HH24:MI:SS'));

  update EPMDocument set (ida3a2folderinginfo, ida3b2folderinginfo, classnamekeyb2folderinginfo) = (
    select ida3a2folderinginfo, ida3b2folderinginfo, classnamekeyb2folderinginfo from MIG$CABINETFOLDER
      where EPMDocument.ida2a2 = MIG$CABINETFOLDER.ida2a2 and runcount=v_max_run_cnt and healable = 'Healable' and MIG$CABINETFOLDER.IDA3DOMAINREF is null)
  where EPMDocument.ida2a2 in (select ida2a2 from MIG$CABINETFOLDER where runcount=v_max_run_cnt and healable = 'Healable'  and MIG$CABINETFOLDER.IDA3DOMAINREF is null);

  v_rows_updated:=sql%rowcount;
  dbms_output.put_line('EPMDocument Rows Updated='||v_rows_updated);
  dbms_output.put_line(to_char(sysdate,'MM/DD/YYYY HH24:MI:SS'));

  commit;
  dbms_output.put_line(to_char(sysdate,'MM/DD/YYYY HH24:MI:SS'));

  exception when others then
     	Rollback;
	v_error := DBMS_UTILITY.format_error_stack;
	dbms_output.put_line('FILENAME$NonHealable_cabinet_folder_corruption_3.html$');

end;
/

