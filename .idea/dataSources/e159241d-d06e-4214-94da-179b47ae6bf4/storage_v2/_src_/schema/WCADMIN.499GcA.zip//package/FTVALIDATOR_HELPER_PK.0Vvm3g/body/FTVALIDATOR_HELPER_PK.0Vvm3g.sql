create package body FTValidator_Helper_PK IS
-- CONSTANTS
c_CHAR_DFLT  CONSTANT VARCHAR2(10):= 'UNKNOWN';
c_NUMBER_DFLT  CONSTANT NUMBER := -2;
c_ALL  CONSTANT VARCHAR2(10):='ALL';
c_99999  CONSTANT NUMBER := 99999;
-- PARSABLE CONFIG PARAMETERS
c_STOP_AT_FIRST  CONSTANT VARCHAR2(20):='STOP_AT_FIRST';
c_STOP_AT_FIRST_VAL_TRUE CONSTANT VARCHAR2(10):='TRUE';
c_STOP_AT_FIRST_VAL_FALSE CONSTANT VARCHAR2(10):='FALSE';
--
c_RECORDING_MODE   CONSTANT VARCHAR2(20):='RECORDING_MODE';
c_RECORDING_MODE_VAL_COLL   CONSTANT VARCHAR2(10):='COLLECTION';
c_RECORDING_MODE_VAL_TABL   CONSTANT VARCHAR2(10):='TABLE';
--
c_VALIDATE_OTHER_DETECTABLES  CONSTANT VARCHAR2(30):='VALIDATE_OTHER_DETECTABLES';
c_VALIDATE_OTHER_VAL_TRUE CONSTANT VARCHAR2(10):='TRUE';
c_VALIDATE_OTHER_VAL_FALSE CONSTANT VARCHAR2(10):='FALSE';
--
c_LIMIT  CONSTANT VARCHAR2(10):='LIMIT';
c_LIMIT_RECORD_ALL   CONSTANT NUMBER := -1;
c_LIMIT_EXCLUDE_IT   CONSTANT NUMBER := 0;
--
--====================================================================
--  internal procedures
--===================================================================
---------------------------------------------------------------------------------------------------
-- Support for mainitaining error counts metadata in table
---------------------------------------------------------------------------------------------------
--
FUNCTION initialize_err_counts RETURN FTVAL_CURR_CNT_TABLE
AS
v_Err_Counts   FTVAL_CURR_CNT_TABLE;
type t_errors is table of CURR_CNT_TABLE%ROWTYPE;
r_errors t_errors;
CURSOR C1 IS
SELECT * FROM CURR_CNT_TABLE;
BEGIN
v_Err_Counts := new FTVAL_CURR_CNT_TABLE();
OPEN C1;
FETCH C1
BULK COLLECT INTO r_errors;
CLOSE C1;
if r_errors.count > 0 then
for i in r_errors.first..r_errors.last loop
v_Err_Counts.extend();
v_Err_Counts(v_Err_Counts.LAST)  := new FTVAL_CURR_CNT(r_errors(i).ERR_CODE
, r_errors(i).ERR_CLASS
, r_errors(i).CURR_CNT);
end loop;
end if;
RETURN v_Err_Counts;
END initialize_err_counts;
--
--
--
PROCEDURE insert_err_count_record(p_Error_Code 	IN NUMBER,
p_Error_Class 	IN VARCHAR2,
p_Err_Count 	IN NUMBER)
IS
BEGIN
INSERT INTO CURR_CNT_TABLE(ERR_CODE, ERR_CLASS, CURR_CNT)
VALUES(p_Error_Code, p_Error_Class, p_Err_Count);
END;
--
--
--
PROCEDURE update_err_count_record(p_Error_Code 	IN NUMBER,
p_Error_Class 	IN VARCHAR2,
p_Err_Count 	IN NUMBER)
IS
BEGIN
UPDATE CURR_CNT_TABLE
SET CURR_CNT = p_Err_Count
WHERE
ERR_CODE = p_Error_Code
AND	ERR_CLASS = p_Error_Class;
END;
--
--
--
---------------------------------------------------------------------------------------------------
---------------------------------------------------------------------------------------------------
--
PROCEDURE validate_param_init     ( p_Param           IN    VARCHAR2
, p_Param_Value     IN    VARCHAR2
, p_Error_Code      IN    NUMBER
, p_Error_Class     IN    VARCHAR2
, p_Default_Value   IN    VARCHAR2 ) IS
BEGIN
if  (p_Param_Value = p_Default_Value)  then
raise_application_error(-20511, 'Invalid FTVal_Config: Parameter '||p_Param||
'  for ERR_CODE = '||to_char(p_Error_Code)||
' and ERR_CLASS = '||p_Error_Class||' is not initialized.' , true);
end if;
END;
--
PROCEDURE read_config_values(
p_FT_Config_Data            IN     FTVAL_CONFIG_TABLE
, p_level                     IN     NUMBER -- 1=ALL, 2=CLASS, 3= ERROR
, p_Validate_Params	      IN     BOOLEAN
, p_Error_Code                IN     NUMBER
, p_Error_Class               IN     VARCHAR2
, p_All_Stop_At_First            OUT VARCHAR2
, p_All_Validate_Other_Detect    OUT VARCHAR2
, p_All_Recording_Mode           OUT VARCHAR2
, p_Error_Limit                  OUT NUMBER   -- for level=3 only
, p_At_Least_1_Limit_Found       OUT BOOLEAN --check if the class or ALL (depending on p_level) has at least 1limit <>0
) IS
--
invalid_config_param exception;
--
l_err_Msg VARCHAR2(1000);
l_All_Limit	NUMBER;
l_Class_Limit	NUMBER;
BEGIN
p_All_Stop_At_First 	:=c_CHAR_DFLT;
p_All_Validate_Other_Detect	:=c_CHAR_DFLT;
p_All_Recording_Mode	:=c_CHAR_DFLT;
l_All_Limit			:=c_NUMBER_DFLT;
--  config parameters for Class level
l_Class_Limit		:=c_NUMBER_DFLT;
--  config parameters for Error Code level
p_Error_Limit		:=c_NUMBER_DFLT;
p_At_Least_1_Limit_Found 	:= FALSE;
if  (p_FT_Config_Data IS NULL)  then
raise_application_error(-20514, 'Invalid usage of FTValidator_Helper_PK.should_validate_error: Parameter  p_FT_Config_Data IS NULL', true);
end if;
IF p_FT_Config_Data.COUNT > 0 THEN
FOR i in 1..p_FT_Config_Data.COUNT
LOOP
if (p_All_Stop_At_First = c_CHAR_DFLT and
p_FT_Config_Data(i).PARAM_NAME = c_STOP_AT_FIRST and
p_FT_Config_Data(i).ERR_CODE = c_99999 and
p_FT_Config_Data(i).ERR_CLASS = c_ALL ) then
if p_FT_Config_Data(i).PARAM_CHR_VAL IS NULL OR (
p_FT_Config_Data(i).PARAM_CHR_VAL <> c_STOP_AT_FIRST_VAL_TRUE AND
p_FT_Config_Data(i).PARAM_CHR_VAL <> c_STOP_AT_FIRST_VAL_FALSE ) then
if p_Validate_Params then
l_err_Msg:='Invalid FTVal_Config: Parameter '||p_FT_Config_Data(i).PARAM_NAME||
'  for ERR_CODE = '||to_char(p_FT_Config_Data(i).ERR_CODE)||' and ERR_CLASS = '||p_FT_Config_Data(i).ERR_CLASS||' is not set correctly. Value='
||p_FT_Config_Data(i).PARAM_CHR_VAL||', allowed values are: '||c_STOP_AT_FIRST_VAL_TRUE||', '||c_STOP_AT_FIRST_VAL_FALSE;
raise invalid_config_param;
end if;
end if;
p_All_Stop_At_First:= p_FT_Config_Data(i).PARAM_CHR_VAL;
elsif (p_All_Validate_Other_Detect= c_CHAR_DFLT and
p_FT_Config_Data(i).PARAM_NAME = c_VALIDATE_OTHER_DETECTABLES and
p_FT_Config_Data(i).ERR_CODE = c_99999 and
p_FT_Config_Data(i).ERR_CLASS = c_ALL ) then
if p_Validate_Params then
if p_FT_Config_Data(i).PARAM_CHR_VAL IS NULL OR (
p_FT_Config_Data(i).PARAM_CHR_VAL <> c_VALIDATE_OTHER_VAL_TRUE AND
p_FT_Config_Data(i).PARAM_CHR_VAL <> c_VALIDATE_OTHER_VAL_FALSE ) then
l_err_Msg:='Invalid FTVal_Config: Parameter '||p_FT_Config_Data(i).PARAM_NAME||
'  for ERR_CODE = '||to_char(p_FT_Config_Data(i).ERR_CODE)||' and ERR_CLASS = '||p_FT_Config_Data(i).ERR_CLASS||' is not set correctly. Value='
||p_FT_Config_Data(i).PARAM_CHR_VAL||', allowed values are: '||c_VALIDATE_OTHER_VAL_TRUE||', '||c_VALIDATE_OTHER_VAL_FALSE;
raise invalid_config_param;
end if;
end if;
p_All_Validate_Other_Detect:= p_FT_Config_Data(i).PARAM_CHR_VAL;
elsif (p_All_Recording_Mode= c_CHAR_DFLT and
p_FT_Config_Data(i).PARAM_NAME = c_RECORDING_MODE and
p_FT_Config_Data(i).ERR_CODE = c_99999 and
p_FT_Config_Data(i).ERR_CLASS = c_ALL ) then
if p_Validate_Params then
if p_FT_Config_Data(i).PARAM_CHR_VAL IS NULL OR (
p_FT_Config_Data(i).PARAM_CHR_VAL <> c_RECORDING_MODE_VAL_COLL AND
p_FT_Config_Data(i).PARAM_CHR_VAL <> c_RECORDING_MODE_VAL_TABL ) then
l_err_Msg:='Invalid FTVal_Config: Parameter '||p_FT_Config_Data(i).PARAM_NAME||
'  for ERR_CODE = '||to_char(p_FT_Config_Data(i).ERR_CODE)||' and ERR_CLASS = '||p_FT_Config_Data(i).ERR_CLASS||' is not set correctly. Value='
||p_FT_Config_Data(i).PARAM_CHR_VAL||', allowed values are: '||c_RECORDING_MODE_VAL_COLL||', '||c_RECORDING_MODE_VAL_TABL;
raise invalid_config_param;
end if;
end if;
p_All_Recording_Mode:= p_FT_Config_Data(i).PARAM_CHR_VAL;
elsif (p_level =3 and
l_All_Limit= c_NUMBER_DFLT and
p_FT_Config_Data(i).PARAM_NAME = c_LIMIT and
p_FT_Config_Data(i).ERR_CODE = c_99999 and
p_FT_Config_Data(i).ERR_CLASS = c_ALL ) then
if p_FT_Config_Data(i).PARAM_NUM_VAL IS NULL  then
l_err_Msg:='Invalid FTVal_Config: Parameter '||p_FT_Config_Data(i).PARAM_NAME||
'  for ERR_CODE = '||to_char(p_FT_Config_Data(i).ERR_CODE)||' and ERR_CLASS = '||p_FT_Config_Data(i).ERR_CLASS||' is not set correctly. Value is NULL.';
raise invalid_config_param;
end if;
l_All_Limit:= p_FT_Config_Data(i).PARAM_NUM_VAL;
elsif (p_level =3 and
l_Class_Limit= c_NUMBER_DFLT and
p_FT_Config_Data(i).PARAM_NAME = c_LIMIT and
p_FT_Config_Data(i).ERR_CODE = c_99999 and
p_FT_Config_Data(i).ERR_CLASS = p_Error_Class) then
if p_FT_Config_Data(i).PARAM_NUM_VAL IS NULL  then
l_err_Msg:='Invalid FTVal_Config: Parameter '||p_FT_Config_Data(i).PARAM_NAME||
'  for ERR_CODE = '||to_char(p_FT_Config_Data(i).ERR_CODE)||' and ERR_CLASS = '||p_FT_Config_Data(i).ERR_CLASS||' is not set correctly. Value is NULL.';
raise invalid_config_param;
end if;
l_Class_Limit:= p_FT_Config_Data(i).PARAM_NUM_VAL;
elsif (p_level =3 and
p_Error_Limit= c_NUMBER_DFLT and
p_FT_Config_Data(i).PARAM_NAME = c_LIMIT and
p_FT_Config_Data(i).ERR_CODE = p_Error_Code and
p_FT_Config_Data(i).ERR_CLASS = p_Error_Class ) then
if p_FT_Config_Data(i).PARAM_NUM_VAL IS NULL  then
l_err_Msg:='Invalid FTVal_Config: Parameter '||p_FT_Config_Data(i).PARAM_NAME||
'  for ERR_CODE = '||to_char(p_FT_Config_Data(i).ERR_CODE)||' and ERR_CLASS = '||p_FT_Config_Data(i).ERR_CLASS||' is not set correctly. Value is NULL.';
raise invalid_config_param;
end if;
p_Error_Limit:= p_FT_Config_Data(i).PARAM_NUM_VAL;
elsif (p_level =2 and
NOT p_At_Least_1_Limit_Found and
p_FT_Config_Data(i).PARAM_NAME = c_LIMIT and
p_FT_Config_Data(i).ERR_CLASS = p_Error_Class and
p_FT_Config_Data(i).PARAM_NUM_VAL <> c_LIMIT_EXCLUDE_IT
) then
p_At_Least_1_Limit_Found:=TRUE;
elsif (p_level =1 and
NOT p_At_Least_1_Limit_Found and
p_FT_Config_Data(i).PARAM_NAME = c_LIMIT and
p_FT_Config_Data(i).PARAM_NUM_VAL <> c_LIMIT_EXCLUDE_IT
) then
p_At_Least_1_Limit_Found:=TRUE;
end if;
EXIT WHEN
(  (p_All_Stop_At_First!=c_CHAR_DFLT)
AND (p_All_Validate_Other_Detect != c_CHAR_DFLT)
AND (p_All_Recording_Mode != c_CHAR_DFLT)
AND (l_All_Limit != c_NUMBER_DFLT)
AND (p_level < 3)
AND (p_At_Least_1_Limit_Found))
OR
(  (p_All_Stop_At_First!=c_CHAR_DFLT)
AND (p_All_Validate_Other_Detect != c_CHAR_DFLT)
AND (p_All_Recording_Mode != c_CHAR_DFLT)
AND (l_All_Limit != c_NUMBER_DFLT)
AND (l_Class_Limit != c_NUMBER_DFLT)
AND (p_Error_Limit != c_NUMBER_DFLT)
AND (p_level = 3) )
;
END LOOP;
END IF;
--- Validation after all parameters are read:
-- 1. Check if mandatory parameters are initialized:
if p_Validate_Params then
validate_param_init    (  c_STOP_AT_FIRST               , p_All_Stop_At_First         , c_99999, c_ALL, c_CHAR_DFLT ) ;
validate_param_init    (  c_VALIDATE_OTHER_DETECTABLES  , p_All_Validate_Other_Detect , c_99999, c_ALL, c_CHAR_DFLT ) ;
validate_param_init    (  c_RECORDING_MODE              , p_All_Recording_Mode        , c_99999, c_ALL, c_CHAR_DFLT ) ;
end if;
-- 2. Propagating limits down the hierarchy (ALL->Class->Error)
if  p_All_Validate_Other_Detect =c_VALIDATE_OTHER_VAL_TRUE then
if p_level=3 then -- For error and class
if (p_Error_Limit =c_NUMBER_DFLT) and (l_Class_Limit <>c_NUMBER_DFLT) then
p_Error_Limit:= l_Class_Limit;
end if;
if (p_Error_Limit =c_NUMBER_DFLT) and (l_All_Limit <>c_NUMBER_DFLT) then
p_Error_Limit:= l_All_Limit;
end if;
end if;
end if;
exception when invalid_config_param then
raise_application_error(-20510,l_err_Msg  , true);
end;
--
PROCEDURE get_num_of_allowed_records (
p_Error_Code   IN  NUMBER
,p_Error_Class  IN  VARCHAR2
,p_Error_Limit	IN 	NUMBER
--
,p_Err_Counts  	IN	 FTVAL_CURR_CNT_TABLE
--
,p_Number_of_Requested_Records 	IN NUMBER
,p_Number_of_Rows_to_Record OUT NUMBER ) IS
l_total_Error_Count	 NUMBER;
l_Number_of_Allowed_Records NUMBER;
l_found BOOLEAN :=FALSE;
BEGIN
--dbms_output.put_line('get_num_of_allowed_records BEGIN: p_Number_of_Requested_Records =  '||to_char( p_Number_of_Requested_Records));
--dbms_output.put_line('get_num_of_allowed_records BEGIN: p_Error_Code =  '||to_char(p_Error_Code));
--dbms_output.put_line('get_num_of_allowed_records BEGIN: p_Error_Limit =  '||to_char(p_Error_Limit));
if (nvl(p_Number_of_Requested_Records,0)  >0) then
l_Number_of_Allowed_Records:=  p_Number_of_Requested_Records;
-- 1 process "simple" limits (limits are not set or "0")
if p_Error_Limit <0 then
null; -- p_Number_of_Rows_to_Record does not change
elsif  (p_Error_Limit =0) then
l_Number_of_Allowed_Records:=0;
else
--
-- 2 process "complex" limits: positive limits are set on ANY or ALL levels (All, Class, Error)
--
--  2.1 find out TOTAL COUNTS for Error from  FTVAL_CURR_CNT_TABLE
--
if p_Err_Counts IS NOT NULL then
if p_Err_Counts.COUNT >0 then
for i in p_Err_Counts.FIRST.. p_Err_Counts.LAST
loop
if ( p_Err_Counts(i).ERR_CLASS = p_Error_Class) and (p_Err_Counts(i).ERR_CODE=p_Error_Code)
then
l_total_Error_Count:=p_Err_Counts(i).CURR_CNT;
l_found := TRUE;
end if;
exit when l_found;
end loop;
end if;
end if;
if l_total_Error_Count IS NULL then
l_total_Error_Count:=0;
end if;
--
-- 2.2. Check THIS counts + TOTAL counts against the LIMIT
--
if  (l_Number_of_Allowed_Records  > (p_Error_Limit - l_total_Error_Count) ) then
l_Number_of_Allowed_Records :=   p_Error_Limit - l_total_Error_Count;
end if;
--
end if; -- positive limits
else
l_Number_of_Allowed_Records:=0;
end if;  -- (p_Number_of_Rows_to_Record >0)
--dbms_output.put_line('END: l_Number_of_Allowed_Records =  '||to_char( l_Number_of_Allowed_Records));
-- define return value
if l_Number_of_Allowed_Records <0 then
l_Number_of_Allowed_Records:=0;
end if;
p_Number_of_Rows_to_Record := l_Number_of_Allowed_Records;
END;
--
--
--
PROCEDURE update_Error_Counts (
p_Error_Code            IN     NUMBER
, p_Error_Class           IN     VARCHAR2
, p_Number_of_Rows        IN     NUMBER
, p_Err_Counts            IN OUT FTVAL_CURR_CNT_TABLE
) IS
l_updated BOOLEAN := FALSE;
BEGIN
--   dbms_output.put_line('begin update_Error_Counts p_Err_Counts.COUNT='||to_char(p_Err_Counts.COUNT));
if (p_Error_Code <> c_99999 and p_Error_Class <> c_ALL) then
-- initialize  p_Err_Counts if it is NULL
if (p_Err_Counts IS NULL) then
p_Err_Counts := initialize_err_counts;
--dbms_output.put_line('p_Err_Counts initialized');
end if;
--
if p_Err_Counts.COUNT >0 then
for i in p_Err_Counts.FIRST.. p_Err_Counts.LAST
loop
if (p_Err_Counts(i).ERR_CODE = p_Error_Code AND  p_Err_Counts(i).ERR_CLASS = p_Error_Class)
then
p_Err_Counts(i).CURR_CNT := p_Err_Counts(i).CURR_CNT + p_Number_of_Rows;
--
-- Update record in the table CURR_CNT_TABLE here !!!!
--
update_err_count_record(p_Error_Code, p_Error_Class, p_Err_Counts(i).CURR_CNT);
l_updated := TRUE;
end if;
exit when l_updated;
end loop;
end if;
IF (NOT l_updated) then
p_Err_Counts.EXTEND;
p_Err_Counts(p_Err_Counts.LAST):= new FTVAL_CURR_CNT(p_Error_Code,p_Error_Class,p_Number_of_Rows);
--
-- Insert record into the table CURR_CNT_TABLE here !!!!
--
insert_err_count_record(p_Error_Code,p_Error_Class,p_Number_of_Rows);
end if;
end if;
--dbms_output.put_line('end update_Error_Counts p_Err_Counts.COUNT='||to_char(p_Err_Counts.COUNT));
END;
--
PROCEDURE insert_Errors_Into_Collection (
p_Error_Code              IN          NUMBER
, p_Error_Class             IN          VARCHAR2
, p_Number_of_Allowed_Rows  IN          NUMBER
, p_FT_Status_Data          IN   OUT   FT_STATUS_TABLE
, p_FT_Report_Data          IN   OUT   FT_REPORT_DATA
) IS
l_num_inserted NUMBER:=0;
i NUMBER :=0;
BEGIN
--  Insert found errors into COLLECTION
if p_FT_Status_Data.COUNT > 0 and p_Number_of_Allowed_Rows <>0  then
--dbms_output.put_line('begin insert_errorrs p_Number_of_Allowed_Rows='||to_char(p_Number_of_Allowed_Rows));
i := p_FT_Status_Data.FIRST;
while (i IS NOT NULL)
loop
if (p_FT_Status_Data(i).ERR_CD = p_Error_Code) then
p_FT_Report_Data.EXTEND();
-- persist record into FT_REPORT_DATA
p_FT_Report_Data(p_FT_Report_Data.LAST) := new FT_REPORT(p_FT_Status_Data(i).CLASSNAME, p_FT_Status_Data(i).OID, p_FT_Status_Data(i).ERR_CD);
l_num_inserted:= l_num_inserted+1;
end if;
i:= p_FT_Status_Data.NEXT(i);
exit when (l_num_inserted=p_Number_of_Allowed_Rows) and (p_Number_of_Allowed_Rows <>c_NUMBER_DFLT);-- the limit is set and met
end loop;
end if;
--dbms_output.put_line('end insert_errorrs p_FT_Status_Data.COUNT='||to_char(p_FT_Status_Data.COUNT));
--dbms_output.put_line('end insert_errorrs p_FT_Report_Data.COUNT='||to_char(p_FT_Report_Data.COUNT));
END;
--
PROCEDURE insert_Errors_Into_Table (
p_Error_Code      IN     NUMBER
, p_Error_Class     IN     VARCHAR2
, p_Number_of_Allowed_Rows  IN         NUMBER
, p_FT_Status_Data          IN     OUT FT_STATUS_TABLE
) IS
t FT_STATUS_TABLE;
BEGIN
INSERT INTO WCTK_AHF_EPMFTValPK_Errs (OBJ_CLASS,OBJ_ID,CODE)
SELECT * FROM (
SELECT distinct CLASSNAME,OID,ERR_CD
FROM TABLE(cast(p_FT_Status_Data  as FT_STATUS_TABLE)) t
WHERE
ERR_CD    =p_Error_Code
AND   (ROWNUM > 0)
) s
WHERE
(ROWNUM < (p_Number_of_Allowed_Rows+1))
OR (p_Number_of_Allowed_Rows = c_NUMBER_DFLT)
;
COMMIT;
END;
--
-- ===========================================================================
-- ***************************************************************************
-- ===========================================================================
PROCEDURE record_errors(
p_Error_Code      IN     NUMBER
, p_Error_Class     IN     VARCHAR2
, p_FT_Config_Data  IN OUT FTVAL_CONFIG_TABLE
, p_FT_Status_Data  IN OUT FT_STATUS_TABLE
, p_FT_Report_Data  IN OUT FT_REPORT_DATA
, p_Continue           OUT BOOLEAN) IS
--TY DEBUG
v_sqltext VARCHAR2(200);
-- config params
l_All_Stop_At_First VARCHAR2(10);
l_All_Validate_Other_Detect  VARCHAR2(10);
l_All_Recording_Mode  VARCHAR2(30);
l_Error_Limit NUMBER; -- not used
l_At_Least_1_Limit_Found BOOLEAN;
--
l_Validate BOOLEAN := TRUE;
l_Number_of_Allowed_Record NUMBER;
--
l_this_Error_Count NUMBER;
--
--
l_Number_of_Rows_to_Record NUMBER;
p_Err_Counts   FTVAL_CURR_CNT_TABLE;
BEGIN
--
-- Check if there are records for us to record
--
if (p_FT_Status_Data IS NOT NULL) then
if  (p_FT_Status_Data.COUNT > 0) then
-- initialize  p_Err_Counts
p_Err_Counts:= initialize_err_counts;
l_Number_of_Rows_to_Record := 0;
if  (p_Error_Class IS NULL)  then
raise_application_error(-20516, 'Invalid usage of FTValidator_Helper_PK.record_errors: Parameter  p_Error_Class IS NULL', true);
end if;
if  (p_Error_Code IS NULL)  then
raise_application_error(-20517, 'Invalid usage of FTValidator_Helper_PK.record_errors: Parameter  p_Error_Code IS NULL', true);
end if;
read_config_values(p_FT_Config_Data
, 3
, FALSE
, p_Error_Code
, p_Error_Class
, l_All_Stop_At_First
, l_All_Validate_Other_Detect
, l_All_Recording_Mode
, l_Error_Limit
, l_At_Least_1_Limit_Found  );
-- 1) define IF CONTINUE
if  (p_FT_Status_Data.COUNT >0) and (l_All_Stop_At_First = c_STOP_AT_FIRST_VAL_TRUE) then
p_Continue := FALSE;
else
p_Continue := TRUE;
end if;
-- define HOW MANY ERRORS to record and process them
-- Set  number of errors to record
-- 2. Find out number of ERRORS found for THIS CHUNK
if ( l_Error_Limit <>0 ) then
select count(*) cnt
into  l_this_Error_Count
from (
SELECT CLASSNAME ,
OID,
ERR_CD
FROM TABLE(CAST(p_FT_Status_Data AS FT_STATUS_TABLE))
) t
where ERR_CD =p_Error_Code;
get_num_of_allowed_records (
p_Error_Code
,p_Error_Class
,l_Error_Limit
,p_Err_Counts
,l_this_Error_Count
,l_Number_of_Rows_to_Record); -- number of allowed records
else
l_Number_of_Rows_to_Record:= c_NUMBER_DFLT;
end if; -- limits are set
-- 3)  Update COUNTS collection
if (l_Number_of_Rows_to_Record >0) then
update_Error_Counts (p_Error_Code
, p_Error_Class
, l_Number_of_Rows_to_Record
, p_Err_Counts );
-- 4) Record found errors into the TABLE or COLLECTION
if (l_All_Recording_Mode = c_RECORDING_MODE_VAL_TABL) then
insert_Errors_Into_Table  ( p_Error_Code
, p_Error_Class
, l_Number_of_Rows_to_Record
, p_FT_Status_Data
) ;
elsif (l_All_Recording_Mode = c_RECORDING_MODE_VAL_COLL) then
insert_Errors_Into_Collection (
p_Error_Code
, p_Error_Class
, l_Number_of_Rows_to_Record
, p_FT_Status_Data
, p_FT_Report_Data
);
end if;
end if;
-- 5) CLEAN UP p_FT_Status_Data!!!!
p_FT_Status_Data.DELETE;
else
-- p_FT_Status_Data is not null, but there are no records
-- Nothing to record, set CONTINUE flag to TRUE
p_Continue := TRUE;
end if;   -- if p_FT_Status_Data is populated
else
-- p_FT_Status_Data is null
-- Nothing to record, set CONTINUE flag to TRUE
p_Continue := TRUE;
end if;   --if p_FT_Status_Data IS NOT NULL
END;
-- *****************************************
PROCEDURE should_validate_error(
p_Error_Code      IN     NUMBER
, p_Error_Class     IN     VARCHAR2
, p_FT_Config_Data  IN OUT FTVAL_CONFIG_TABLE
, p_Answer             OUT BOOLEAN) IS
l_All_Stop_At_First VARCHAR2(10);
l_All_Validate_Other_Detect  VARCHAR2(10);
l_All_Recording_Mode  VARCHAR2(30);
l_Error_Limit NUMBER;
--
l_Validate BOOLEAN := TRUE;
l_Number_of_Allowed_Record NUMBER;
l_At_Least_1_Limit_Found BOOLEAN;
p_Err_Counts  FTVAL_CURR_CNT_TABLE;
BEGIN
-- initialize  p_Err_Counts
p_Err_Counts:= initialize_err_counts;
if  (p_Error_Class IS NULL)  then
raise_application_error(-20513, 'Invalid usage of FTValidator_Helper_PK.should_validate_error: Parameter  p_Error_Class IS NULL', true);
end if;
if  (p_Error_Code IS NULL)  then
raise_application_error(-20514, 'Invalid usage of FTValidator_Helper_PK.should_validate_error: Parameter  p_Error_Code IS NULL', true);
end if;
-- get config values
read_config_values(p_FT_Config_Data
, 3
, FALSE
, p_Error_Code
, p_Error_Class
, l_All_Stop_At_First
, l_All_Validate_Other_Detect
, l_All_Recording_Mode
, l_Error_Limit
, l_At_Least_1_Limit_Found  );
if (l_Error_Limit = c_NUMBER_DFLT ) or (l_Error_Limit = c_LIMIT_EXCLUDE_IT ) then
l_Validate := FALSE;
end if;
-- check if number of found records does not exceed LIMIT for ERROR
if  (l_Validate) then
get_num_of_allowed_records (p_Error_Code
,p_Error_Class
,l_Error_Limit
,p_Err_Counts
,1 -- at least 1 record
,l_Number_of_Allowed_Record); -- number of allowed records
if  (l_Number_of_Allowed_Record <1) then
l_Validate := FALSE;
end if;
end if;
p_Answer := l_Validate;
END;
-- *****************************************
PROCEDURE should_validate_class(
p_Error_Class     IN     VARCHAR2
, p_FT_Config_Data  IN OUT FTVAL_CONFIG_TABLE
, p_Answer             OUT  BOOLEAN) IS
--  config parameters for All level
l_All_Stop_At_First VARCHAR2(10);
l_All_Validate_Other_Detect  VARCHAR2(10);
l_All_Recording_Mode  VARCHAR2(30);
l_Error_Limit NUMBER; -- not used
--
l_Validate BOOLEAN := TRUE;
l_Number_of_Allowed_Record NUMBER;
l_At_Least_1_Limit_Found BOOLEAN;
BEGIN
--dbms_output.put_line('should_validate_class BEGIN! '||' error_class='||p_error_class);
if  (p_Error_Class IS NULL)  then
raise_application_error(-20512, 'Invalid usage of FTValidator_Helper_PK.should_validate_class: Parameter  p_Error_Class IS NULL', true);
end if;
-- get config values
read_config_values(
p_FT_Config_Data
, 2
, TRUE
, c_99999
, p_Error_Class
, l_All_Stop_At_First
, l_All_Validate_Other_Detect
, l_All_Recording_Mode
, l_Error_Limit
, l_At_Least_1_Limit_Found  );
-- if no records for this error/class/all are found in config, check VALIDATE_OTHER_DETECTABLES
if (
(NOT l_At_Least_1_Limit_Found ) AND
(l_All_Validate_Other_Detect = c_VALIDATE_OTHER_VAL_FALSE) ) then
l_Validate := FALSE;
end if;
--
p_Answer := l_Validate;
END;
--***************************************************************
PROCEDURE should_validate_chunk(
p_Error_Class     IN     VARCHAR2
, p_FT_Config_Data  IN OUT FTVAL_CONFIG_TABLE
, p_Answer             OUT  BOOLEAN) IS
l_Validate BOOLEAN := TRUE;
l_got_room  BOOLEAN:=FALSE;
l_got_room_str VARCHAR2(20);
l_found_Err_count BOOLEAN:=FALSE;
p_Err_Counts FTVAL_CURR_CNT_TABLE;
--
BEGIN
-- initialize  p_Err_Counts
p_Err_Counts:= initialize_err_counts;
should_validate_class(p_Error_Class
, p_FT_Config_Data
, l_Validate);
-- check if number of found records does not exceed LIMIT for ERROR
if  (l_Validate) then
-- try to find at least 1 error code within the class with the limit which is not filled yet
if p_Err_Counts.COUNT IS NOT NULL then
if p_Err_Counts.COUNT >0 then
for i in p_Err_Counts.FIRST.. p_Err_Counts.LAST
loop
if ( p_Err_Counts(i).ERR_CLASS = p_Error_Class) then
l_found_Err_count := TRUE;
should_validate_error(
p_Err_Counts(i).ERR_CODE
, p_Err_Counts(i).ERR_CLASS
, p_FT_Config_Data
, l_got_room) ;
end if;
exit when l_got_room;
end loop;
if NOT l_got_room and l_found_Err_count then
l_Validate:=FALSE;
end if;
end if;
end if;
end if;
--
p_Answer := l_Validate;
END;
--***************************************************************
PROCEDURE should_return_collection(
p_FT_Config_Data  IN     FTVAL_CONFIG_TABLE
, p_Answer           OUT BOOLEAN) IS
-- config params
l_All_Recording_Mode  VARCHAR2(30);
-- others are not used:
l_All_Stop_At_First VARCHAR2(10);
l_All_Validate_Other_Detect  VARCHAR2(10);
l_Error_Limit NUMBER;
l_At_Least_1_Limit_Found BOOLEAN;
--
BEGIN
read_config_values(
p_FT_Config_Data
, 1
, TRUE
, c_99999
, c_ALL
, l_All_Stop_At_First
, l_All_Validate_Other_Detect
, l_All_Recording_Mode
, l_Error_Limit
, l_At_Least_1_Limit_Found);
if l_All_Recording_Mode = c_RECORDING_MODE_VAL_COLL then
p_Answer:= TRUE;
else
p_Answer:= FALSE;
end if;
END;
--***************************************************************
PROCEDURE Truncate_EPMFTValPK_Errs AS
BEGIN
delete from WCTK_AHF_EPMFTValPK_Errs;
update CURR_CNT_TABLE set CURR_CNT=0;
EXCEPTION WHEN OTHERS THEN
null;
END;
--
--***************************************************************
--
PROCEDURE append_report_data(old_FT_Report_Data  IN OUT FT_REPORT_DATA
, new_FT_Report_Data  IN     FT_REPORT_DATA)
AS
BEGIN
--
IF new_FT_Report_Data.COUNT > 0 THEN
IF old_FT_Report_Data IS NOT NULL THEN
FOR i in 1..new_FT_Report_Data.COUNT LOOP
old_FT_Report_Data.extend();
old_FT_Report_Data(old_FT_Report_Data.LAST) := new FT_REPORT(new_FT_Report_Data(i).CLASSNAME, new_FT_Report_Data(i).OID, new_FT_Report_Data(i).ERR_CD);
END LOOP;
END IF;
END IF;
--
END;
END;
/

